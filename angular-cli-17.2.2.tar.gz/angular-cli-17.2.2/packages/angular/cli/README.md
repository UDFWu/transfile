# Angular CLI - The CLI tool for Angular.

The sources for this package are in the [Angular CLI](https://github.com/angular/angular-cli) repository. Please file issues and pull requests against that repository.

Usage information and reference details can be found in repository [README](../../../README.md) file.
