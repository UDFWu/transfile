package com.ibm.cbmp.fabric.foundation.mcs;

import java.util.Map;
import java.util.Objects;
import java.util.function.Supplier;

import com.ibm.cbmp.fabric.foundation.toolkit.CastUtils;

/**
 * McsContext
 */
public interface McsContext extends Map<Object, Object> {
    /**
     * Returns the value to which the specified key is mapped,
     */
    default <K, V> V getObject(K key) {
        return CastUtils.cast(this.get(key));
    }

    /**
     * Associates the specified value with the specified key in this map
     */
    default <K, V> V putObject(K key, V value) {
        return CastUtils.cast(this.put(key, value));
    }

    /**
     * Removes the mapping for a key from this map if it is present
     */
    default <K, V> V removeObject(K key) {
        return CastUtils.cast(this.remove(key));
    }

    /**
     * If the specified key is not already associated with a value (or is mapped to {@code null}), attempts to compute its value using the given mapping function and enters it into this map unless
     * {@code null}.
     */
    default <K, V> V getObject(K key, Supplier<V> supplierFunction) {
        Objects.requireNonNull(supplierFunction);
        V v;
        if ((v = getObject(key)) == null) {
            V newValue;
            if ((newValue = supplierFunction.get()) != null) {
                put(key, newValue);
                return newValue;
            }
        }
        return v;
    }
}
