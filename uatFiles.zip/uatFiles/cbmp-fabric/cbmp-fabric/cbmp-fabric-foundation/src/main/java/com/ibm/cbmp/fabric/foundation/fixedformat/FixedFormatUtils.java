package com.ibm.cbmp.fabric.foundation.fixedformat;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.WeakHashMap;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.reflect.ConstructorUtils;
import org.hibernate.mapping.Collection;
import org.springframework.beans.BeanUtils;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.util.Assert;
import org.springframework.util.ReflectionUtils.FieldCallback;

import com.ibm.cbmp.fabric.foundation.fixedformat.annotation.Spec;
import com.ibm.cbmp.fabric.foundation.toolkit.SpelExpressionUtils;

/**
 * FixedFormat 內部使用Utils
 */
public class FixedFormatUtils {
    private static WeakHashMap<Class<?>, List<FixedSpecBean>> cachedSpecBeanMap = new WeakHashMap<>();

    public static List<FixedSpecBean> getSpecBeanList(Class<?> type) {
        List<FixedSpecBean> cachedSpecBeanList = cachedSpecBeanMap.get(type);
        if (cachedSpecBeanList != null) {
            return cachedSpecBeanList;
        } else {
            List<FixedSpecBean> specBeanList = new ArrayList<>();
            doWithFields(type, field -> {
                Spec spec = AnnotatedElementUtils.findMergedAnnotation(field, Spec.class);
                if (spec != null
                        || Collection.class.isAssignableFrom(field.getType())
                        || !BeanUtils.isSimpleValueType(field.getType())) {
                    FixedSpecBean specProperties = new FixedSpecBean();
                    specProperties.setField(field);
                    specProperties.setSpec(AnnotatedElementUtils.findMergedAnnotation(field, Spec.class));
                    specBeanList.add(specProperties);
                }
            });
            cachedSpecBeanMap.put(type, specBeanList);
            return specBeanList;
        }
    }

    public static void doWithFields(Class<?> clazz, FieldCallback fc) {
        Assert.notNull(clazz, "Class must not be null");
        Assert.notNull(fc, "FieldCallback must not be null");

        Class<?> superClass = clazz.getSuperclass();
        if (superClass != null && superClass != Object.class) {
            doWithFields(superClass, fc);
        }
        Field[] fields = clazz.getDeclaredFields();
        for (Field field : fields) {
            try {
                fc.doWith(field);
            } catch (IllegalAccessException ex) {
                throw new IllegalStateException("Not allowed to access field '" + field.getName() + "': " + ex, ex);
            }
        }
    }

    public static int getSpecLength(Object instance, Spec spec) {
        if (spec.length() > 0) {
            return spec.length();
        } else if (StringUtils.isNotBlank(spec.lengthRef())) {
            return SpelExpressionUtils.getExpressionValue(spec.lengthRef(), instance, Integer.class);
        } else {
            return 0;
        }
    }

    public static <T> T createObject(Class<T> resultType) {
        try {
            return ConstructorUtils.invokeConstructor(resultType);
        } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException | InstantiationException e) {
            throw new IllegalStateException("Falled to create Object : " + resultType, e);
        }
    }

    public static byte[] readSpecBytes(FixedSpecBean specBean, int length, InputStream inputStream) throws IOException {
        byte[] bytes = new byte[length];
        int readCount = IOUtils.read(inputStream, bytes);
        if (length != readCount) {
            throw new EOFException("資料長度不足 : " + specBean.getField().getName());
        }
        return bytes;
    }
}
