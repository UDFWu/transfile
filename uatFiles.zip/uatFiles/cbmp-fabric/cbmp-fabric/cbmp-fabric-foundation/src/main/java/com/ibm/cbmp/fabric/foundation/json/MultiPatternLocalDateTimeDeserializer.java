package com.ibm.cbmp.fabric.foundation.json;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoField;
import java.time.temporal.TemporalAccessor;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;

/**
 * JSON日期格式解析
 */
public class MultiPatternLocalDateTimeDeserializer extends LocalDateTimeDeserializer {
    private static final DateTimeFormatter DEFAULT_FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
    private DateTimeFormatter[] dateTimeFormatters;

    public MultiPatternLocalDateTimeDeserializer() {
        this(DEFAULT_FORMATTER);
    }

    public MultiPatternLocalDateTimeDeserializer(DateTimeFormatter... dateTimeFormatters) {
        super(dateTimeFormatters[0]);
        this.dateTimeFormatters = ArrayUtils.subarray(dateTimeFormatters, 1, dateTimeFormatters.length);
    }

    @Override
    public LocalDateTime deserialize(JsonParser jsonParser, DeserializationContext ctxt) throws IOException, JacksonException {
        try {
            return super.deserialize(jsonParser, ctxt);
        } catch (Exception e) {
            String value = jsonParser.readValueAs(String.class);
            if (StringUtils.isNotBlank(value)) {
                for (DateTimeFormatter dateTimeFormatter : dateTimeFormatters) {
                    try {
                        return this.parseLocalDateTime(value, dateTimeFormatter);
                    } catch (Exception ex) {
                        // 忽略其他格式的Exception
                    }
                }
            }
            throw e;
        }
    }

    private LocalDateTime parseLocalDateTime(String value, DateTimeFormatter dateTimeFormatter) {
        TemporalAccessor temporal = dateTimeFormatter.parse(value);
        if (temporal.isSupported(ChronoField.INSTANT_SECONDS)) {
            OffsetDateTime offsetDateTime = OffsetDateTime.from(temporal);
            ZonedDateTime zonedDateTime = offsetDateTime.atZoneSameInstant(ZoneId.systemDefault());
            return zonedDateTime.toLocalDateTime();
        } else if (temporal.isSupported(ChronoField.HOUR_OF_DAY)) {
            return LocalDateTime.from(temporal);
        } else {
            return LocalDate.from(temporal).atStartOfDay();
        }
    }
}
