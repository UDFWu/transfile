package com.ibm.cbmp.fabric.foundation.toolkit;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.Nulls;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.TreeNode;
import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.Module;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectMapper.DefaultTyping;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.cfg.CoercionAction;
import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.type.LogicalType;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalTimeSerializer;
import com.ibm.cbmp.fabric.foundation.json.MultiPatternLocalDateTimeDeserializer;

public class JsonUtils {

    private static ObjectMapper objectMapper;

    private static ObjectMapper redisObjectMapper;

    /**
     * prettyWriter
     **/
    private static ObjectWriter prettyWriter;

    /**
     * ignoreEmptyObjectMapper
     **/
    private static ObjectMapper ignoreEmptyObjectMapper;

    /**
     * nullToEmptyObjectMapper
     **/
    private static ObjectMapper nullToEmptyObjectMapper;

    static {
        objectMapper = buildDefaultObjectMapper();

        prettyWriter = objectMapper.writerWithDefaultPrettyPrinter();
        ignoreEmptyObjectMapper = objectMapper.copy().setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
        nullToEmptyObjectMapper = objectMapper.copy();
        nullToEmptyObjectMapper.disable(MapperFeature.USE_ANNOTATIONS);
        nullToEmptyObjectMapper.configOverride(String.class)
                .setSetterInfo(JsonSetter.Value.forValueNulls(Nulls.AS_EMPTY));

        initRedisObjectMapper();
    }

    private JsonUtils() {

    }

    private static ObjectMapper buildDefaultObjectMapper() {

        return new Jackson2ObjectMapperBuilder().failOnEmptyBeans(false)
                .failOnUnknownProperties(false)
                .indentOutput(false)
                .defaultUseWrapper(true)
                .serializationInclusion(JsonInclude.Include.NON_NULL)
                .defaultViewInclusion(false)
                .modules(
                        // Optional
                        new Jdk8Module(),
                        // Dates/Times
                        new JavaTimeModule(),
                        buildFabricApiTimeModule())
                .featuresToDisable(
                        SerializationFeature.WRITE_DATES_AS_TIMESTAMPS,
                        DeserializationFeature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS,
                        SerializationFeature.WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS)
                .featuresToEnable(
                        SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS,
                        DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_USING_DEFAULT_VALUE)
                .featuresToEnable(DeserializationFeature.FAIL_ON_NUMBERS_FOR_ENUMS)
                .postConfigurer(objectMapper -> {
                    objectMapper.coercionConfigFor(LogicalType.Enum)
                            .setCoercion(CoercionInputShape.EmptyString, CoercionAction.AsNull)
                            .setAcceptBlankAsEmpty(true);
                })
                .visibility(PropertyAccessor.ALL, Visibility.ANY)
                .timeZone("GMT+8")
                .build();
    }

    private static Module buildFabricApiTimeModule() {
        SimpleModule timeModule = new SimpleModule("FabricApiTimeModule", Version.unknownVersion());
        // 對LocalDateTime類，response轉換json至Angular 提供統一的序列化方式
        timeModule.addSerializer(LocalDateTime.class, new LocalDateTimeSerializer(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        timeModule.addSerializer(LocalDate.class, new LocalDateSerializer(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        timeModule.addSerializer(LocalTime.class, new LocalTimeSerializer(DateTimeFormatter.ofPattern("HH:mm:ss")));

        // 對LocalDateTime類，request json轉換為java bean 提供統一的序列化方式
        // timeModule.addDeserializer(LocalDateTime.class, new LocalDateTimeDeserializer(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        timeModule.addDeserializer(LocalDateTime.class,
                new MultiPatternLocalDateTimeDeserializer(
                        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss[.SSS]"),
                        DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss[.SSS][X]")));
        timeModule.addDeserializer(LocalDate.class, new LocalDateDeserializer(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        timeModule.addDeserializer(LocalTime.class, new LocalTimeDeserializer(DateTimeFormatter.ofPattern("HH:mm:ss")));
        return timeModule;
    }

    private static void initRedisObjectMapper() {
        redisObjectMapper = getObjectMapper().copy();
        redisObjectMapper.activateDefaultTyping(objectMapper.getPolymorphicTypeValidator(), DefaultTyping.NON_FINAL, As.PROPERTY);
        GenericJackson2JsonRedisSerializer.registerNullValueSerializer(redisObjectMapper, null);
    }

    public static ObjectMapper getObjectMapper() {
        return objectMapper;
    }

    public static ObjectMapper getRedisObjectMapper() {
        return redisObjectMapper;
    }

    public static TypeFactory getTypeFactory() {
        return objectMapper.getTypeFactory();
    }

    public static String toJson(Object obj) {
        try {
            return objectMapper.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return Objects.toString(obj);
        }
    }

    public static String toPrettyJson(Object obj) {
        try {
            return prettyWriter.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return Objects.toString(obj);
        }
    }

    public static JsonNode toJsonNode(String jsonStr) {
        try {
            return objectMapper.readTree(jsonStr);
        } catch (JsonProcessingException ex) {
            ex.printStackTrace();
        }

        return null;
    }

    public static <T> T toObject(InputStream jsonIs, Class<T> valueType) {
        try {
            return objectMapper.readValue(jsonIs, valueType);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    public static <T> T toObject(String jsonStr, Class<T> valueType) {
        try {
            if (StringUtils.isNotBlank(jsonStr)) {
                return objectMapper.readValue(jsonStr, valueType);
            } else {
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static <T> List<T> toObjectList(String json, Class<T> valueType) {
        try {
            if (StringUtils.isNotBlank(json)) {
                return objectMapper.readerForListOf(valueType).readValue(json);
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return null;
    }

    public static <T> T treeToValue(TreeNode treeNode, Class<T> valueType) {
        try {
            return objectMapper.treeToValue(treeNode, valueType);
        } catch (JsonProcessingException | IllegalArgumentException ex) {
            ex.printStackTrace();
        }

        return null;
    }

    public static String toJsonIgnoreEmpty(Object val) {
        try {
            if (val != null) {
                return ignoreEmptyObjectMapper.writeValueAsString(val);
            } else {
                return null;
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static <T> T[] toObjectArray(String json, Class<T> valueType) {
        try {
            if (StringUtils.isNotBlank(json)) {
                return objectMapper.readerForArrayOf(valueType).readValue(json);
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }
}
