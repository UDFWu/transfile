package com.ibm.cbmp.fabric.foundation.mcs.advice.request;

import org.springframework.beans.factory.annotation.Autowired;

import com.ibm.cbmp.fabric.foundation.mcs.advice.McsExecution;
import com.ibm.cbmp.fabric.foundation.validation.FabricSmartValidator;

public class SimpleRuleValidAdvice implements IRuleValidAdvice {
    @Autowired
    private FabricSmartValidator validator;

    @Override
    public void invoke(McsExecution execution) {
        execution.getApiRequest().ifPresent(validator::validate);
    }
}
