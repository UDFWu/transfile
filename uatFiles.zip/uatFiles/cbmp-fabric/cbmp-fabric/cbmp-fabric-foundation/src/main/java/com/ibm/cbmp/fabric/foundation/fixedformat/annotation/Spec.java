package com.ibm.cbmp.fabric.foundation.fixedformat.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.ibm.cbmp.fabric.foundation.fixedformat.FixedFormatHandler;

/**
 * 定長格式設定使用
 */
@Documented
@Target({ElementType.FIELD, ElementType.ANNOTATION_TYPE })
@Retention(RetentionPolicy.RUNTIME)
public @interface Spec {
    /**
     * 長度
     */
    int length() default -1;

    /**
     * 長度參考另一個欄位值時使用
     */
    String lengthRef() default "";

    /**
     * Load時是否為選擇性欄位，使用SPEL回傳true/false
     */
    String conditional() default "";

    /**
     * 對齊方式
     */
    Align align() default Align.LEFT;

    /**
     * 長度不度時要補的字元
     */
    char padding() default ' ';

    /**
     * 數字/日期格式化PATTERN
     */
    String pattern() default "";

    /**
     * 數字格式小數位數，當此值>=0時，忽略pattern格式
     */
    int decimal() default -1;

    /**
     * 去否去空白, 僅在Load時使用
     */
    boolean trim() default false;

    /**
     * 類別格式式Handler
     */
    Class<?> handler() default FixedFormatHandler.class;

    /**
     * 對齊方式
     */
    public enum Align {
        LEFT,
        RIGHT;
    }
}
