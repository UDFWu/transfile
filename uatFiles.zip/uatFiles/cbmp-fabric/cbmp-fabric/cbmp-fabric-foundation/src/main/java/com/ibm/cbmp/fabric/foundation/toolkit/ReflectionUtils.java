package com.ibm.cbmp.fabric.foundation.toolkit;

import java.lang.reflect.InvocationTargetException;
import java.util.stream.Stream;

import org.springframework.core.ResolvableType;

/**
 * Simple utility class for working with the reflection API
 */
public class ReflectionUtils extends org.springframework.util.ReflectionUtils {
    /**
     * resolve a specific generic parameters
     */
    public static Class<?> resolveGenericParameter(Object instance, Class<?> parameterizedType, int index) {
        ResolvableType reslovableType = ResolvableType.forInstance(instance);
        do {
            for (ResolvableType interfaceType : reslovableType.getInterfaces()) {
                Class<?> rawClasss = interfaceType.getRawClass();
                if (parameterizedType.equals(rawClasss)) {
                    return interfaceType.resolveGeneric(index);
                } else if (parameterizedType.isAssignableFrom(rawClasss)) {
                    for (ResolvableType superInterfaceType : interfaceType.getInterfaces()) {
                        if (parameterizedType.equals(superInterfaceType.getRawClass())) {
                            return superInterfaceType.resolveGeneric(index);
                        }
                    }
                }
            }
            if (parameterizedType.equals(reslovableType.getRawClass())) {
                return reslovableType.resolveGeneric(index);
            }
            reslovableType = reslovableType.getSuperType();

        } while (reslovableType != null && reslovableType.getRawClass() != null);
        throw new UnsupportedOperationException();
    }

    public static <T> T newInstance(Class<T> type, Object... params) {
        try {
            if (params == null || params.length == 0) {
                return type.getConstructor().newInstance();
            }

            Object value = Stream.of(type.getConstructors())
                    .filter(c -> c.getParameterCount() == params.length)
                    .filter(c -> {
                        Class<?>[] paramTypes = c.getParameterTypes();
                        for (int paramIndex = 0; paramIndex < paramTypes.length; paramIndex++) {
                            Class<?> paramType = paramTypes[paramIndex];
                            Object param = params[paramIndex];
                            if (param != null && paramType.isInstance(params)) {
                                return false;
                            }
                        }
                        return true;
                    })
                    .findFirst()
                    .orElseThrow(() -> new IllegalStateException("Constructor not found : " + type.getClass()))
                    .newInstance(params);
            return CastUtils.cast(value);
        } catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException | SecurityException e) {
            throw new IllegalStateException(e);
        }
    }
}
