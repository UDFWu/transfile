package com.ibm.cbmp.fabric.foundation.data.jpa;

import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.PersistenceException;

import org.hibernate.cfg.Environment;
import org.hibernate.dialect.Oracle12cDialect;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.persistenceunit.MutablePersistenceUnitInfo;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

import com.ibm.cbmp.fabric.foundation.resource.FabricClassPathResourceResolver;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * Camp EntityManagerFactoryBean
 */
@Import(FabricPhysicalNamingStrategy.class)
@Slf4j
public class FabricEntityManagerFactoryBean extends LocalContainerEntityManagerFactoryBean {
    private static final String HIBERNATE_PHYSICAL_NAMING_STRATEGY = "hibernate.physical_naming_strategy";
    @Autowired
    private FabricClassPathResourceResolver classPathResourceResolver;
    @Autowired
    private FabricPhysicalNamingStrategy physicalNamingStrategy;
    @Autowired
    private ObjectProvider<FabricJpaConfigurator> jpaConfiguratorProvider;
    @Setter
    private List<Class<? extends Annotation>> enableEntitiesAnnotaionTypes;
    @Getter
    @Setter
    private String[] managedClassNames;
    private Set<String> packagesToScanSet = new LinkedHashSet<>();
    private Set<String> mappingResourceSet = new LinkedHashSet<>();
    /**
     * entity manager name
     */
    @Setter
    private String name;

    public FabricEntityManagerFactoryBean() {
        super();
        HashMap<String, Object> properties = new HashMap<>();
        properties.put(Environment.DIALECT, Oracle12cDialect.class.getName());
        this.setJpaPropertyMap(properties);
        this.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
        this.setPersistenceUnitPostProcessors(this::postProcessPersistenceUnitInfo);
    }

    @Override
    public void afterPropertiesSet() throws PersistenceException {
        if (!this.getJpaPropertyMap().containsKey(HIBERNATE_PHYSICAL_NAMING_STRATEGY)) {
            this.getJpaPropertyMap().put(HIBERNATE_PHYSICAL_NAMING_STRATEGY, physicalNamingStrategy);
        }
        if (enableEntitiesAnnotaionTypes != null) {
            enableEntitiesAnnotaionTypes.stream().forEach(annotationType -> {
                String[] basePackages = FabricJpaConfigurationUtils.getBasePackages(jpaConfiguratorProvider, annotationType, name);
                this.packagesToScanSet.addAll(Arrays.asList(basePackages));

                String[] mappingResources = FabricJpaConfigurationUtils.getMappingResources(jpaConfiguratorProvider, annotationType, name);
                this.mappingResourceSet.addAll(Arrays.asList(mappingResources));
            });
            this.setPackagesToScan(packagesToScanSet.toArray(String[]::new));
        }
        this.postProcessMappingResource();
        super.afterPropertiesSet();
    }

    public void setJpaVendorAdapterClass(Class<JpaVendorAdapter> jpaVendorAdapterClass)
            throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
        super.setJpaVendorAdapter(jpaVendorAdapterClass.getConstructor().newInstance());
    }

    private void postProcessPersistenceUnitInfo(MutablePersistenceUnitInfo persistenceUnitInfo) {
        if (managedClassNames != null) {
            for (String managedClassName : managedClassNames) {
                persistenceUnitInfo.addManagedClassName(managedClassName);
            }
        }
    }

    @Override
    public void setPackagesToScan(String... packagesToScan) {
        super.setPackagesToScan(packagesToScan);
        packagesToScanSet.addAll(Arrays.asList(packagesToScan));
    }

    @Override
    public void setMappingResources(String... mappingResources) {
        this.mappingResourceSet.addAll(Arrays.asList(mappingResources));
    }

    private void postProcessMappingResource() {
        Set<String> allMappingResourceSet = new LinkedHashSet<>();
        for (String mappingResource : mappingResourceSet) {
            if (mappingResource.startsWith(ResourcePatternResolver.CLASSPATH_ALL_URL_PREFIX)) {
                try {
                    classPathResourceResolver
                            .getClassPathResourceList(mappingResource)
                            .stream()
                            .map(ClassPathResource::getPath)
                            .forEach(allMappingResourceSet::add);
                } catch (IOException e) {
                    throw new IllegalStateException(e.getMessage(), e);
                }
            } else {
                allMappingResourceSet.add(mappingResource);
            }
        }
        log.info("mappingResources : {}", allMappingResourceSet);
        super.setMappingResources(allMappingResourceSet.toArray(String[]::new));
    }
}
