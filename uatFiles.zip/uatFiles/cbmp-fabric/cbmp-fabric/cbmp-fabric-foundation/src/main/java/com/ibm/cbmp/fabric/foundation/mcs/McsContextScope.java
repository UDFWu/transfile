package com.ibm.cbmp.fabric.foundation.mcs;

import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.config.Scope;

public class McsContextScope implements Scope {
    @Override
    public Object get(String name, ObjectFactory<?> objectFactory) {
        return McsContextManager.getContext().getObject(name, objectFactory::getObject);
    }

    @Override
    public Object remove(String name) {
        return McsContextManager.getContext().remove(name);
    }

    @Override
    public void registerDestructionCallback(String name, Runnable callback) {
    }

    @Override
    public Object resolveContextualObject(String key) {
        return null;
    }

    @Override
    public String getConversationId() {
        return null;
    }
}
