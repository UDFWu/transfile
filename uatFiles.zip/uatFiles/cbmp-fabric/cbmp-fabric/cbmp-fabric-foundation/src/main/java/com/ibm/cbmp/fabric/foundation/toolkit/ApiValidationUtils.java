package com.ibm.cbmp.fabric.foundation.toolkit;

import java.util.ArrayList;
import java.util.List;

import com.ibm.cbmp.fabric.foundation.enums.api.SeverityEnum;
import com.ibm.cbmp.fabric.foundation.facade.bean.ApiValidationMessage;
import com.ibm.cbmp.fabric.foundation.mcs.McsContextManager;

public class ApiValidationUtils {
    private static final String API_VALIDATION_MESSAGE_KEY = ApiValidationMessage.class.getName();

    /**
     * 設定檢核訊息
     */
    public static void setApiValidationMessages(List<ApiValidationMessage> messages) {
        McsContextManager.getContext().put(API_VALIDATION_MESSAGE_KEY, messages);
    }

    /**
     * 取得檢核訊息
     */
    public static List<ApiValidationMessage> getApiValidationMessages() {
        return McsContextManager.getContext().getObject(API_VALIDATION_MESSAGE_KEY);
    }

    public static void addApiValidationMessage(ApiValidationMessage message) {
        McsContextManager.getContext()
                .getObject(API_VALIDATION_MESSAGE_KEY, ArrayList::new)
                .add(message);
    }

    /**
     * 是否有錯誤等級的訊息
     * @param errorList 錯誤訊息清單
     * @return 若訊息等級>ERROR 回傳true
     */
    public static boolean containsErrorMessage(List<ApiValidationMessage> errorList) {
        for (ApiValidationMessage error : errorList) {
            if (error.getSeverity().getLevel() >= SeverityEnum.ERROR.getLevel()) {
                return true;
            }
        }
        return false;
    }
}
