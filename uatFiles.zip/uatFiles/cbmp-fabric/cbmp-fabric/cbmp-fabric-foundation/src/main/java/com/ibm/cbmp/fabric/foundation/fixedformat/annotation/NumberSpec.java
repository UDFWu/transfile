package com.ibm.cbmp.fabric.foundation.fixedformat.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.core.annotation.AliasFor;

import com.ibm.cbmp.fabric.foundation.fixedformat.FixedFormatHandler;
import com.ibm.cbmp.fabric.foundation.fixedformat.annotation.Spec.Align;

/**
 * 定長格式設定使用
 */
@Documented
@Target({ElementType.FIELD, ElementType.ANNOTATION_TYPE })
@Retention(RetentionPolicy.RUNTIME)
@Spec
public @interface NumberSpec {
    /**
     * 長度
     */
    @AliasFor(annotation = Spec.class)
    int length() default -1;

    /**
     * 長度參考另一個欄位值時使用
     */
    @AliasFor(annotation = Spec.class)
    String lengthRef() default "";

    /**
     * Load時是否為選擇性欄位，使用SPEL回傳true/false
     */
    @AliasFor(annotation = Spec.class)
    String conditional() default "";

    /**
     * 對齊方式
     */
    @AliasFor(annotation = Spec.class)
    Align align() default Align.RIGHT;

    /**
     * 長度不度時要補的字元
     */
    @AliasFor(annotation = Spec.class)
    char padding() default '0';

    /**
     * 數字/日期格式化PATTERN
     */
    @AliasFor(annotation = Spec.class)
    String pattern() default "0";

    /**
     * 數字格式小數位數，當此值>=0時，忽略pattern格式
     */
    @AliasFor(annotation = Spec.class)
    int decimal() default -1;

    /**
     * 去否去空白, 僅在Load時使用
     */
    @AliasFor(annotation = Spec.class)
    boolean trim() default false;

    /**
     * 類別格式式Handler
     */
    @AliasFor(annotation = Spec.class)
    Class<?> handler() default FixedFormatHandler.class;

}
