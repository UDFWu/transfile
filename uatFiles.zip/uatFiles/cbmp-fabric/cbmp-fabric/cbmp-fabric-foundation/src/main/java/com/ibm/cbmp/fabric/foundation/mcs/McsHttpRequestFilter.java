package com.ibm.cbmp.fabric.foundation.mcs;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;

import com.ibm.cbmp.fabric.foundation.api.RequestContext;
import com.ibm.cbmp.fabric.foundation.mcs.annotation.EnableMcs;

@ConditionalOnBean(annotation = EnableMcs.class)
@Order(Ordered.HIGHEST_PRECEDENCE)
public class McsHttpRequestFilter extends OncePerRequestFilter {
    @Autowired
    private RequestContext requestContext;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        try {
            MDC.put("requestURI", request.getRequestURI());
            McsContextManager.initContext();
            requestContext.setHttpServletRequest(request);
            requestContext.setHttpServletResponse(response);
            ContentCachingRequestWrapper requestWrapper = new ContentCachingRequestWrapper(request);
            ContentCachingResponseWrapper responseWrapper = new ContentCachingResponseWrapper(response);
            try {
                filterChain.doFilter(requestWrapper, responseWrapper);
            } finally {
                responseWrapper.copyBodyToResponse();
            }
        } finally {
            McsContextManager.resetContext();
            MDC.clear();
        }
    }
}
