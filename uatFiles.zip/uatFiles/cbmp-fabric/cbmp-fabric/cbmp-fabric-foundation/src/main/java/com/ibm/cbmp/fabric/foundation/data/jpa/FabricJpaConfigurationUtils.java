package com.ibm.cbmp.fabric.foundation.data.jpa;

import java.lang.annotation.Annotation;
import java.lang.reflect.AnnotatedElement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.core.annotation.AnnotatedElementUtils;

public class FabricJpaConfigurationUtils {
    public static <A extends Annotation> String[] getBasePackages(ObjectProvider<FabricJpaConfigurator> jpaConfiguratorProvider, Class<A> annotionType, String name) {
        List<String> basePackages = new ArrayList<>();
        for (FabricJpaConfigurator campJpaConfigurator : jpaConfiguratorProvider) {
            A annotion = AnnotatedElementUtils.findMergedAnnotation(campJpaConfigurator.getClass(), annotionType);
            if (annotion == null) {
                continue;
            }
            AnnotatedElement annotatedElement = AnnotatedElementUtils.forAnnotations(annotion);
            FabricJpaEntities campJpaEntities = AnnotatedElementUtils.findMergedAnnotation(annotatedElement, FabricJpaEntities.class);
            if (campJpaEntities != null && campJpaEntities.name().equals(StringUtils.defaultString(name))) {
                for (String basePackage : campJpaEntities.basePackages()) {
                    if (basePackage != null && !basePackages.contains(basePackage)) {
                        basePackages.add(basePackage);
                    }
                }
            }
        }
        return basePackages.toArray(new String[basePackages.size()]);
    }

    public static <A extends Annotation> String[] getMappingResources(ObjectProvider<FabricJpaConfigurator> jpaConfiguratorProvider, Class<A> annotionType, String name) {
        Set<String> mappingResources = new LinkedHashSet<>();
        for (FabricJpaConfigurator campJpaConfigurator : jpaConfiguratorProvider) {
            A annotion = AnnotatedElementUtils.findMergedAnnotation(campJpaConfigurator.getClass(), annotionType);
            if (annotion == null) {
                continue;
            }
            AnnotatedElement annotatedElement = AnnotatedElementUtils.forAnnotations(annotion);
            FabricJpaEntities campJpaEntities = AnnotatedElementUtils.findMergedAnnotation(annotatedElement, FabricJpaEntities.class);
            if (campJpaEntities != null && campJpaEntities.name().equals(StringUtils.defaultString(name))) {
                mappingResources.addAll(Arrays.asList(campJpaEntities.mappingResources()));
            }
        }
        return mappingResources.toArray(String[]::new);
    }
}
