package com.ibm.cbmp.fabric.foundation.fixedformat.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.reflect.ConstructorUtils;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.springframework.core.ResolvableType;
import org.springframework.util.Assert;

import com.ibm.cbmp.fabric.foundation.fixedformat.FixedFormatCodeEnum;
import com.ibm.cbmp.fabric.foundation.fixedformat.FixedFormatContext;
import com.ibm.cbmp.fabric.foundation.fixedformat.FixedFormatException;
import com.ibm.cbmp.fabric.foundation.fixedformat.FixedFormatHandler;
import com.ibm.cbmp.fabric.foundation.fixedformat.FixedFormatUtils;
import com.ibm.cbmp.fabric.foundation.fixedformat.FixedSpecBean;
import com.ibm.cbmp.fabric.foundation.fixedformat.annotation.Loop;
import com.ibm.cbmp.fabric.foundation.fixedformat.annotation.Spec;
import com.ibm.cbmp.fabric.foundation.toolkit.SpelExpressionUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class AbstractFormatMapper {
    @SuppressWarnings("rawtypes")
    private Map<Class<?>, FixedFormatHandler> formatHandlerMap = new HashMap<>();

    protected <T> T loadBytes(FixedFormatContext context, Class<T> resultType, byte[] inputBytes) {
        return this.loadBytes(context, resultType, new ByteArrayInputStream(inputBytes));
    }

    protected <T> T loadBytes(FixedFormatContext context, Class<T> resultType, InputStream input) {
        T instance = FixedFormatUtils.createObject(resultType);
        List<FixedSpecBean> specBeanList = FixedFormatUtils.getSpecBeanList(resultType);
        for (FixedSpecBean specProperties : specBeanList) {
            Field field = specProperties.getField();
            if (log.isTraceEnabled()) {
                log.trace("Load Field => {}. {}, type : {}", resultType.getSimpleName(), field.getName(), field.getType());
            }

            if (specProperties.getSpec() != null) {
                this.loadSpec(context, specProperties, input, instance);
            } else if (List.class.isAssignableFrom(field.getType())) {
                Class<?> elementType = ResolvableType.forField(specProperties.getField()).getGeneric(0).resolve();
                List<?> fieldValue = this.loadList(context, field, elementType, input, instance);
                this.setFieldValue(specProperties.getField(), instance, fieldValue);
            } else {
                Object fieldValue = this.loadBytes(context, field.getType(), input);
                this.setFieldValue(field, instance, fieldValue);
            }
        }
        return instance;
    }

    protected void loadSpec(FixedFormatContext context, FixedSpecBean specBean, InputStream inputStream, Object instance) {
        try {
            int length = FixedFormatUtils.getSpecLength(instance, specBean.getSpec());
            context.setCurrentSpecBean(specBean);

            byte[] bytes = FixedFormatUtils.readSpecBytes(specBean, length, inputStream);

            FixedFormatHandler<?> handler = this.lookupFormatHandler(specBean);
            Object value = handler.parse(context, bytes, specBean.getSpec());
            this.setFieldValue(specBean.getField(), instance, value);
        } catch (Exception e) {
            throw new FixedFormatException(FixedFormatCodeEnum.LOAD_ERROR, this.getFieldMessage(specBean.getField()), e);
        }
    }

    protected byte[] exportBytes(FixedFormatContext context, Object input) {
        ByteArrayOutputStream bodyOut = new ByteArrayOutputStream();
        List<FixedSpecBean> specBeanList = FixedFormatUtils.getSpecBeanList(input.getClass());
        for (FixedSpecBean specProperties : specBeanList) {
            Object value = this.getFieldValue(specProperties.getField(), input);
            this.exportBytes(context, input, value, specProperties, bodyOut);
        }
        return bodyOut.toByteArray();
    }

    protected <T> void exportListBytes(FixedFormatContext context, Object input, List<T> valueList, FixedSpecBean specBean, ByteArrayOutputStream out) {
        int size = this.getListSize(specBean.getField(), input);
        if (size > 0) {
            int currentIndex = 0;
            if (valueList != null) {
                for (Object value : valueList) {
                    if (currentIndex < size) {
                        currentIndex++;
                        this.exportObjectBytes(context, input, value, out);
                    } else {
                        break;
                    }
                }
            }
            if (currentIndex < size) {
                Class<?> elementType = ResolvableType.forField(specBean.getField()).getGeneric(0).resolve();
                Object emptyValue = this.createInstance(elementType);
                while (currentIndex < size) {
                    currentIndex++;
                    this.exportObjectBytes(context, input, emptyValue, out);
                }
            }
        } else {
            if (valueList != null) {
                for (Object value : valueList) {
                    this.exportObjectBytes(context, input, value, out);
                }
            }
        }
    }

    @SuppressWarnings("unchecked")
    protected void exportSpecBytes(FixedFormatContext context, Object input, Object value, FixedSpecBean specProperties, ByteArrayOutputStream out) {
        FixedFormatHandler<Object> handler = this.lookupFormatHandler(specProperties);
        byte[] bytes = handler.format(context, input, value, specProperties.getSpec());
        out.writeBytes(bytes);
    }

    protected int getListSize(Field field, Object instance) {
        Loop loop = field.getAnnotation(Loop.class);
        if (loop != null) {
            if (StringUtils.isNotBlank(loop.lengthRef())) {
                Integer length = SpelExpressionUtils.getExpressionValue(loop.lengthRef(), instance, Integer.class);
                return ObjectUtils.defaultIfNull(length, 0);
            } else {
                return loop.length();
            }
        }
        return -1;
    }

    protected int getSpecLength(Spec spec, Object instance) {
        if (StringUtils.isNotBlank(spec.lengthRef())) {
            Integer length = SpelExpressionUtils.getExpressionValue(spec.lengthRef(), instance, Integer.class);
            return ObjectUtils.defaultIfNull(length, 0);
        } else {
            return spec.length();
        }
    }

    protected int getLoopLength(Object instance, Loop loop) {
        if (loop == null) {
            return -1;
        }
        if (StringUtils.isNotBlank(loop.lengthRef())) {
            Integer length = SpelExpressionUtils.getExpressionValue(loop.lengthRef(), instance, Integer.class);
            return ObjectUtils.defaultIfNull(length, 0);
        } else {
            return loop.length();
        }
    }

    private <T> List<T> loadList(FixedFormatContext context, Field field, Class<T> elementType, InputStream input,
            Object instance) {
        int loopLength = this.getListSize(field, instance);
        List<T> result = new ArrayList<>();
        for (int loopIndex = 0; loopIndex < loopLength; loopIndex++) {
            T item = this.loadBytes(context, elementType, input);
            result.add(item);
        }
        return result;
    }

    protected void exportBytes(FixedFormatContext context, Object input, Object value, FixedSpecBean specBean, ByteArrayOutputStream out) {
        if (specBean.getSpec() != null) {
            this.exportSpecBytes(context, input, value, specBean, out);
        } else if (List.class.isAssignableFrom(specBean.getField().getType())) {
            this.exportListBytes(context, input, (List<?>) value, specBean, out);
        } else {
            if (value == null) {
                value = FixedFormatUtils.createObject(specBean.getField().getType());
            }
            this.exportObjectBytes(context, input, value, out);
        }
    }

    private void exportObjectBytes(FixedFormatContext context, Object input, Object target, ByteArrayOutputStream out) {
        List<FixedSpecBean> specBeanList = FixedFormatUtils.getSpecBeanList(target.getClass());
        for (FixedSpecBean specProperties : specBeanList) {
            Object value = this.getFieldValue(specProperties.getField(), target);
            this.exportBytes(context, input, value, specProperties, out);
        }
    }

    protected void registerFormatHandler(Class<?> type, FixedFormatHandler<?> handler) {
        formatHandlerMap.put(type, handler);
    }

    @SuppressWarnings("rawtypes")
    private FixedFormatHandler lookupFormatHandler(FixedSpecBean specProperteis) {
        Class<?> handlerType = specProperteis.getSpec().handler();

        if (handlerType != FixedFormatHandler.class) {
            FixedFormatHandler handler = formatHandlerMap.get(handlerType);
            if (handler == null) {
                handler = (FixedFormatHandler) createInstance(handlerType);
                this.registerFormatHandler(handlerType, handler);
            }
            return handler;
        } else {
            FixedFormatHandler handler = formatHandlerMap.get(specProperteis.getField().getType());
            Assert.notNull(handler, "FormatHandler not found : " + specProperteis.getField().getType());
            return handler;
        }

    }

    private <T> T createInstance(Class<T> type, Object... args) {
        try {
            return ConstructorUtils.invokeConstructor(type);
        } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException | InstantiationException e) {
            throw new IllegalStateException("Not allowed to access constructor '" + type + "': " + e);
        }
    }

    protected Object getFieldValue(Field field, Object target) {
        try {
            return FieldUtils.readField(field, target, true);
        } catch (IllegalAccessException e) {
            throw new IllegalStateException("讀取欄位失敗 : " + getFieldMessage(field), e);
        }
    }

    protected void setFieldValue(Field field, Object instance, Object value) {
        try {
            if (value != null || !field.getType().isPrimitive()) {
                FieldUtils.writeField(field, instance, value, true);
            }
        } catch (IllegalAccessException e) {
            throw new IllegalStateException("Falled to set field '" + field.getName() + "': " + e, e);
        }
    }

    private String getFieldMessage(Field field) {
        return String.format("%s.%s", field.getDeclaringClass().getName(), field.getName());
    }

}
