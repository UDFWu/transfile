package com.ibm.cbmp.fabric.foundation.data.jpa;

import java.util.Arrays;

import javax.persistence.EntityManagerFactory;
import javax.persistence.spi.PersistenceUnitTransactionType;
import javax.sql.DataSource;
import javax.transaction.TransactionManager;
import javax.transaction.UserTransaction;

import org.hibernate.cfg.Environment;
import org.hibernate.engine.transaction.jta.platform.internal.AtomikosJtaPlatform;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.jta.JtaTransactionManager;

import com.atomikos.icatch.jta.UserTransactionImp;
import com.atomikos.icatch.jta.UserTransactionManager;

@Configuration
@ConditionalOnBean(annotation = EnableFabricJpa.class)
@EnableConfigurationProperties
@Import({FabricJpaEnitiesConfiguratioin.class })
public class FabricJpaConfiguration {
    public static final String DATA_SOURCE_NAME = "fabricDataSource";
    public static final String ENTITY_MANAGER_FACTORY_NAME = "fabricEntityManager";
    public static final String TRANSACTION_MANAGER_NAME = "fabricTransactionManager";

    @Value("${fabric.jpa.transaction-type:RESOURCE_LOCAL}")
    private PersistenceUnitTransactionType transactionType;

    @Bean
    @ConditionalOnMissingBean
    FabricDataSourceFactoryBean fabricDataSourceFactoryBean() {
        return new FabricDataSourceFactoryBean();
    }

    @Bean
    @Primary
    FabricPhysicalNamingStrategy fabricPhysicalNamingStrategy() {
        return new FabricPhysicalNamingStrategy();
    }

    @Bean
    @ConfigurationProperties("cbmp.datasource")
    @ConditionalOnMissingBean(name = "fabricDataSourceProperties")
    FabricDataSourceProperties fabricDataSourceProperties() {
        return new FabricDataSourceProperties();
    }

    @Primary
    @Bean(FabricJpaConfiguration.DATA_SOURCE_NAME)
    @FabricDatabase
    @ConditionalOnMissingBean(name = FabricJpaConfiguration.DATA_SOURCE_NAME)
    DataSource fabricDataSource(FabricDataSourceFactoryBean dataSourceFactoryBean) {
        return dataSourceFactoryBean.createDataSource(fabricDataSourceProperties());
    }

    @Primary
    @Bean(FabricJpaConfiguration.ENTITY_MANAGER_FACTORY_NAME)
    @FabricDatabase
    @ConditionalOnMissingBean(name = FabricJpaConfiguration.ENTITY_MANAGER_FACTORY_NAME)
    FabricEntityManagerFactoryBean fabricEntityManager(
            ObjectProvider<FabricJpaConfigurator> jpaConfiguratorProvider,
            @FabricDatabase DataSource dataSource) {
        FabricEntityManagerFactoryBean em = new FabricEntityManagerFactoryBean();
        em.setEnableEntitiesAnnotaionTypes(Arrays.asList(EnableFabricJpaEntities.class));
        switch (transactionType) {
        case JTA:
            em.setJtaDataSource(dataSource);
            em.getJpaPropertyMap().put(Environment.JTA_PLATFORM, AtomikosJtaPlatform.class.getName());
            em.getJpaPropertyMap().put(Environment.JPA_TRANSACTION_TYPE, transactionType.name());
            break;
        case RESOURCE_LOCAL:
            em.setDataSource(dataSource);
            break;
        default:
            throw new IllegalStateException("invalid transaction type : " + transactionType);
        }
        return em;
    }

    @Bean(FabricJpaConfiguration.TRANSACTION_MANAGER_NAME)
    @FabricDatabase
    @ConditionalOnMissingBean(name = FabricJpaConfiguration.TRANSACTION_MANAGER_NAME)
    PlatformTransactionManager fabricTransactionManager(@FabricDatabase EntityManagerFactory entityManagerFactory) {
        switch (transactionType) {
        case JTA:
            return this.jtaTransactionManager();
        case RESOURCE_LOCAL:
            return this.jpaTransactionManager(entityManagerFactory);
        default:
            throw new IllegalStateException("invalid transaction type : " + transactionType);
        }
    }

    PlatformTransactionManager jpaTransactionManager(@FabricDatabase EntityManagerFactory entityManagerFactory) {
        final JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory);
        return transactionManager;
    }

    PlatformTransactionManager jtaTransactionManager() {
        UserTransaction userTransaction = userTransaction();
        TransactionManager atomikosTransactionManager = atomikosTransactionManager();
        return new JtaTransactionManager(userTransaction, atomikosTransactionManager);
    }

    @Bean
    @ConditionalOnProperty(prefix = "fabric.jpa", name = "transaction-type", havingValue = "JTA")
    UserTransaction userTransaction() {
        UserTransactionImp userTransactionImp = new UserTransactionImp();
        return userTransactionImp;
    }

    @Bean(initMethod = "init", destroyMethod = "close")
    @ConditionalOnProperty(prefix = "fabric.jpa", name = "transaction-type", havingValue = "JTA")
    TransactionManager atomikosTransactionManager() {
        UserTransactionManager userTransactionManager = new UserTransactionManager();
        userTransactionManager.setForceShutdown(false);
        return userTransactionManager;
    }

}
