package com.temenos.t24.util;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * 提供T24系統處理加解密的工具
 */
public class AesEncryptUtils {
    public static final String KEY_ALGORITHM = "AES";
    public static final String CIPHER_ALGORITHM = "AES/GCM/NoPadding";
    public static final int KEY_LENGTH = 256;
    public static final int IV_SIZE = 12;

    /**
     * 載入AES要加解密使用的密鑰
     * @param key 密鑰位元組
     * @return 密鑰物件
     */
    public static SecretKey loadSecretKey(byte[] key) {
        return new SecretKeySpec(key, KEY_ALGORITHM);
    }

    /**
     * 產生AES要加解密使用的密鑰, 此方法僅提供測試使用
     * @return 密鑰物件
     */
    public static SecretKey generateSecretKey() throws NoSuchAlgorithmException {
        KeyGenerator keyGenerator = KeyGenerator.getInstance(KEY_ALGORITHM);
        keyGenerator.init(KEY_LENGTH);
        return keyGenerator.generateKey();
    }

    /**
     * 產要加密使用的初始化向量位元組
     * @return 初始化向量位元組
     */
    public static byte[] generateIV() {
        byte[] iv = new byte[IV_SIZE];
        new SecureRandom().nextBytes(iv);
        return iv;
    }

    /**
     * 處理資料加密
     * @param key 密鑰
     * @param iv 初始化向量位元組
     * @param plainBytes 明文位元組
     * @retun 明文加密後的密文位元組
     */
    public static byte[] encrypt(SecretKey key, byte[] iv, byte[] plainBytes)
            throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
        Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(iv.length * 8, iv));
        return cipher.doFinal(plainBytes);
    }

    /**
     * 處理資料加密並轉為base64
     * @param key 密鑰
     * @param iv 初始化向量位元組
     * @param plainBytes 明文位元組
     * @retun 明文加密後的密文
     */
    public static String encryptToBase64(SecretKey key, byte[] iv, byte[] plainBytes)
            throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
        byte[] encryptedBytes = encrypt(key, iv, plainBytes);
        return Base64.getEncoder().encodeToString(encryptedBytes);
    }

    /**
     * 處理資料解密
     * @param key 密鑰
     * @param iv 加密時使用的初始化向量位元組
     * @param 密文位元組
     * @return 解密後的明文位元組
     */
    public static byte[] decrypt(SecretKey key, byte[] iv, byte[] encryptedBytes)
            throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
        Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(iv.length * 8, iv));
        return cipher.doFinal(encryptedBytes);
    }

    /**
     * 處理資料解密
     * @param key 密鑰
     * @param iv 加密時使用的初始化向量位元組
     * @param encryptedText 密文base64格式
     * @return 解密後的明文位元組
     */
    public static byte[] decryptFromBase64(SecretKey key, byte[] iv, String encryptedText)
            throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
        byte[] encryptedBytes = Base64.getDecoder().decode(encryptedText);
        return decrypt(key, iv, encryptedBytes);
    }

    /**
     * 加解密範例
     * @param args
     * @throws Exception
     * @remark
     */
    public static void main(String[] args) throws Exception {
        // 產加要加密測試使用的密錀
        SecretKey testKey = AesEncryptUtils.generateSecretKey();
        // 密錀位元組
        byte[] keyBytes = testKey.getEncoded();

        // 載入要加解密的密鑰
        SecretKey secretKey = AesEncryptUtils.loadSecretKey(keyBytes);
        // 明文
        String plainText = "12345";
        System.out.println("plainText : " + plainText);
        // 加密初始化向量位元組
        byte[] iv = AesEncryptUtils.generateIV();

        // 加密
        String encryptedText = AesEncryptUtils.encryptToBase64(secretKey, iv, plainText.getBytes());
        System.out.println("encryptedText : " + encryptedText);

        // 解密
        byte[] decrypedBytes = AesEncryptUtils.decryptFromBase64(secretKey, iv, encryptedText);
        String decryptedText = new String(decrypedBytes);
        System.out.println("decryptedText : " + decryptedText);
    }

}
