package com.scsb.ncbs.core.data.jpa;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.core.annotation.AliasFor;

/**
 * 啟用EXP JPA Entity
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
@EnableMidEntities(name = MidDatabaseConstants.EXP)
public @interface EnableExpEntities {
    @AliasFor(annotation = EnableMidEntities.class, attribute = "value")
    String[] value() default {};

    @AliasFor(annotation = EnableMidEntities.class, attribute = "basePackages")
    String[] basePackages() default {};

    @AliasFor(annotation = EnableMidEntities.class, attribute = "mappingResources")
    String[] mappingResources() default {};
}
