package com.scsb.ncbs.core.data.jpa;

import java.util.Arrays;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import com.ibm.cbmp.fabric.foundation.data.jpa.FabricDataSourceFactoryBean;
import com.ibm.cbmp.fabric.foundation.data.jpa.FabricDataSourceProperties;
import com.ibm.cbmp.fabric.foundation.data.jpa.FabricEntityManagerFactoryBean;
import com.scsb.ncbs.core.data.jpa.T24JpaAutoConfiguration.T24DataSourceProperties;

@Configuration
@ConditionalOnBean(annotation = EnableT24Jpa.class)
@EnableConfigurationProperties(T24DataSourceProperties.class)
public class T24JpaAutoConfiguration {
    public static final String DATA_SOURCE_NAME = "t24DataSource";
    public static final String ENTITY_MANAGER_FACTORY_NAME = "t24EntityManager";
    public static final String TRANSACTION_MANAGER_NAME = "t24TransactionManager";

    @Autowired
    private FabricDataSourceFactoryBean dataSourceFactoryBean;
    @Autowired
    private T24DataSourceProperties properties;

    @T24Database
    @Bean(DATA_SOURCE_NAME)
    DataSource dataSource() {
        return dataSourceFactoryBean.createDataSource(properties);
    }

    @T24Database
    @Bean(ENTITY_MANAGER_FACTORY_NAME)
    FabricEntityManagerFactoryBean entityManagerFactory() {
        FabricEntityManagerFactoryBean em = new FabricEntityManagerFactoryBean();
        em.setEnableEntitiesAnnotaionTypes(Arrays.asList(EnableT24Entities.class));
        em.setDataSource(dataSource());
        return em;
    }

    @T24Database
    @Bean(TRANSACTION_MANAGER_NAME)
    PlatformTransactionManager transactionManager() {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());
        return transactionManager;
    }

    @ConfigurationProperties("mid.datasource.t24")
    static class T24DataSourceProperties extends FabricDataSourceProperties {

    }

}
