package com.scsb.ncbs.core.repository;

import java.util.stream.Stream;

import javax.persistence.EntityManager;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.NoRepositoryBean;

/**
 * 中台 JpaRepository
 */
@NoRepositoryBean
public interface MidJpaRepository<T, ID> extends JpaRepository<T, ID>, JpaSpecificationExecutor<T> {
    /**
     * 取得JPA EntityManager
     */
    EntityManager getEntityManager();

    Stream<T> streamAll(Specification<T> spec);

    Stream<T> streamAll(Specification<T> spec, int pageSize);
}
