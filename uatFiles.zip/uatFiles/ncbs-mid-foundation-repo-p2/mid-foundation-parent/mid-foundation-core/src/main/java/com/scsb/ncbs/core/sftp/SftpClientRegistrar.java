package com.scsb.ncbs.core.sftp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.config.BeanDefinitionHolder;
import org.springframework.beans.factory.support.AbstractBeanDefinition;
import org.springframework.beans.factory.support.AutowireCandidateQualifier;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.boot.context.properties.bind.Bindable;
import org.springframework.boot.context.properties.bind.Binder;
import org.springframework.core.type.AnnotationMetadata;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.integration.file.FileHeaders;
import org.springframework.integration.sftp.session.DefaultSftpSessionFactory;
import org.springframework.integration.sftp.session.SftpRemoteFileTemplate;

import com.scsb.ncbs.core.configuration.MidBeanDefinitionRegistrar;

/**
 * SftpClientRegistrar
 */
public class SftpClientRegistrar implements MidBeanDefinitionRegistrar<EnableSFTPClient> {
    private static final String SFTP_REMOTE_FILE_TEMPLATE_BEAN_NAME_SUFFIX = ".SftpRemoteFileTemplate";
    private static final String SFTP_SESSION_FACTORY_BEAN_NAME_SUFFIX = ".SftpSessionFactory";
    private static final String SFTP_PROPERTIES_BEAN_NAME_SUFFIX = ".SftpProperties";
    private static final String SFTP_FACTORY_BEAN_NAME = "SFTP_CLIENT_FACTORY_BEAN";

    @Override
    public void registerBeanDefinitions(EnableSFTPClient enableSFTPClient, AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry) {
        if (registry.containsBeanDefinition(enableSFTPClient.name())) {
            return;
        }

        this.registerFactoryBeanDefinition(registry);
        this.registerBeanDefinition(registry, this.getSftpPropertiesBeanDefinition(enableSFTPClient));
        this.registerBeanDefinition(registry, this.getSftpSessionFactoryBeanDefinition(enableSFTPClient));
        this.registerBeanDefinition(registry, this.getSftpRemoteFileTemplateBeanDefinition(enableSFTPClient));
        this.registerBeanDefinition(registry, this.getSftpClientBeanDefinition(enableSFTPClient));
    }

    private void registerFactoryBeanDefinition(BeanDefinitionRegistry registry) {
        if (!registry.containsBeanDefinition(SFTP_FACTORY_BEAN_NAME)) {
            AbstractBeanDefinition beanDefinition = BeanDefinitionBuilder.genericBeanDefinition(FactoryBean.class).getBeanDefinition();
            registry.registerBeanDefinition(SFTP_FACTORY_BEAN_NAME, beanDefinition);
        }
    }

    private void registerBeanDefinition(BeanDefinitionRegistry registry, BeanDefinitionHolder beanDefinitionHolder) {
        registry.registerBeanDefinition(beanDefinitionHolder.getBeanName(), beanDefinitionHolder.getBeanDefinition());
    }

    BeanDefinitionHolder getSftpPropertiesBeanDefinition(EnableSFTPClient enableSFTPClient) {
        BeanDefinitionBuilder beanDefinitionBuilder = BeanDefinitionBuilder.genericBeanDefinition(SftpProperties.class);
        beanDefinitionBuilder.setFactoryMethodOnBean("createSftpProperties", SFTP_FACTORY_BEAN_NAME);
        beanDefinitionBuilder.addConstructorArgValue(enableSFTPClient.configPrefix());
        AbstractBeanDefinition beanDefinition = beanDefinitionBuilder.getBeanDefinition();
        beanDefinition.addQualifier(new AutowireCandidateQualifier(Qualifier.class.getName(), enableSFTPClient.name()));
        beanDefinition.setPrimary(enableSFTPClient.primary());
        return new BeanDefinitionHolder(beanDefinition, enableSFTPClient.name() + SFTP_PROPERTIES_BEAN_NAME_SUFFIX);
    }

    BeanDefinitionHolder getSftpSessionFactoryBeanDefinition(EnableSFTPClient enableSFTPClient) {
        BeanDefinitionBuilder beanDefinitionBuilder = BeanDefinitionBuilder.genericBeanDefinition(DefaultSftpSessionFactory.class);
        beanDefinitionBuilder.setFactoryMethodOnBean("createSftpSessionFactory", SFTP_FACTORY_BEAN_NAME);
        beanDefinitionBuilder.addConstructorArgReference(enableSFTPClient.name() + SFTP_PROPERTIES_BEAN_NAME_SUFFIX);
        AbstractBeanDefinition beanDefinition = beanDefinitionBuilder.getBeanDefinition();
        beanDefinition.addQualifier(new AutowireCandidateQualifier(Qualifier.class.getName(), enableSFTPClient.name()));
        beanDefinition.setPrimary(enableSFTPClient.primary());
        return new BeanDefinitionHolder(beanDefinition, enableSFTPClient.name() + SFTP_SESSION_FACTORY_BEAN_NAME_SUFFIX);
    }

    BeanDefinitionHolder getSftpRemoteFileTemplateBeanDefinition(EnableSFTPClient enableSFTPClient) {
        BeanDefinitionBuilder beanDefinitionBuilder = BeanDefinitionBuilder.genericBeanDefinition(SftpRemoteFileTemplate.class);
        beanDefinitionBuilder.setFactoryMethodOnBean("createSftpRemoteFileTemplate", SFTP_FACTORY_BEAN_NAME);
        beanDefinitionBuilder.addConstructorArgReference(enableSFTPClient.name() + SFTP_SESSION_FACTORY_BEAN_NAME_SUFFIX);
        AbstractBeanDefinition beanDefinition = beanDefinitionBuilder.getBeanDefinition();
        beanDefinition.addQualifier(new AutowireCandidateQualifier(Qualifier.class.getName(), enableSFTPClient.name()));
        beanDefinition.setPrimary(enableSFTPClient.primary());
        return new BeanDefinitionHolder(beanDefinition, enableSFTPClient.name() + SFTP_REMOTE_FILE_TEMPLATE_BEAN_NAME_SUFFIX);
    }

    BeanDefinitionHolder getSftpClientBeanDefinition(EnableSFTPClient enableSFTPClient) {
        BeanDefinitionBuilder beanDefinitionBuilder = BeanDefinitionBuilder.genericBeanDefinition(SftpClient.class);
        beanDefinitionBuilder.setFactoryMethodOnBean("createSftpClient", SFTP_FACTORY_BEAN_NAME);
        beanDefinitionBuilder.addConstructorArgReference(enableSFTPClient.name() + SFTP_REMOTE_FILE_TEMPLATE_BEAN_NAME_SUFFIX);
        AbstractBeanDefinition beanDefinition = beanDefinitionBuilder.getBeanDefinition();
        beanDefinition.addQualifier(new AutowireCandidateQualifier(Qualifier.class.getName(), enableSFTPClient.name()));
        beanDefinition.setPrimary(enableSFTPClient.primary());
        return new BeanDefinitionHolder(beanDefinition, enableSFTPClient.name());
    }

    static class FactoryBean {
        @Autowired
        private Binder binder;

        public SftpProperties createSftpProperties(String prefix) {
            SftpProperties sftpProperties = new SftpProperties();
            binder.bind(prefix, Bindable.ofInstance(sftpProperties));
            return sftpProperties;
        }

        public DefaultSftpSessionFactory createSftpSessionFactory(SftpProperties properties) {
            DefaultSftpSessionFactory factory = new DefaultSftpSessionFactory();
            factory.setHost(properties.getHost());
            factory.setPort(properties.getPort());
            factory.setUser(properties.getUser());
            factory.setPrivateKey(properties.getPrivateKey());
            factory.setPrivateKeyPassphrase(properties.getPrivateKeyPassphrase());
            factory.setPassword(properties.getPassword());
            factory.setAllowUnknownKeys(properties.isAllowUnknownKeys());
            factory.setChannelConnectTimeout(properties.getChannelConnectTimeout());
            factory.setTimeout(properties.getTimeout());
            return factory;
        }

        public SftpRemoteFileTemplate createSftpRemoteFileTemplate(DefaultSftpSessionFactory sessionFactory) {
            SpelExpressionParser parser = new SpelExpressionParser();
            SftpRemoteFileTemplate remoteFileTemplate = new SftpRemoteFileTemplate(sessionFactory);
            remoteFileTemplate.setAutoCreateDirectory(true);
            remoteFileTemplate.setRemoteDirectoryExpression(parser.parseExpression("headers['" + FileHeaders.REMOTE_DIRECTORY + "']"));
            return remoteFileTemplate;
        }

        public SftpClient createSftpClient(SftpRemoteFileTemplate remoteFileTemplate) {
            return new SftpClientImpl(remoteFileTemplate);
        }

    }
}
