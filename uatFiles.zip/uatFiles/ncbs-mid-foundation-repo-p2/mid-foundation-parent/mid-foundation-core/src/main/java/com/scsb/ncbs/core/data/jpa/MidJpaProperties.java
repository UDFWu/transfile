package com.scsb.ncbs.core.data.jpa;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Data;

/**
 * MID JPA 設定Properties
 * @remark
 */
@ConfigurationProperties("mid.jpa.app")
@Data
public class MidJpaProperties {
    /**
     * JPA properties
     */
    private Map<String, String> properties = new HashMap<>();
}
