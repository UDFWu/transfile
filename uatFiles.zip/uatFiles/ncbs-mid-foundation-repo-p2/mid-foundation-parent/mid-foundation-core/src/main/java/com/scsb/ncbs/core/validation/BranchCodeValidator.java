package com.scsb.ncbs.core.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.scsb.ncbs.core.service.BranchCodeService;

/**
 * 分行代碼檢核
 */
public class BranchCodeValidator implements ConstraintValidator<BranchCode, String> {
    @Autowired
    private BranchCodeService branchCodeService;

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (StringUtils.isNotBlank(value)) {
            return branchCodeService.findBranchCode(value).isPresent();
        }
        return true;
    }
}
