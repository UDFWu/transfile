package com.scsb.ncbs.core.service.bean;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 幣別代碼表
 *
 * @author IBM
 * @date 2024/1/18 10:57 AM
 */

@Data
public class CmnCurrencyParm implements Serializable {
    private static final long serialVersionUID = 4447947350253744628L;

    private long listId;

    /**
     * 幣別(代碼)
     */
    private String ccy;

    /**
     * 幣別中文名稱
     */
    private String ccyCh;

    /**
     * 幣別順序
     */
    private Integer ccyOrder;

    /**
     * 金額小數位
     */
    private Integer noOfDecimals;

    /**
     * 兌美金報價方式
     */
    private String quotationCode;

    /**
     * 兌美金報價表示方式
     */
    private String ccyPair;

    /**
     * 是否有現鈔匯率
     */
    private String cashExchgRateExist;

    /**
     * 現鈔買匯加減碼
     */
    private BigDecimal cashExchgRateBuy;

    /**
     * 現鈔賣匯加減碼
     */
    private BigDecimal cashExchgRateSell;

    /**
     * 是否有定期匯率
     */
    private String periodicIntrateExist;

    /**
     * 是否有活期匯率
     */
    private String basicIntrateExist;

    /**
     * 存款利率顯示順序
     */
    private Integer intrateShowOrder;

    /**
     * 啟用鈔櫃註記(Y/N)
     */
    private String enableTillFlag;
}
