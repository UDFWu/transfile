package com.scsb.ncbs.core.configuration;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.config.server.environment.JdbcEnvironmentProperties;
import org.springframework.cloud.config.server.environment.JdbcEnvironmentRepository;
import org.springframework.cloud.config.server.environment.JdbcEnvironmentRepository.PropertiesResultSetExtractor;
import org.springframework.cloud.config.server.environment.JdbcEnvironmentRepositoryFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;

import com.ibm.cbmp.fabric.foundation.data.jpa.FabricDataSourceFactoryBean;
import com.ibm.cbmp.fabric.foundation.data.jpa.FabricDataSourceProperties;

/**
 * 中台Spring Cloud Config 設定
 */
@Order(1)
@Import(MidEncryptableConfiguration.class)
@EnableConfigurationProperties(MidBootstrapDatabaseProperties.class)
@ConditionalOnProperty(prefix = "spring.cloud.config.server", name = "bootstrap", havingValue = "true", matchIfMissing = false)
public class MidConfigBootstrapAutoConfiguration {
    @Bean
    @MidBootstrapDatabase
    JdbcEnvironmentRepository midEnvironmentRepository(
            @MidBootstrapDatabase JdbcEnvironmentRepositoryFactory factory,
            JdbcEnvironmentProperties environmentProperties) {
        return factory.build(environmentProperties);
    }

    @Bean
    @MidBootstrapDatabase
    JdbcEnvironmentRepositoryFactory midEnvironmentRepositoryFactory(
            @MidBootstrapDatabase JdbcTemplate jdbcTemplate,
            @MidBootstrapDatabase PropertiesResultSetExtractor propertiesResultSetExtractor) {
        return new JdbcEnvironmentRepositoryFactory(jdbcTemplate, propertiesResultSetExtractor);
    }

    @Bean
    @MidBootstrapDatabase
    public JdbcEnvironmentRepository.PropertiesResultSetExtractor midPropertiesResultSetExtractor() {
        return new JdbcEnvironmentRepository.PropertiesResultSetExtractor();
    }

    @Bean
    @MidBootstrapDatabase
    DataSource midBootstrapDataSource(MidBootstrapDatabaseProperties properties, Environment environment) {
        FabricDataSourceFactoryBean factoryBean = new FabricDataSourceFactoryBean(environment);
        return factoryBean.createDataSource(properties);
    }

    @Bean
    @MidBootstrapDatabase
    JdbcTemplate midBootstrapJdbcTemplate(@MidBootstrapDatabase DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }
}

@Target({ElementType.FIELD, ElementType.METHOD, ElementType.PARAMETER, ElementType.TYPE, ElementType.ANNOTATION_TYPE })
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Qualifier
@interface MidBootstrapDatabase {

}

@ConfigurationProperties("mid.datasource.bootstrap")
class MidBootstrapDatabaseProperties extends FabricDataSourceProperties {
}
