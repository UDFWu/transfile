package com.scsb.ncbs.core.checker;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.ibm.cbmp.fabric.foundation.enums.api.ApiCodeEnum;
import com.ibm.cbmp.fabric.foundation.exception.BeanValidationException;
import com.ibm.cbmp.fabric.foundation.exception.ExceptionUtils;
import com.ibm.cbmp.fabric.foundation.facade.bean.ApiValidationMessage;
import com.ibm.cbmp.fabric.foundation.toolkit.ApiValidationUtils;
import com.ibm.cbmp.fabric.foundation.toolkit.CastUtils;
import com.scsb.ncbs.core.enums.CodeEnum;
import com.scsb.ncbs.core.mcs.MidRequestContext;
import com.scsb.ncbs.core.service.bean.MidServiceHeader;
import com.scsb.ncbs.core.utils.MidMessageUtils;
import com.scsb.ncbs.core.utils.MidStringUtils;

/**
 * <p>
 *
 * @PreCheck AOP
 *           </p>
 *           <p>
 *           添加在Service的Method上，發生於進入service前
 *           </p>
 *           <p>
 *           分為“嚴重錯誤”與“輕微錯誤”，前者會立即拋出錯誤、後者會疊加累計後一次回傳
 *           </p>
 *           <p>
 *           發生“嚴重錯誤”時，不論先前是否有輕微錯誤，都會只回傳“嚴重錯誤”
 *           </p>
 *           <p>
 *           需求訂立中的“嚴重錯誤”使用MidMessageUtils.raiseTxError
 *           </p>
 *           <p>
 *           需求訂立中的“輕微錯誤”使用errorList.add(new BeanValidationException.Error(${code},${error message}
 *           </p>
 *           <p>
 *           交易個別的欄位檢查後才會進行統一檢查(主管授權等等)
 *           </p>
 */
@Aspect
@Component
public class PreCheckAspect {
    private Map<PreCheck, List<PreChecker>> checkerListMap = new ConcurrentHashMap<>();

    @Autowired
    private ApplicationContext applicationContext;

    @Around(value = "@annotation(preCheck)", argNames = "point,preCheck")
    public Object around(ProceedingJoinPoint point, PreCheck preCheck) throws Throwable {
        MidRequestContext requestContext = MidRequestContext.getInstance();
        MidServiceHeader apiRequest = new MidServiceHeader(requestContext.getRequestHeader(), requestContext.getServiceInfo());
        List<BeanValidationException.Error> errorList = new ArrayList<>();
        PreCheck.supervisorLv supervisorLv = preCheck.supervisorLv();
        doCustomCheck(point, preCheck, supervisorLv, errorList);
        doSupervisorCheck(apiRequest, supervisorLv);
        doFinalCheck(apiRequest, errorList);
        return point.proceed();
    }

    private void doCustomCheck(JoinPoint point, PreCheck preCheck, PreCheck.supervisorLv supervisorLv,
            List<BeanValidationException.Error> errorList) {

        MidRequestContext requestContext = MidRequestContext.getInstance();
        CheckerBean preCheckerBean = new CheckerBean();
        preCheckerBean.setApiRequestHeader(requestContext.getRequestHeader());
        preCheckerBean.setErrorList(errorList);
        preCheckerBean.setMethodName(point.getSignature().getName());
        preCheckerBean.setArgs(point.getArgs());
        preCheckerBean.setPageable(requestContext.getPageable());
        preCheckerBean.setServiceInfo(requestContext.getServiceInfo());
        preCheckerBean.setSupervisorLv(supervisorLv);

        for (PreChecker checker : this.getCheckerList(preCheck)) {
            checker.valid(preCheckerBean);
        }

    }

    private void doSupervisorCheck(MidServiceHeader apiRequest, PreCheck.supervisorLv supervisorLv) {
        String supervisorAId = apiRequest.getHeader().getSupervisorAId();
        String supervisorBId = apiRequest.getHeader().getSupervisorBId();

        switch (supervisorLv) {
        case NONE:
            break;
        case SUPERVISOR_A:
            if (MidStringUtils.isBlank(supervisorAId)) {
                MidMessageUtils.raiseTxError(CodeEnum.SUPERVISOR_A);
            }
            break;

        case SUPERVISOR_B:
            if (MidStringUtils.isBlank(supervisorAId) && MidStringUtils.isBlank(supervisorBId)) {
                MidMessageUtils.raiseTxError(CodeEnum.SUPERVISOR_B);
            }
            break;

        case BOTH:
            if (MidStringUtils.isBlank(supervisorAId) || MidStringUtils.isBlank(supervisorBId)) {
                MidMessageUtils.raiseTxError(CodeEnum.SUPERVISOR_AB);
            }
            break;
        }
    }

    private void doFinalCheck(MidServiceHeader apiRequest, List<BeanValidationException.Error> errorList) {
        List<ApiValidationMessage> validationMessages = CastUtils.cast(errorList);
        // if list not null, throw exception
        if (ApiValidationUtils.containsErrorMessage(validationMessages)) {
            throw new BeanValidationException(ApiCodeEnum.INVALID_PARAMETER, errorList);
        }

        if (MidStringUtils.equals(apiRequest.getHeader().getValidFlag(), "Y")) {
            // if header.valid = "Y" , exit trans
            ExceptionUtils.raiseTxException(CodeEnum.OK, errorList);
        } else if (!errorList.isEmpty()) {
            ApiValidationUtils.setApiValidationMessages(validationMessages);
        }
    }

    private List<PreChecker> getCheckerList(PreCheck preCheck) {
        return checkerListMap.computeIfAbsent(preCheck, key -> {
            if (key.value().length > 0) {
                return Stream.of(preCheck.value())
                        .map(applicationContext::getBean)
                        .map(PreChecker.class::cast)
                        .collect(Collectors.toList());
            } else {
                return Stream.of(preCheck.checkerName())
                        .map(applicationContext::getBean)
                        .map(PreChecker.class::cast)
                        .collect(Collectors.toList());
            }
        });
    }

}