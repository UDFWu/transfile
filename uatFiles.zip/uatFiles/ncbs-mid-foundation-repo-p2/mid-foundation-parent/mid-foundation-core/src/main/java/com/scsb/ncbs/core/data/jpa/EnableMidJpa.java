package com.scsb.ncbs.core.data.jpa;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.context.annotation.Import;

/**
 * 用來啟用中台JPA設定
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Import(MidJpaRegistrar.class)
@Repeatable(EnableMidJpa.List.class)
public @interface EnableMidJpa {
    /**
     * JPA設定檔名稱
     */
    String name() default "";

    /**
     * 要參考的DataSource，未設定此值時會自動註冊一個新的DataSousrce
     */
    String datasource() default "";

    /**
     * 註冊Bean時預設會使用name屬性當作qualifier, 若有額外設定其他的qualifier值時，可利用此屬性設定
     */
    String[] qualifiers() default {};

    /**
     * 同qualifiers設定
     */
    Class<?>[] qualifierClasses() default {};

    /**
     * 是否為PrimaryBean
     */
    boolean primary() default false;

    /**
     * Defines several constraints on the same element.
     */
    @Target({TYPE, ANNOTATION_TYPE })
    @Retention(RUNTIME)
    @Documented
    @Import({MidJpaRegistrar.class })
    public @interface List {
        EnableMidJpa[] value();
    }
}
