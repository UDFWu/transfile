package com.scsb.ncbs.core.threadlocal;

import com.ibm.cbmp.fabric.foundation.facade.bean.ApiRequestHeader;
import com.scsb.ncbs.core.mcs.MidRequestContext;

/**
 * ApiRequestHeader ThreadLocal
 */
public class RequestHeaderThreadLocal {
    /**
     * 
     * @return
     */
    public static ApiRequestHeader get() {
        return MidRequestContext.getInstance().getRequestHeader();
    }

    public static void set(ApiRequestHeader apiRequestHeader) {
        MidRequestContext.getInstance().setRequestHeader(apiRequestHeader);
    }
}
