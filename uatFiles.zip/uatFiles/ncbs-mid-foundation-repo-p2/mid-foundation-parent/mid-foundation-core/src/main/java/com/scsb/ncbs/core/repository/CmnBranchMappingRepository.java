package com.scsb.ncbs.core.repository;

import com.scsb.ncbs.core.entity.CmnBranchMappingEntity;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CmnBranchMappingRepository extends MidJpaRepository<CmnBranchMappingEntity, Long> {
    // 使用5碼數字(通常為總行+部門)進行搜尋
    Optional<CmnBranchMappingEntity> findByBranchCode(String branchCode);

    // 使用字軌(2碼英文代碼)進行搜尋
    Optional<CmnBranchMappingEntity> findByCbrCode(String cbrCode);

    // 使用T24分行代碼進行搜尋
    Optional<CmnBranchMappingEntity> findByT24CompanyId(String t24CompanyId);

    // 查詢出所有 T24CompanyId is not null的資料
    Optional<List<CmnBranchMappingEntity>> findAllByT24CompanyIdIsNotNull();
}
