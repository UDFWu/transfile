package com.scsb.ncbs.core.service.bean;

import java.io.Serializable;

import lombok.Data;

/**
 * 分行字軌代碼表
 *
 * @author IBM
 * @date 2024/1/18 10:57 AM
 */
@Data
public class CmnBranchCode implements Serializable {
    private static final long serialVersionUID = 4447947350253744628L;
    /**
     * DBU
     */
    public static final String DBU = "99901";
    /**
     * OBU
     */
    public static final String OBU = "02700";
    /**
     * OBU境內法人
     */
    public static final String OBU_LEGAL_PERSON = "99902";

    private long listId;

    /**
     * 分行代碼
     */
    private String branchCode;

    /**
     * 簡碼
     */
    private String shortCode;

    /**
     * 分行字軌
     */
    private String cbrCode;

    /**
     * 分行名稱
     */
    private String branchName;

    /**
     * 分行英文名稱
     */
    private String branchEngName;

    /**
     * 統轄行註記
     */
    private String mgmBrFlag;

    /**
     * 行政區代碼
     */
    private String division;

    /**
     * 區域中心代碼
     */
    private String area;

    /**
     * T24分行代碼
     */
    private String t24CompanyId;

    /**
     * 所屬統轄行編號
     * 20250808 Update: 因 DEP 調整，從 supervisoryBankCode 改為 supervisoryCode
     */
    private String supervisoryCode;

    /**
     * 退票行區碼
     */
    private String returnBankAreaCode;

    /**
     * 檢查碼
     */
    private String checkNo;

    /**
     * 上海銀行代碼
     */
    private String localBankCode;

    /**
     * 三碼分行外加檢查碼
     */
    private String localBranchCode;
}
