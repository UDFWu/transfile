package com.scsb.ncbs.core.mcs;

import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import com.ibm.cbmp.fabric.foundation.facade.bean.ApiRequest;
import com.ibm.cbmp.fabric.foundation.facade.bean.ServiceRq;
import com.ibm.cbmp.fabric.foundation.mcs.advice.IMcsAdvice;
import com.ibm.cbmp.fabric.foundation.mcs.advice.McsExecution;
import com.ibm.cbmp.fabric.foundation.toolkit.CastUtils;
import com.scsb.ncbs.core.log.LogConstants;

@Component
public class MidContextInitialAdvice implements IMcsAdvice {
    @Override
    public void invoke(McsExecution execution) {
        this.initialApiHeader(execution);
        this.initialServiceRq(execution);
        this.initialRequestContext(execution);
    }

    private void initialApiHeader(McsExecution execution) {
        execution.getApiRequest()
                .map(ApiRequest::getHeader)
                .ifPresent(header -> {
                    MDC.put(LogConstants.GUID, header.getGuid());
                    MDC.put(LogConstants.TELLER_ID, header.getTellerId());
                    MDC.put(LogConstants.CLIENT_SEQ_NO, header.getClientSeqNo());
                    MDC.put(LogConstants.TX_SEQ_NO, header.getTxSeqNo());
                });
    }

    private void initialServiceRq(McsExecution execution) {
        execution.getApiRequest()
                .map(ApiRequest::getServiceRq)
                .filter(ServiceRq.class::isInstance)
                .map(ServiceRq.class::cast)
                .map(ServiceRq::getServiceInfo)
                .ifPresent(serviceRqInfo -> {
                    execution.setTxCode(serviceRqInfo.getTxnCode());
                });
    }

    private void initialRequestContext(McsExecution execution) {
        execution.getApiRequest().ifPresent(request -> {
            MidRequestContext.getInstance().init(CastUtils.cast(request));
        });
    }

}
