package com.scsb.ncbs.core.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.scsb.ncbs.core.jasypt.MidJasyptPropertySourceFactory;
import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;

/**
 * Annotation that enables Jasypt for properties decryption by annotating {@link Configuration} classes
 */
@Target({ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
@EnableEncryptableProperties
@PropertySource(value = "classpath:mid-encrypted.properties", factory = MidJasyptPropertySourceFactory.class)
public @interface EnableMidEncryptableProperties {

}
