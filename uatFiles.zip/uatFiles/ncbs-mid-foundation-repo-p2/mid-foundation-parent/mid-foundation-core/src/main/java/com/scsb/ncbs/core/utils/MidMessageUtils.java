package com.scsb.ncbs.core.utils;

import java.util.function.Supplier;

import com.ibm.cbmp.fabric.foundation.enums.IReturnCodeDescEnum;
import com.ibm.cbmp.fabric.foundation.exception.AuthorizationException;
import com.ibm.cbmp.fabric.foundation.exception.FabricException;
import com.ibm.cbmp.fabric.foundation.exception.TxnException;
import com.ibm.cbmp.fabric.foundation.exception.VerificationException;
import com.scsb.ncbs.core.enums.AuthorizationLevelEnum;

/**
 * API 訊息共用函式
 *
 * @author IBM
 * @date 2022/10/25 下午 12:01
 */
public class MidMessageUtils {
    MidMessageUtils() {
    }

    /**
     * 交易邏輯異常Exception
     * @param codeEnum 錯誤代碼Enum
     */
    public static void raiseTxError(IReturnCodeDescEnum codeEnum) {
        throw new TxnException(codeEnum);
    }

    /**
     * 交易邏輯異常Exception
     * @param cause 發生異常時的Exception
     * @param codeEnum 錯誤代碼Enum
     */
    public static void raiseTxError(Throwable cause, IReturnCodeDescEnum codeEnum) {
        throw new TxnException(codeEnum, cause);
    }

    /**
     * 交易邏輯異常Exception
     * @param codeEnum 錯誤代碼Enum
     * @param args 訊息參數
     */
    public static void raiseTxError(IReturnCodeDescEnum codeEnum, Object... args) {
        throw new TxnException(codeEnum, args);
    }

    public static Supplier<TxnException> raiseTxErrorSupp(IReturnCodeDescEnum codeEnum) {
        return () -> new TxnException(codeEnum);
    }

    public static Supplier<TxnException> raiseTxErrorSupp(IReturnCodeDescEnum codeEnum, Object... args) {
        return () -> new TxnException(codeEnum, args);
    }

    public static void raiseFabricError(IReturnCodeDescEnum codeEnum) {
        throw new FabricException(codeEnum);
    }

    public static void raiseVerificationError(IReturnCodeDescEnum codeEnum) {
        throw new VerificationException(codeEnum);
    }

    /**
     * A級主管授權Exception
     */
    public static void raiseAuthorizationErrorA(IReturnCodeDescEnum codeEnum, Object... args) {
        throw new AuthorizationException(codeEnum, AuthorizationLevelEnum.A.getCode(), args);
    }

    /**
     * B級主管授權Exception
     */
    public static void raiseAuthorizationErrorB(IReturnCodeDescEnum codeEnum, Object... args) {
        throw new AuthorizationException(codeEnum, AuthorizationLevelEnum.B.getCode(), args);
    }

    /**
     * A+B級主管授權Exception
     */
    public static void raiseAuthorizationErrorAB(IReturnCodeDescEnum codeEnum, Object... args) {
        throw new AuthorizationException(codeEnum, AuthorizationLevelEnum.AB.getCode(), args);
    }

    /**
     * A級主管授權Exception
     */
    public static void raiseAuthorizationErrorWithDetailA(IReturnCodeDescEnum codeEnum, Object detail, Object... args) {
        throw new AuthorizationException(codeEnum, AuthorizationLevelEnum.A.getCode(), detail, args);
    }

    /**
     * B級主管授權Exception
     */
    public static void raiseAuthorizationErrorWithDetailB(IReturnCodeDescEnum codeEnum, Object detail, Object... args) {
        throw new AuthorizationException(codeEnum, AuthorizationLevelEnum.B.getCode(), detail, args);
    }

    /**
     * A+B級主管授權Exception
     */
    public static void raiseAuthorizationErrorWithDetailAB(IReturnCodeDescEnum codeEnum, Object detail, Object... args) {
        throw new AuthorizationException(codeEnum, AuthorizationLevelEnum.AB.getCode(), detail, args);
    }
}
