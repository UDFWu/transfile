package com.scsb.ncbs.core.threadlocal;

import com.ibm.cbmp.fabric.foundation.facade.bean.ServiceInfo;
import com.scsb.ncbs.core.mcs.MidRequestContext;

/**
 * ServiceInfo ThreadLocal
 */
public class ServiceInfoThreadLocal {
    /**
     * 
     * @return
     */
    public static ServiceInfo get() {
        return MidRequestContext.getInstance().getServiceInfo();
    }

    public static void set(ServiceInfo serviceInfo) {
        MidRequestContext.getInstance().setServiceInfo(serviceInfo);
    }
}
