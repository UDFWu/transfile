package com.scsb.ncbs.core.data.jpa;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.core.annotation.AliasFor;

/**
 * 啟用中EXP JPA Repository
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
@EnableMidRepositories(name = MidDatabaseConstants.EXP)
public @interface EnableExpRepositories {
    @AliasFor(annotation = EnableMidRepositories.class)
    String[] value() default {};

    @AliasFor(annotation = EnableMidRepositories.class)
    String[] basePackages() default {};
}
