package com.scsb.ncbs.core.enums;

import com.ibm.cbmp.fabric.foundation.enums.ICodeDescEnum;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * @description 刪除標誌
 *
 */
@RequiredArgsConstructor
@Getter
public enum DeletedFlagEnum implements ICodeDescEnum {
    /** 已刪除 */
    Y("1", "已刪除"),

    /** 未刪除 */
    N("0", "未刪除"),;

    private final String code;

    private final String desc;
}
