package com.scsb.ncbs.core.utils;

import java.nio.charset.Charset;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.CaseUtils;

/**
 * String字串共用函式
 *
 * @author IBM
 * @date 2022/10/25 上午 10:42
 */
public class MidStringUtils extends StringUtils {
    private static final Map<Charset, Float> maxBytesPerCharMap = new ConcurrentHashMap<>();

    /**
     * &
     */
    public static final String AND = "&";
    /**
     * carriage return 字元
     */
    public static final String CARRIAGE_RETURN = "\r";
    /**
     * 次方
     */
    public static final String CIRCUMFLEX = "^";
    /**
     * 冒號
     */
    public static final String COLON = ":";
    /**
     * 逗號
     */
    public static final String COMMA = ",";
    /**
     * DEFAULT_REMARKS_FORMAT
     */
    public static final String DEFAULT_REMARKS_FORMAT = " \r\n \r\n \r\n \r\n";
    /**
     * DEFAULT_TWO_REMARKS_FORMAT
     */
    public static final String DEFAULT_TWO_REMARKS_FORMAT = " \r\n \r\n";
    /**
     * 點
     */
    public static final String DOT = ".";
    /**
     * 兩條斜線
     */
    public static final String DOUBLE_SLASH = "//";
    /**
     * 空值
     */
    public static final String EMPTY = "";
    /**
     * 等於
     */
    public static final String EQUAL = "=";
    /**
     * 井字號
     */
    public static final String HASH_TAG = "#";
    /**
     * 連字號
     */
    public static final String HYPHEN = "-";
    /**
     * 左大括號
     */
    public static final String LEFT_BRACES = "\\{";
    /**
     * 多行分隔符號
     */
    public static final String MULTI_LINE_SEPARATOR = "\n";
    /**
     * 換行
     */
    public static final String NEW_LINE = "\r\n";
    /**
     * +字號
     */
    public static final String PLUS = "+";
    /**
     * 右大括號
     */
    public static final String RIGHT_BRACES = "\\}";
    /**
     * 分號
     */
    public static final String SEMICOLON = ";";
    /**
     * 斜線
     */
    public static final String SLASH = "/";
    /**
     * 空白符號
     */
    public static final String SPACE = " ";
    /**
     * 米字號
     */
    public static final String STAR = "*";
    /**
     * Tab
     */
    public static final String TAB = "\t";
    /**
     * 底線
     */
    public static final String UNDER_LINE = "_";
    /**
     * 垂直
     */
    public static final String VERTICAL = "|";

    public static boolean contains(CharSequence seq, CharSequence searchSeq) {
        return StringUtils.contains(seq, searchSeq);
    }

    public static <T extends CharSequence> T defaultIfBlank(T str, T defaultStr) {
        return StringUtils.defaultIfBlank(str, defaultStr);
    }

    public static String defaultString(String str) {
        return StringUtils.defaultString(str, "");
    }

    public static String defaultString(String str, String defaultStr) {
        return StringUtils.defaultString(str, defaultStr);
    }

    public static boolean equals(CharSequence cs1, CharSequence cs2) {
        return StringUtils.equals(cs1, cs2);
    }

    public static boolean equalsIgnoreCase(CharSequence cs1, CharSequence cs2) {
        return StringUtils.equalsIgnoreCase(cs1, cs2);
    }

    public static String formatDynamicString(String formatStr, String... args) {
        if (isEmpty(formatStr) || args == null)
            return formatStr;
        for (String arg : args)
            formatStr = formatStr.replaceFirst(LEFT_BRACES + RIGHT_BRACES, arg);
        return formatStr;
    }

    public static int getRepeatCount(String str, String repeat) {
        if (str == null)
            return 0;

        int count = 0;
        int idx = 0;
        while (true) {
            idx = StringUtils.indexOf(str, repeat, idx);

            if (idx == -1)
                break;

            idx++;
            count++;
        }

        return count;
    }

    public static boolean isEmpty(CharSequence css) {
        return StringUtils.isEmpty(css);
    }

    public static boolean isNoneBlank(CharSequence... css) {
        return !isAnyBlank(css);
    }

    public static boolean isNoneEmpty(CharSequence... css) {
        return !isAnyEmpty(css);
    }

    public static boolean isNotBlank(CharSequence cs) {
        return !isBlank(cs);
    }

    public static boolean isNotEmpty(CharSequence cs) {
        return !isEmpty(cs);
    }

    public static boolean isNumeric(CharSequence cs) {
        return StringUtils.isNumeric(cs);
    }

    public static String joinWith(String delimiter, Object... array) {
        return StringUtils.joinWith(delimiter, array);
    }

    /**
     * 計算全形在字串中, 有幾個字
     * 
     * @param str
     * @return
     */
    public static int lengthForFullwidth(String str) {
        if (str == null)
            return 0;

        int fullwidthLength = 0;

        char[] chars = str.toCharArray();

        for (int i = 0; i < chars.length; i++) {
            int value = chars[i];

            if (value < 32 || value > 126)
                fullwidthLength++;
        }

        return fullwidthLength;
    }

    public static void replaceNewLine(Object... obj) {
        int index = 0;
        if (obj != null)
            for (Object sourceObject : obj) {
                if (sourceObject != null && MidStringUtils.isNotBlank(sourceObject.toString())
                        && sourceObject instanceof String)
                    obj[index] = sourceObject.toString().replaceAll(MULTI_LINE_SEPARATOR, "")
                            .replaceAll(CARRIAGE_RETURN, "");
                index++;
            }
    }

    public static String substring(String str, int start, int end) {
        return StringUtils.substring(str, start, end);
    }

    public static String substringByFullWidth(String str, int start, int length) {
        char[] chars = str.toCharArray();

        StringBuilder builder = new StringBuilder();

        int idx = start;
        for (int i = start; i < start + length; i++) {
            char c = chars[idx++];

            builder.append(c);

            if (c < 32 || c > 126)
                i++;
        }

        return builder.toString();
    }

    public static String toCamelCase(String str, boolean isCapitalizeFirstLetter) {
        return CaseUtils.toCamelCase(str, isCapitalizeFirstLetter, '_');
    }

    public static String toDefaultCamelCase(String str) {
        return CaseUtils.toCamelCase(str, false);
    }

    /**
     * 判斷是否包含全型字元
     * @param value 輸入的字串
     * @return true 有全型字元
     */
    public static boolean containFullWidth(String value) {
        if (StringUtils.isEmpty(value)) {
            return false;
        }
        for (char c : value.toCharArray()) {
            if (isFullWidth(c)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 判斷是否包含半型字元
     * @param value 輸入的字串
     * @return true 有半型字元
     */
    public static boolean containHalfWidth(String value) {
        if (StringUtils.isEmpty(value)) {
            return false;
        }
        for (char c : value.toCharArray()) {
            if (isHalfWidth(c)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 判斷是否為全型字元
     * @param c char
     * @return true 全型字元
     */
    public static boolean isFullWidth(char c) {
        Character.UnicodeBlock ub = Character.UnicodeBlock.of(c);
        return (ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS
                || ub == Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS
                || ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A
                || ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_B
                || ub == Character.UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION
                || ub == Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS
                || ub == Character.UnicodeBlock.GENERAL_PUNCTUATION);
    }

    /**
     * 判斷是否為半型字元
     * @param c char
     * @return true 半型字元
     */
    public static boolean isHalfWidth(char c) {
        return !isFullWidth(c);
    }

    /**
     * 轉換成全型字串
     * @param value 要轉換的字串
     * @return 全型字串
     */
    public static String convertToFullWidth(String value) {
        if (StringUtils.isEmpty(value)) {
            return value;
        }
        char[] arr = value.toCharArray();
        for (int i = 0; i < arr.length; ++i) {
            int charValue = arr[i];
            if (charValue >= 33 && charValue <= 126) {
                arr[i] = (char) (charValue + 65248);
            } else if (charValue == 32) {
                arr[i] = (char) 12288;
            }
        }
        return new String(arr);
    }

    /**
     * 轉換成半型字串
     * @param value 要轉換的字串
     * @return 半型字串
     */
    public static String convertToHalfWidth(String value) {
        if (StringUtils.isEmpty(value)) {
            return value;
        }
        char[] charArray = value.toCharArray();
        // 對全形字元轉換的char陣列遍歷
        for (int i = 0; i < charArray.length; i++) {
            int charIntValue = charArray[i];
            // 如果符合轉換關係,將對應下標之間減掉偏移量65248;如果是空格的話,直接做轉換
            if (charIntValue >= 65281 && charIntValue <= 65374) {
                charArray[i] = (char) (charIntValue - 65248);
            } else if (charIntValue == 12288) {
                charArray[i] = (char) 32;
            }
        }
        return new String(charArray);
    }

    /**
     * 截斷超過最大長度的字串
     * @param input 輸入字串
     * @param maxByteLenth 最大長度
     * @param charset 字元集
     * @return 截斷後的字串
     */
    public static String truncate(String input, int maxByteLenth, Charset charset) {
        if (input != null && input.length() * getMaxBytesPerChar(charset) > maxByteLenth) {
            byte[] bytes = input.getBytes(charset);
            if (bytes.length > maxByteLenth) {
                return new String(bytes, 0, maxByteLenth, charset);
            }
        }
        return input;
    }

    private static float getMaxBytesPerChar(Charset charset) {
        return maxBytesPerCharMap.computeIfAbsent(charset, key -> {
            return key.newEncoder().maxBytesPerChar();
        });
    }
}
