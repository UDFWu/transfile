package com.scsb.ncbs.core.log;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConditionalOnProperty(prefix = "mid", name = "enable-aop-logging", havingValue = "true")
public class MidLogAutoConfiguration {
    @Bean
    MidControllerMethodLogAspect midControllerMethodLogAspect() {
        return new MidControllerMethodLogAspect();
    }

    @Bean
    MidServiceMethodLogAspect midServiceMethodLogAspect() {
        return new MidServiceMethodLogAspect();
    }

}
