package com.scsb.ncbs.core.data.jpa;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.core.annotation.AliasFor;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * Describes a transaction attribute on an individual method or on a class.
 */
@Target({ElementType.TYPE, ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
@MidTransactional(transactionManager = MidDatabaseConstants.EXP)
public @interface ExpTransactional {
    /**
     * The transaction propagation type.
     * <p>
     * Defaults to {@link Propagation#REQUIRED}.
     * @see org.springframework.transaction.interceptor.TransactionAttribute#getPropagationBehavior()
     */
    @AliasFor(annotation = MidTransactional.class, attribute = "propagation")
    Propagation propagation() default Propagation.REQUIRED;

    /**
     * The transaction isolation level.
     * <p>
     * Defaults to {@link Isolation#DEFAULT}.
     * <p>
     * Exclusively designed for use with {@link Propagation#REQUIRED} or {@link Propagation#REQUIRES_NEW} since it only applies to newly started transactions. Consider switching the
     * "validateExistingTransactions" flag to "true" on your transaction manager if you'd like isolation level declarations to get rejected when participating in an existing transaction with a
     * different isolation level.
     * @see org.springframework.transaction.interceptor.TransactionAttribute#getIsolationLevel()
     * @see org.springframework.transaction.support.AbstractPlatformTransactionManager#setValidateExistingTransaction
     */
    @AliasFor(annotation = MidTransactional.class, attribute = "isolation")
    Isolation isolation() default Isolation.DEFAULT;

    /**
     * A boolean flag that can be set to {@code true} if the transaction is effectively read-only, allowing for corresponding optimizations at runtime.
     * <p>
     * Defaults to {@code false}.
     * <p>
     * This just serves as a hint for the actual transaction subsystem; it will <i>not necessarily</i> cause failure of write access attempts. A transaction manager which cannot interpret the
     * read-only hint will <i>not</i> throw an exception when asked for a read-only transaction but rather silently ignore the hint.
     * @see org.springframework.transaction.interceptor.TransactionAttribute#isReadOnly()
     * @see org.springframework.transaction.support.TransactionSynchronizationManager#isCurrentTransactionReadOnly()
     */
    @AliasFor(annotation = MidTransactional.class, attribute = "readOnly")
    boolean readOnly() default false;

    /**
     * Defines zero (0) or more exception {@linkplain Class classes}, which must be subclasses of {@link Throwable}, indicating which exception types must cause a transaction rollback.
     * <p>
     * By default, a transaction will be rolled back on {@link RuntimeException} and {@link Error} but not on checked exceptions (business exceptions). See
     * {@link org.springframework.transaction.interceptor.DefaultTransactionAttribute#rollbackOn(Throwable)} for a detailed explanation.
     * <p>
     * This is the preferred way to construct a rollback rule (in contrast to {@link #rollbackForClassName}), matching the exception type, its subclasses, and its nested classes. See the
     * {@linkplain Transactional class-level javadocs} for further details on rollback rule semantics and warnings regarding possible unintentional matches.
     * @see #rollbackForClassName
     * @see org.springframework.transaction.interceptor.RollbackRuleAttribute#RollbackRuleAttribute(Class)
     * @see org.springframework.transaction.interceptor.DefaultTransactionAttribute#rollbackOn(Throwable)
     */
    @AliasFor(annotation = MidTransactional.class, attribute = "rollbackFor")
    Class<? extends Throwable>[] rollbackFor() default {};

    /**
     * Defines zero (0) or more exception {@link Class Classes}, which must be subclasses of {@link Throwable}, indicating which exception types must <b>not</b> cause a transaction rollback.
     * <p>
     * This is the preferred way to construct a rollback rule (in contrast to {@link #noRollbackForClassName}), matching the exception type, its subclasses, and its nested classes. See the
     * {@linkplain Transactional class-level javadocs} for further details on rollback rule semantics and warnings regarding possible unintentional matches.
     * @see #noRollbackForClassName
     * @see org.springframework.transaction.interceptor.NoRollbackRuleAttribute#NoRollbackRuleAttribute(Class)
     * @see org.springframework.transaction.interceptor.DefaultTransactionAttribute#rollbackOn(Throwable)
     */
    @AliasFor(annotation = MidTransactional.class, attribute = "noRollbackFor")
    Class<? extends Throwable>[] noRollbackFor() default {};
}
