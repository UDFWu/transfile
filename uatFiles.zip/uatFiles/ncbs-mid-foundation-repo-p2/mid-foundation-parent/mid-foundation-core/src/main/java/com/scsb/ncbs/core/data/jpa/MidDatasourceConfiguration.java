package com.scsb.ncbs.core.data.jpa;

import javax.sql.DataSource;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.ibm.cbmp.fabric.foundation.data.jpa.FabricDataSourceFactoryBean;
import com.ibm.cbmp.fabric.foundation.data.jpa.FabricDataSourceProperties;
import com.ibm.cbmp.fabric.foundation.data.jpa.FabricDatabase;
import com.ibm.cbmp.fabric.foundation.data.jpa.FabricJpaConfiguration;
import com.scsb.ncbs.core.data.jpa.MidDatasourceConfiguration.MidAppDataSourceProperties;

/**
 * Mid Datasource 設定
 */
@Configuration
@EnableConfigurationProperties(MidAppDataSourceProperties.class)
public class MidDatasourceConfiguration {
    public static final String DATA_SOURCE_NAME = FabricJpaConfiguration.DATA_SOURCE_NAME;

    @Bean
    @ConditionalOnMissingBean
    FabricDataSourceFactoryBean midDataSourceFactoryBean() {
        return new FabricDataSourceFactoryBean();
    }

    @Primary
    @Bean(DATA_SOURCE_NAME)
    @FabricDatabase
    @MidDatabase
    @ConditionalOnMissingBean(name = DATA_SOURCE_NAME)
    DataSource midDataSource(MidAppDataSourceProperties properties) {
        FabricDataSourceFactoryBean dataSourceFactoryBean = midDataSourceFactoryBean();
        return dataSourceFactoryBean.createDataSource(properties);
    }

    @Primary
    @Bean
    @FabricDatabase
    @MidDatabase
    @ConditionalOnMissingBean(name = "midJdbcTemplate")
    JdbcTemplate midJdbcTemplate(@MidDatabase DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }

    @Primary
    @Bean
    @FabricDatabase
    @MidDatabase
    @ConditionalOnMissingBean(name = "midJdbcTemplate")
    NamedParameterJdbcTemplate midNamedParameterJdbcTemplate(@MidDatabase DataSource dataSource) {
        return new NamedParameterJdbcTemplate(dataSource);
    }

    @ConfigurationProperties("mid.datasource.app")
    public static class MidAppDataSourceProperties extends FabricDataSourceProperties {
    }

}
