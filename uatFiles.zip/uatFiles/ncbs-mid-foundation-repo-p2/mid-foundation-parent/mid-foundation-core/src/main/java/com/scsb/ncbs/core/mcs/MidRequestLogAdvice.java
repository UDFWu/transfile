package com.scsb.ncbs.core.mcs;

import org.slf4j.Marker;
import org.slf4j.MarkerFactory;
import org.springframework.stereotype.Component;

import com.ibm.cbmp.fabric.foundation.facade.bean.ApiRequest;
import com.ibm.cbmp.fabric.foundation.mcs.advice.IMcsAdvice;
import com.ibm.cbmp.fabric.foundation.mcs.advice.McsExecution;
import com.scsb.ncbs.core.json.JsonMaskUtils;
import com.scsb.ncbs.core.log.LogConstants;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class MidRequestLogAdvice implements IMcsAdvice {
    public static final Marker REQUEST_MARKER = MarkerFactory.getMarker("request");

    @Override
    public void invoke(McsExecution execution) {
        if (log.isInfoEnabled()) {
            ApiRequest<?> apiRequest = execution.getApiRequest().orElse(null);
            log.info(LogConstants.REQUEST_MARKER, JsonMaskUtils.toJson(apiRequest));
        }
    }
}
