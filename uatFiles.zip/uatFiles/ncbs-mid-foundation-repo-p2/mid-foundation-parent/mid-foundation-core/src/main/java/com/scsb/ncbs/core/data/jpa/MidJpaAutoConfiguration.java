package com.scsb.ncbs.core.data.jpa;

import java.util.Arrays;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import com.ibm.cbmp.fabric.foundation.data.jpa.EnableFabricJpa;
import com.ibm.cbmp.fabric.foundation.data.jpa.EnableFabricJpaEntities;
import com.ibm.cbmp.fabric.foundation.data.jpa.FabricDatabase;
import com.ibm.cbmp.fabric.foundation.data.jpa.FabricEntityManagerFactoryBean;
import com.ibm.cbmp.fabric.foundation.data.jpa.FabricJpaConfiguration;
import com.ibm.cbmp.fabric.foundation.data.jpa.FabricJpaConfigurator;

@Configuration
@EnableFabricJpa
@ConditionalOnBean(annotation = EnableMidJpa.class)
@AutoConfigureBefore(FabricJpaConfiguration.class)
@Import(MidDatasourceConfiguration.class)
@EnableConfigurationProperties(MidJpaProperties.class)
public class MidJpaAutoConfiguration {
    public static final String DATA_SOURCE_NAME = FabricJpaConfiguration.DATA_SOURCE_NAME;
    public static final String ENTITY_MANAGER_FACTORY_NAME = FabricJpaConfiguration.ENTITY_MANAGER_FACTORY_NAME;
    public static final String TRANSACTION_MANAGER_NAME = FabricJpaConfiguration.TRANSACTION_MANAGER_NAME;

    @Primary
    @Bean(ENTITY_MANAGER_FACTORY_NAME)
    @FabricDatabase
    @MidDatabase
    @Qualifier(MidDatabaseConstants.MID)
    FabricEntityManagerFactoryBean midEntityManager(
            ObjectProvider<FabricJpaConfigurator> jpaConfiguratorProvider,
            @MidDatabase DataSource dataSource,
            MidJpaProperties jpaProperties) {
        FabricEntityManagerFactoryBean em = new FabricEntityManagerFactoryBean();
        em.setEnableEntitiesAnnotaionTypes(Arrays.asList(EnableFabricJpaEntities.class, EnableMidEntities.class));
        em.setDataSource(dataSource);
        em.getJpaPropertyMap().putAll(jpaProperties.getProperties());
        return em;
    }

    @Bean(TRANSACTION_MANAGER_NAME)
    @FabricDatabase
    @MidDatabase
    @Qualifier(MidDatabaseConstants.MID)
    PlatformTransactionManager midTransactionManager(@MidDatabase EntityManagerFactory entityManagerFactory) {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory);
        return transactionManager;
    }

}
