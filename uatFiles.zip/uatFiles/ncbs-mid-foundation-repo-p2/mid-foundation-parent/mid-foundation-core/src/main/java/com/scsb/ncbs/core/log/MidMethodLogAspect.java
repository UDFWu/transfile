package com.scsb.ncbs.core.log;

import java.util.LinkedHashMap;
import java.util.Map;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scsb.ncbs.core.json.JsonMaskUtils;

abstract interface MidMethodLogAspect {
    void servicePointcut();

    @Pointcut("execution(* com.scsb.ncbs..*.*(..))")
    default void serviceMethod() {
    }

    @Around("servicePointcut() && serviceMethod()")
    default Object invoke(ProceedingJoinPoint point) throws Throwable {
        Logger log = LoggerFactory.getLogger(point.getSignature().getDeclaringTypeName());
        if (this.isLogEnabled(log)) {
            this.logStart(point, log);
            Object result = point.proceed();
            this.logEnd(point, result, log);
            return result;
        } else {
            return point.proceed();
        }
    }

    private void logStart(ProceedingJoinPoint point, Logger log) throws Throwable {
        MethodSignature signature = (MethodSignature) point.getSignature();
        if (log.isDebugEnabled()) {
            String[] argumentNames = signature.getParameterNames();
            Object[] argumentValus = point.getArgs();
            Map<String, Object> arguments = combineArgNameAndValue(argumentNames, argumentValus);
            log.debug("start {} ==> {}", signature.getName(), JsonMaskUtils.toPrettyJson(arguments));
        } else if (log.isInfoEnabled()) {
            log.info("start {}", signature.getName());
        }
    }

    private void logEnd(ProceedingJoinPoint point, Object output, Logger log) throws Throwable {
        MethodSignature signature = (MethodSignature) point.getSignature();
        if (log.isDebugEnabled()) {
            log.debug("end {} ==> {}", signature.getName(), JsonMaskUtils.toPrettyJson(output));
        } else if (log.isInfoEnabled()) {
            log.info("end {}", signature.getName());
        }
    }

    /**
     * - 組合參數名與參數值
     * 
     * @param names
     * @param values
     * @return
     */
    private Map<String, Object> combineArgNameAndValue(String[] names, Object[] values) {
        Map<String, Object> map = new LinkedHashMap<>();
        if (values != null && values.length > 0) {
            for (int i = 0; i < values.length; i++) {
                String name = String.valueOf(i);
                if (names != null && names.length > 0) {
                    name = names[i];
                }
                map.put(name, values[i]);
            }
        }
        return map;
    }

    private boolean isLogEnabled(Logger log) {
        return log.isInfoEnabled() || log.isDebugEnabled();
    }

}
