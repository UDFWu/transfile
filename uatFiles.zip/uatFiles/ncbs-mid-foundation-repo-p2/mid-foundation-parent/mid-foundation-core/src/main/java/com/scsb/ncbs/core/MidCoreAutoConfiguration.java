package com.scsb.ncbs.core;

import javax.validation.Validator;

import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.validation.ValidationAutoConfiguration;
import org.springframework.boot.validation.beanvalidation.FilteredMethodValidationPostProcessor;
import org.springframework.boot.validation.beanvalidation.MethodValidationExcludeFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.validation.beanvalidation.MethodValidationPostProcessor;

import com.ibm.cbmp.fabric.autoconfigure.cache.EnableFabricCache;
import com.ibm.cbmp.fabric.autoconfigure.cache.FabricCacheAutoConfiguration;
import com.ibm.cbmp.fabric.autoconfigure.redis.EnableFabricRedis;
import com.ibm.cbmp.fabric.autoconfigure.redis.FabricRedisAutoConfiguration;
import com.scsb.ncbs.core.annotation.MidConfiguration;

/**
 * 中台AutoConfiguration
 */
@MidConfiguration(proxyBeanMethods = false)
@EnableScheduling
@EnableAsync
@EnableFabricRedis
@EnableFabricCache
@AutoConfigureBefore({
        FabricCacheAutoConfiguration.class,
        FabricRedisAutoConfiguration.class,
        ValidationAutoConfiguration.class
})
public class MidCoreAutoConfiguration {
    @Bean
    public static MethodValidationPostProcessor methodValidationPostProcessor(Environment environment,
            @Lazy Validator validator, ObjectProvider<MethodValidationExcludeFilter> excludeFilters) {
        FilteredMethodValidationPostProcessor processor = new FilteredMethodValidationPostProcessor(
                excludeFilters.orderedStream());
        processor.setBeforeExistingAdvisors(true);
        boolean proxyTargetClass = environment.getProperty("spring.aop.proxy-target-class", Boolean.class, true);
        processor.setProxyTargetClass(proxyTargetClass);
        processor.setValidator(validator);
        return processor;
    }
}
