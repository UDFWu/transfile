package com.scsb.ncbs.core.data.jpa;

import java.util.Arrays;
import java.util.function.Supplier;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.annotation.BeanFactoryAnnotationUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanDefinitionHolder;
import org.springframework.beans.factory.support.AbstractBeanDefinition;
import org.springframework.beans.factory.support.AutowireCandidateQualifier;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.boot.context.properties.bind.Bindable;
import org.springframework.boot.context.properties.bind.Binder;
import org.springframework.context.EnvironmentAware;
import org.springframework.core.env.Environment;
import org.springframework.core.type.AnnotationMetadata;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.SharedEntityManagerCreator;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.util.ClassUtils;

import com.ibm.cbmp.fabric.foundation.data.jpa.FabricDataSourceFactoryBean;
import com.ibm.cbmp.fabric.foundation.data.jpa.FabricEntityManagerFactoryBean;
import com.scsb.ncbs.core.configuration.MidBeanDefinitionRegistrar;

import io.vavr.collection.Stream;

/**
 * 自動註冊MID JPA相關的Bean
 */
public class MidJpaRegistrar implements MidBeanDefinitionRegistrar<EnableMidJpa>, BeanFactoryAware, EnvironmentAware {
    static final String DATA_SOURCE_NAME_SUFFIX = "$DataSource";
    static final String ENTITY_MANAGER_FACTORY_NAME_SUFFIX = "$EntityManagerFactory";
    static final String TRANSACTION_MANAGER_NAME_SUFFIX = "$TransactionManager";
    static final String DATA_SOURCE_CONFIG_PREFIX = "mid.datasource.";
    static final String JPA_CONFIG_PREFIX = "mid.jpa.";
    static final String JTA_CONFIG_PREFIX = "mid.jta.";
    private BeanFactory beanFactory;
    private Environment environment;

    @Override
    public void registerBeanDefinitions(EnableMidJpa annotation, AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry) {
        if (StringUtils.isBlank(annotation.name()) || registry.containsBeanDefinition(annotation.name() + ENTITY_MANAGER_FACTORY_NAME_SUFFIX)) {
            return;
        }

        if (StringUtils.isBlank(annotation.datasource())) {
            this.registerBeanDefinition(registry, this.buildDataSourceBeanDefinition(annotation));
            this.registerBeanDefinition(registry, this.buildJdbcTemplateBeanDefinition(annotation));
        }
        this.registerBeanDefinition(registry, this.buildEntityManagerFactoryBeanDefinition(annotation));
        this.registerBeanDefinition(registry, this.buildTransactionManagerBeanDefinition(annotation));
        this.registerBeanDefinition(registry, this.buildEntityManagerBeanDefinition(annotation));
    }

    private void registerBeanDefinition(BeanDefinitionRegistry registry, BeanDefinitionHolder beanDefinitionHolder) {
        registry.registerBeanDefinition(beanDefinitionHolder.getBeanName(), beanDefinitionHolder.getBeanDefinition());
    }

    BeanDefinitionHolder buildDataSourceBeanDefinition(EnableMidJpa enableMidJpa) {
        BeanDefinition beanDefinition = this.buildBeanDefinition(enableMidJpa, DataSource.class, () -> {
            FabricDataSourceFactoryBean dataSourceFactoryBean = beanFactory.getBean(FabricDataSourceFactoryBean.class);
            return dataSourceFactoryBean.createDataSource(DATA_SOURCE_CONFIG_PREFIX + enableMidJpa.name());
        });
        return new BeanDefinitionHolder(beanDefinition, enableMidJpa.name() + DATA_SOURCE_NAME_SUFFIX);
    }

    BeanDefinitionHolder buildJdbcTemplateBeanDefinition(EnableMidJpa enableMidJpa) {
        BeanDefinition beanDefinition = this.buildBeanDefinition(enableMidJpa, JdbcTemplate.class, () -> {
            DataSource dataSource = this.determineDataSource(enableMidJpa);
            JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
            return jdbcTemplate;
        });
        return new BeanDefinitionHolder(beanDefinition, enableMidJpa.name() + "$JdbcTemplate");
    }

    BeanDefinitionHolder buildEntityManagerFactoryBeanDefinition(EnableMidJpa enableMidJpa) {
        BeanDefinition beanDefinition = this.buildBeanDefinition(enableMidJpa, FabricEntityManagerFactoryBean.class, () -> {
            DataSource dataSource = this.determineDataSource(enableMidJpa);
            FabricEntityManagerFactoryBean em = new FabricEntityManagerFactoryBean();
            em.setName(enableMidJpa.name());
            em.setEnableEntitiesAnnotaionTypes(Arrays.asList(EnableMidEntities.class));
            em.setDataSource(dataSource);
            this.bindProperties(em, JPA_CONFIG_PREFIX + enableMidJpa.name());
            return em;
        });
        return new BeanDefinitionHolder(beanDefinition, enableMidJpa.name() + ENTITY_MANAGER_FACTORY_NAME_SUFFIX);
    }

    BeanDefinitionHolder buildEntityManagerBeanDefinition(EnableMidJpa enableMidJpa) {
        BeanDefinition beanDefinition = this.buildBeanDefinition(enableMidJpa, EntityManager.class, () -> {
            EntityManagerFactory entityManagerFactory = this.getBean(EntityManagerFactory.class, enableMidJpa.name());
            return SharedEntityManagerCreator.createSharedEntityManager(entityManagerFactory);
        });
        return new BeanDefinitionHolder(beanDefinition, enableMidJpa.name() + "$EntityManager");
    }

    BeanDefinitionHolder buildTransactionManagerBeanDefinition(EnableMidJpa enableMidJpa) {
        BeanDefinition beanDefinition = this.buildBeanDefinition(enableMidJpa, PlatformTransactionManager.class, () -> {
            EntityManagerFactory entityManagerFactory = this.getBean(EntityManagerFactory.class, enableMidJpa.name());
            JpaTransactionManager transactionManager = new JpaTransactionManager();
            transactionManager.setEntityManagerFactory(entityManagerFactory);
            this.bindProperties(transactionManager, JTA_CONFIG_PREFIX + enableMidJpa.name());
            return transactionManager;
        });
        return new BeanDefinitionHolder(beanDefinition, enableMidJpa.name() + TRANSACTION_MANAGER_NAME_SUFFIX);
    }

    private <T> BeanDefinition buildBeanDefinition(EnableMidJpa enableMidJpa, Class<T> beanType, Supplier<T> instanceSupplier) {
        BeanDefinitionBuilder beanDefinitionBuilder = BeanDefinitionBuilder
                .genericBeanDefinition(beanType, instanceSupplier)
                .setPrimary(enableMidJpa.primary());
        AbstractBeanDefinition beanDefinition = beanDefinitionBuilder.getBeanDefinition();
        String[] qualifiers = ArrayUtils.add(enableMidJpa.qualifiers(), enableMidJpa.name());
        Stream.of(qualifiers).forEach(qualifier -> {
            if (ClassUtils.isPresent(qualifier, null)) {
                beanDefinition.addQualifier(new AutowireCandidateQualifier(qualifier));
            } else {
                beanDefinition.addQualifier(new AutowireCandidateQualifier(Qualifier.class.getName(), qualifier));
            }
        });
        Stream.of(enableMidJpa.qualifierClasses()).forEach(qualifier -> {
            beanDefinition.addQualifier(new AutowireCandidateQualifier(qualifier.getName()));
        });
        return beanDefinition;
    }

    private DataSource determineDataSource(EnableMidJpa enableMidJpa) {
        return this.getBean(DataSource.class, StringUtils.firstNonBlank(enableMidJpa.datasource(), enableMidJpa.name()));
    }

    private <T> T getBean(Class<T> type, String qualifier) {
        return BeanFactoryAnnotationUtils.qualifiedBeanOfType(beanFactory, type, qualifier);
    }

    private void bindProperties(Object instance, String configPrefix) {
        Binder.get(environment).bind(configPrefix, Bindable.ofInstance(instance));
    }

    @Override
    public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
        this.beanFactory = beanFactory;
    }

    @Override
    public void setEnvironment(Environment environment) {
        this.environment = environment;
    }

}
