package com.scsb.ncbs.core.data.jpa;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.core.annotation.AliasFor;

import com.ibm.cbmp.fabric.foundation.data.jpa.FabricJpaEntities;

/**
 * 啟用MID JPA Entity
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
@FabricJpaEntities
public @interface EnableMidEntities {
    @AliasFor(annotation = FabricJpaEntities.class, attribute = "value")
    String[] value() default {};

    @AliasFor(annotation = FabricJpaEntities.class, attribute = "basePackages")
    String[] basePackages() default {};

    @AliasFor(annotation = FabricJpaEntities.class, attribute = "mappingResources")
    String[] mappingResources() default {};

    @AliasFor(annotation = FabricJpaEntities.class, attribute = "name")
    String name() default "";
}
