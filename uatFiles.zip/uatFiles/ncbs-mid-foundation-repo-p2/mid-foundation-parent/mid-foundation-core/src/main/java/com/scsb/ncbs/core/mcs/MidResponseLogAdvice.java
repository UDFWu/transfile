package com.scsb.ncbs.core.mcs;

import org.springframework.stereotype.Component;

import com.ibm.cbmp.fabric.foundation.mcs.advice.IMcsAdvice;
import com.ibm.cbmp.fabric.foundation.mcs.advice.McsExecution;
import com.scsb.ncbs.core.json.JsonMaskUtils;
import com.scsb.ncbs.core.log.LogConstants;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class MidResponseLogAdvice implements IMcsAdvice {
    @Override
    public void invoke(McsExecution execution) {
        if (log.isInfoEnabled()) {
            log.info(LogConstants.RESPONSE_MARKER, JsonMaskUtils.toJson(execution.getApiResponse()));
        }
    }
}
