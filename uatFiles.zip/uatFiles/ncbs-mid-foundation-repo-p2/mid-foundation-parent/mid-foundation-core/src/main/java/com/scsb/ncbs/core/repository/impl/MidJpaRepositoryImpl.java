package com.scsb.ncbs.core.repository.impl;

import java.util.stream.Stream;

import javax.persistence.EntityManager;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.support.JpaEntityInformation;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;

import com.scsb.ncbs.core.repository.MidJpaRepository;

public class MidJpaRepositoryImpl<T, ID> extends SimpleJpaRepository<T, ID> implements MidJpaRepository<T, ID> {
    private EntityManager entityManager;

    public MidJpaRepositoryImpl(JpaEntityInformation<T, ?> entityInformation, EntityManager entityManager) {
        super(entityInformation, entityManager);
        this.entityManager = entityManager;
    }

    @Override
    public EntityManager getEntityManager() {
        return entityManager;
    }

    @Override
    public Stream<T> streamAll(Specification<T> spec) {
        return this.streamAll(spec, 1000);
    }

    @Override
    public Stream<T> streamAll(Specification<T> spec, int pageSize) {
        return Stream.iterate(
                this.findAll(spec, Pageable.ofSize(pageSize)),
                Page::hasContent,
                p -> p.hasNext() ? this.findAll(spec, p.nextPageable()) : Page.empty())
                .flatMap(Page::stream);
    }
}
