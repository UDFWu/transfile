package com.scsb.ncbs.core.data.jpa;

public class MidDatabaseConstants {
    public static final String MID = "mid";
    public static final String EXP = "exp";
}
