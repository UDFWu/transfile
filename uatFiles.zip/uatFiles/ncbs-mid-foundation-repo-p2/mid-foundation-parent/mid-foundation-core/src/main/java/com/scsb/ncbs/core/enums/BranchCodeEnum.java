package com.scsb.ncbs.core.enums;

import com.ibm.cbmp.fabric.foundation.enums.ICodeDescEnum;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * 分行代碼ENUM
 * @author daniel
 * @date 2025年3月12日
 * @remark
 */
@RequiredArgsConstructor
@Getter
public enum BranchCodeEnum implements ICodeDescEnum {
    INTERNATIONAL_DEPARTEMENT("00500", "005", "國外部");

    /**
     * 分行代碼
     */
    private final String code;
    /**
     * 簡碼
     */
    private final String shortCode;
    /**
     * 說明
     */
    private final String desc;

}
