package com.scsb.ncbs.core.data.jpa;

import java.lang.annotation.Annotation;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.annotation.BeanFactoryAnnotationUtils;
import org.springframework.beans.factory.support.AbstractBeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.data.jpa.repository.config.JpaRepositoryConfigExtension;
import org.springframework.data.repository.config.RepositoryBeanDefinitionRegistrarSupport;
import org.springframework.data.repository.config.RepositoryConfigurationExtension;
import org.springframework.data.repository.config.RepositoryConfigurationSource;
import org.springframework.lang.Nullable;
import org.springframework.orm.jpa.SharedEntityManagerCreator;

/**
 * 自動註冊JPA儲存庫設定
 */
public class MidJpaRepositoriesRegistrar extends RepositoryBeanDefinitionRegistrarSupport implements BeanFactoryAware {
    private BeanFactory beanFactory;

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.data.repository.config.RepositoryBeanDefinitionRegistrarSupport#getAnnotation()
     */
    @Override
    protected Class<? extends Annotation> getAnnotation() {
        return EnableMidRepositories.class;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.data.repository.config.RepositoryBeanDefinitionRegistrarSupport#getExtension()
     */
    @Override
    protected RepositoryConfigurationExtension getExtension() {
        return new MidJpaRepositoryConfigExtension();
    }

    class MidJpaRepositoryConfigExtension extends JpaRepositoryConfigExtension {
        @Override
        public void postProcess(BeanDefinitionBuilder builder, RepositoryConfigurationSource source) {
            super.postProcess(builder, source);
            source.getAttribute("name").ifPresent(name -> {
                builder.addPropertyValue("transactionManager", name);
                builder.addPropertyValue("entityManager", getEntityManagerBeanDefinitionFor(source.getSource(), name));
            });
        }

        /**
         * Creates an anonymous factory to extract the actual {@link javax.persistence.EntityManager} from the {@link javax.persistence.EntityManagerFactory} bean name reference.
         *
         * @param config
         * @param source
         * @return
         */
        private AbstractBeanDefinition getEntityManagerBeanDefinitionFor(@Nullable Object source, String name) {
            BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(EntityManager.class, () -> {
                EntityManagerFactory entityManagerFactory = BeanFactoryAnnotationUtils.qualifiedBeanOfType(beanFactory, EntityManagerFactory.class, name);
                return SharedEntityManagerCreator.createSharedEntityManager(entityManagerFactory);
            });
            AbstractBeanDefinition bean = builder.getRawBeanDefinition();
            bean.setSource(source);
            return bean;
        }
    }

    @Override
    public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
        this.beanFactory = beanFactory;
    }
}
