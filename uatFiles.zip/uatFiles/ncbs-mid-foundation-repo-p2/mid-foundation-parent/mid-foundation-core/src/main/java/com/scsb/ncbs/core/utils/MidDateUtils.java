package com.scsb.ncbs.core.utils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Period;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAccessor;
import java.util.Date;
import java.util.Objects;
import java.util.Optional;
import java.util.TimeZone;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * 日期格式共用函式
 *
 * @author IBM
 * @date 2022/10/25 下午 03:27
 */
public class MidDateUtils extends org.apache.commons.lang3.time.DateUtils {

    private MidDateUtils() {
    }

    public static final String S_YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
    public static final String S_YYYY_MM_DD = "yyyyMMdd";

    public static final DateTimeFormatter YYYYMM = DateTimeFormatter.ofPattern("yyyyMM");
    // 日期格式
    public static final DateTimeFormatter YYYY_MM = DateTimeFormatter.ofPattern("yyyy/MM");
    /** 格式： yyyy-MM-dd HH:mm:ss */
    public static final DateTimeFormatter YYYY_MM_DD_HH_MM_SS = DateTimeFormatter.ofPattern(S_YYYY_MM_DD_HH_MM_SS);
    public static final DateTimeFormatter YYYY_MM_DD_HH_MM = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm");
    public static final DateTimeFormatter YYYY_MM_DD = DateTimeFormatter.ofPattern("yyyy/MM/dd");
    public static final DateTimeFormatter YYYY_MM_DD_ISO = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    public static final DateTimeFormatter YYYYMMDD = DateTimeFormatter.ofPattern(S_YYYY_MM_DD);
    public static final DateTimeFormatter HHmmss = DateTimeFormatter.ofPattern("HHmmss");
    public static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm");

    private static ThreadLocal<LocalDate> currentDate = new ThreadLocal<>();

    public static void setMockNowDate(LocalDate date) {
        currentDate.set(date);
    }

    public static void clearMockNowDate() {
        currentDate.remove();
    }

    public static LocalDate getCurrentDate() {
        LocalDate date = currentDate.get();
        if (date == null) {
            date = LocalDate.now();
        }
        return date;
    }

    /**
     * @param localDateTime yyyy-MM-dd HH:mm:ss
     * @return
     */
    public static String localDateTimeToString(LocalDateTime localDateTime) {
        return localDateTimeToString(localDateTime, YYYY_MM_DD_HH_MM_SS);
    }

    /**
     * @param localDateTime by given formatter
     * @return
     */
    public static String localDateTimeToString(LocalDateTime localDateTime, DateTimeFormatter formatter) {
        return format(localDateTime, formatter);
    }

    /**
     * @param localDate by given formatter
     * @return
     */
    public static String localDateToString(LocalDate localDate) {
        return localDateToString(localDate, YYYY_MM_DD);
    }

    /**
     * @param localDate by given formatter
     * @return
     */
    public static String localDateToString(LocalDate localDate, DateTimeFormatter formatter) {
        return format(localDate, formatter);
    }

    /**
     * @param localDate by given pattern
     * @return
     */
    public static String format(TemporalAccessor temporalAccessor, String pattern) {
        return format(temporalAccessor, DateTimeFormatter.ofPattern(pattern));
    }

    /**
     * @param localDate by given formatter
     * @return
     */
    public static String format(TemporalAccessor temporalAccessor, DateTimeFormatter formatter) {
        Objects.requireNonNull(formatter, "formatter");
        return org.apache.commons.lang3.ObjectUtils.isNotEmpty(temporalAccessor) ? formatter.format(temporalAccessor) : org.apache.commons.lang3.StringUtils.EMPTY;
    }

    /**
     * @param localTime by given formatter
     * @return
     */
    public static String localTimeToString(LocalTime localTime, DateTimeFormatter formatter) {
        return format(localTime, formatter);
    }

    /**
     * @param localDate by given formatter
     * @return
     */
    public static String localDateToStringOrEmpty(LocalDate localDate, DateTimeFormatter formatter) {
        return ObjectUtils.isNotEmpty(localDate) ? localDate.format(formatter) : StringUtils.EMPTY;
    }

    public static LocalDateTime nowLocalDateTime() {
        return LocalDateTime.of(getCurrentDate(), LocalTime.now());
    }

    /**
     * LocalDateTime for now into string
     *
     * @return
     */
    public static String now() {
        return localDateTimeToString(nowLocalDateTime());
    }

    /**
     * String format to Local Date
     *
     * @param dateString
     * @param pattern
     * @return
     */
    public static LocalDate stringToLocalDate(String dateString, String pattern) {
        if (dateString == null || pattern == null) {
            return null;
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
        return LocalDate.parse(dateString, formatter);
    }

    /**
     * String format to Local Date
     *
     * @param dateString
     * @param pattern
     * @return
     */
    public static LocalDate stringToLocalDate(String dateString, DateTimeFormatter pattern) {
        if (dateString == null || pattern == null) {
            return null;
        }
        return LocalDate.parse(dateString, pattern);
    }

    /**
     * String format to Local Date
     *
     * @param dateString
     * @param pattern
     * @return
     */
    public static LocalDateTime stringToLocalDateTime(String dateString, String pattern) {
        if (dateString == null || pattern == null) {
            return null;
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
        return LocalDateTime.parse(dateString, formatter);
    }

    /**
     * Get Difference between dateFrom and dateTo as Days
     *
     * @param dateFrom
     * @param dateTo
     * @return
     */
    public static Long getDateDifferenceAsDays(LocalDate dateFrom, LocalDate dateTo) {
        return ChronoUnit.DAYS.between(dateFrom, dateTo);
    }

    /**
     * Get Difference between dateFrom and dateTo as Months (30 Days as a month)
     *
     * @param dateFrom
     * @param dateTo
     * @return
     */
    public static BigDecimal getDateDifferenceAsMonthsBy30(LocalDate dateFrom, LocalDate dateTo) {
        BigDecimal days = BigDecimal.valueOf(getDateDifferenceAsDays(dateFrom, dateTo));
        BigDecimal thirty = BigDecimal.valueOf(30);
        return days.divide(thirty, RoundingMode.CEILING);
    }

    /**
     * 計算 年月 天數
     *
     * @param year
     * @param month
     * @return
     */
    public static BigDecimal calculateYearMonthDays(String year, String month) {
        Long yearDay = Long.valueOf(Optional.ofNullable(year).orElse("0"));
        Long monthDay = Long.valueOf(Optional.ofNullable(month).orElse("0"));
        return BigDecimal.valueOf(yearDay * 365 + monthDay * 30);
    }

    /**
     * Turn "X years Y months" into total months
     *
     * @param year
     * @param month
     * @return
     */
    public static BigDecimal getTotalMonthsFromYearsAndMonths(BigDecimal year, BigDecimal month) {
        return year.multiply(BigDecimal.valueOf(12)).add(month);
    }

    /**
     * get Age
     *
     * @param birthday
     * @return
     */
    public static BigDecimal getAge(LocalDate birthday) {
        if (Objects.isNull(birthday)) {
            return null;
        }
        LocalDate now1 = getCurrentDate();
        Period diff1 = Period.between(birthday, now1);

        return BigDecimal.valueOf(diff1.getYears());
    }

    public static LocalDate convertToLocalDate(Date dateToConvert) {

        if (dateToConvert == null) {
            return null;
        }

        return dateToConvert.toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
    }

    /**
     * 用來與專案申請日期比較
     *
     * @param birthday
     * @param compareDate
     * @return
     */
    public static int getAge(LocalDate birthday, LocalDate compareDate) {
        if (Objects.isNull(birthday) || Objects.isNull(compareDate)) {
            return 0;
        }
        LocalDate now1 = compareDate;
        Period diff1 = Period.between(birthday, now1);

        return diff1.getYears();
    }

    /**
     * - convert {@link Timestamp} to {@link LocalDate}
     *
     * @param sqlTimestamp
     * @return
     */
    public static LocalDate toLocalDate(Timestamp sqlTimestamp) {
        return sqlTimestamp.toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
    }

    /**
     * - convert {@link Date} to {@link LocalDate}
     *
     * @param date
     * @return
     */
    public static LocalDateTime toLocalDateTime(Date date) {
        return date.toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDateTime();
    }

    /**
     * 比較LocalDateTime without milliseconds
     *
     * @param dateA
     * @param dateB
     * @return
     */
    public static boolean isAfterInSec(LocalDateTime dateA, LocalDateTime dateB) {
        return dateA.truncatedTo(ChronoUnit.SECONDS).isAfter(dateB.truncatedTo(ChronoUnit.SECONDS));
    }

    public static boolean isValidDate(String str) {
        return isValidDate(str, S_YYYY_MM_DD);
    }

    public static boolean isValidDate(String str, String format) {
        boolean convertSuccess = true;
        // 指定日期格式
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        try {
            sdf.setLenient(false);
            sdf.parse(str);
        } catch (Exception e) {
            convertSuccess = false;
        }
        return convertSuccess;
    }

    /**
     * 根據條件抓取該年某月的天數
     *
     * @param year 年
     * @param month 月
     * @return 該年某月的天數
     */
    public static int getLengthOfDaysInMonth(int year, int month) {
        return YearMonth.of(year, month).lengthOfMonth();
    }

    /**
     * millis to localeDateTime
     * @param millis
     * @return LocalDateTime
     */
    public static LocalDateTime toLocalDateTime(Long millis) {
        if (millis == null) {
            return null;
        }
        return LocalDateTime.ofInstant(Instant.ofEpochMilli(millis), TimeZone.getDefault().toZoneId());
    }
}
