package com.scsb.ncbs.core.mcs;

import org.springframework.data.domain.Pageable;

import com.ibm.cbmp.fabric.foundation.facade.bean.ApiRequest;
import com.ibm.cbmp.fabric.foundation.facade.bean.ApiRequestHeader;
import com.ibm.cbmp.fabric.foundation.facade.bean.ServiceInfo;
import com.ibm.cbmp.fabric.foundation.facade.bean.ServiceRq;
import com.ibm.cbmp.fabric.foundation.mcs.McsContext;
import com.ibm.cbmp.fabric.foundation.mcs.McsContextManager;

import lombok.Setter;

/**
 * 中台Request Context
 */
@Setter
public class MidRequestContext {
    /**
     * ApiRequestHeader物件
     */
    private ApiRequestHeader requestHeader;
    /**
     * ServiceRq物件
     */
    private ServiceRq<?> servcieRq;
    /**
     * ServiceInfo物件
     */
    private ServiceInfo serviceInfo;
    /**
     * Pageable物件
     */
    private Pageable pageable;

    /**
     * 取得MidRequestContext實例
     * @return
     * @remark
     */
    public static MidRequestContext getInstance() {
        McsContext context = McsContextManager.getContext();
        return context.getObject(MidRequestContext.class, MidRequestContext::new);
    }

    /**
     * 初始化 MidRequestContext
     */
    public void init(ApiRequest<ServiceRq<?>> apiRequest) {
        this.servcieRq = apiRequest.getServiceRq();
        this.serviceInfo = apiRequest.getServiceRq().getServiceInfo();
        this.requestHeader = apiRequest.getHeader();
    }

    /**
     * 取得ServiceRq物件
     * @return ServiceRq
     */
    public ServiceRq<?> getServiceRq() {
        if (servcieRq == null) {
            servcieRq = new ServiceRq<>();
        }
        return servcieRq;
    }

    /**
     * 取得ServiceInfo物件
     * @return ServiceInfo
     */
    public ServiceInfo getServiceInfo() {
        if (serviceInfo == null) {
            serviceInfo = new ServiceInfo();
        }
        return serviceInfo;
    }

    /**
     * 取得ApiRequestHeader物件
     * @return ApiRequestHeader
     */
    public ApiRequestHeader getRequestHeader() {
        if (requestHeader == null) {
            requestHeader = new ApiRequestHeader();
        }
        return requestHeader;
    }

    /**
     * 取得Pageable物件
     * @return Pageable
     */
    public Pageable getPageable() {
        if (pageable == null) {
            pageable = Pageable.ofSize(10);
        }
        return pageable;
    }
}