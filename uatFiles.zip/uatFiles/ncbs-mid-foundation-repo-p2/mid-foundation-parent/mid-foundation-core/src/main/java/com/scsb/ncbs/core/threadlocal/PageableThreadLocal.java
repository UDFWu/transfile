package com.scsb.ncbs.core.threadlocal;

import org.springframework.data.domain.Pageable;

import com.scsb.ncbs.core.mcs.MidRequestContext;

/**
 * Pageable ThreadLocal
 */
public class PageableThreadLocal {
    /**
     * 
     * @return
     */
    public static Pageable get() {
        return MidRequestContext.getInstance().getPageable();
    }

    public static void set(Pageable pageable) {
        MidRequestContext.getInstance().setPageable(pageable);
    }
}
