package com.scsb.ncbs.core.component.rpt;

import com.ibm.cbmp.fabric.foundation.api.RequestContext;
import com.ibm.cbmp.fabric.foundation.exception.ExceptionUtils;
import com.ibm.cbmp.fabric.foundation.toolkit.JsonUtils;
import com.scsb.ncbs.core.bean.rpt.ReportDataRq;
import com.scsb.ncbs.core.bean.rpt.ReportDataRs;
import com.scsb.ncbs.core.data.jpa.MidTransactional;
import com.scsb.ncbs.core.entity.rpt.ReportDefineEntity;
import com.scsb.ncbs.core.entity.rpt.ReportLogEntity;
import com.scsb.ncbs.core.enums.rpt.ReportPrintType;
import com.scsb.ncbs.core.enums.rpt.ReportStatus;
import com.scsb.ncbs.core.exception.JreportException;
import com.scsb.ncbs.core.repository.rpt.ReportDefineRepository;
import com.scsb.ncbs.core.repository.rpt.ReportLogRepository;
import com.scsb.ncbs.core.utils.MidStringUtils;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.util.Base64Util;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;

import java.io.File;
import java.util.Optional;

/**
 * @author IBM
 * @date 2024/4/8 6:08 PM
 */
@Slf4j
@Component
public class DefaultJreportPrinter implements JreportPrinter {

    @Autowired
    private ReportDefineRepository reportDefineRepository;

    @Autowired
    private ReportLogRepository reportLogRepository;

    @Autowired
    private RequestContext requestContext;

    @Override
    @MidTransactional(propagation = Propagation.REQUIRES_NEW, noRollbackFor = {Throwable.class})
    public ReportDataRs process(ReportDataRq reportDataRq) throws Throwable {
        // 紀錄 ReportLog 資料
        ReportLogEntity logEntity = null;
        try {
            ReportDataRs reportDataRs = new ReportDataRs();
            log.info("reportDataRq={}", reportDataRq);
            log.info("tellerId={}", requestContext.getRequest().getHeader().getTellerId());

            // 紀錄 ReportLog 資料
            logEntity = before(reportDataRq);

            // find report definition data
            Optional<ReportDefineEntity> defineEntityOpt = reportDefineRepository.findById(reportDataRq.getReportId());
            if (defineEntityOpt.isPresent()) {
                ReportDefineEntity reportDefineEntity = defineEntityOpt.get();
                log.info("report define={}", reportDefineEntity);

                // print report
                JasperPrint jprint = JreportFill.fill(
                                (MidStringUtils.isEmpty(reportDefineEntity.getTemplatePathPrefix()) ? "" : reportDefineEntity.getTemplatePathPrefix() + File.separator) + reportDefineEntity.getReportId()
                                        + ".jasper")
                        .dataList(reportDataRq.getReportData()).jprint();

                if (ReportPrintType.PDF == reportDataRq.getPrintType()) {
                    reportDataRs.setContent(Base64Util.encode(JreportFill.exportPdf(jprint)));
                } else {
                    reportDataRs.setContent(JsonUtils.toPrettyJson(reportDataRq.getReportData()));
                }
            } else {
                // error log
                onError(logEntity, new JreportException("The report [" + reportDataRq.getReportId() + "] definition is not found !"));
            }

            return after(logEntity, reportDataRs);
        } catch (Throwable th) {
            if (ObjectUtils.isEmpty(logEntity)) {
                logEntity = new ReportLogEntity();
                logEntity.setReportId(reportDataRq.getReportId());
            }
            // error log
            onError(logEntity, th);
        }

        return null;
    }

    /**
     * pre log
     *
     * @param reportDataRq
     * @return ReportLogEntity
     */
    private ReportLogEntity before(ReportDataRq reportDataRq) {
        // log init
        ReportLogEntity logEntity = new ReportLogEntity();
        logEntity.setReportId(reportDataRq.getReportId());
        logEntity.setGuid(requestContext.getGuid());
        logEntity.setBranchCode(reportDataRq.getBranchCode());
        logEntity.setPrintType(reportDataRq.getPrintType());
        logEntity.setParentGuid(requestContext.getRequestHeader().getClientSeqNo());
        logEntity.setTellerId(requestContext.getRequestHeader().getTellerId());
        logEntity.setSupervisorAId(requestContext.getRequestHeader().getSupervisorAId());
        logEntity.setSupervisorBId(requestContext.getRequestHeader().getSupervisorBId());
        reportLogRepository.saveAndFlush(logEntity);

        return logEntity;
    }

    /**
     * after log
     *
     * @param logEntity
     * @param reportDataRs
     * @return ReportDataRs
     */
    private ReportDataRs after(ReportLogEntity logEntity, ReportDataRs reportDataRs) {
        // log success
        logEntity.setStatus(ReportStatus.SUCCESS);
        // 20240426 Spencer 先不儲存 Base64 PDF字串
        // logEntity.setReportData(reportDataRs.getContent());

        // set report log id(for ref. debug or audit)
        reportDataRs.setReportLogId(logEntity.getListId());

        reportLogRepository.saveAndFlush(logEntity);
        return reportDataRs;
    }

    /**
     * error log
     *
     * @param logEntity
     * @param e         Exception
     * @throws Throwable
     */
    private void onError(ReportLogEntity logEntity, Throwable e) throws Throwable {
        // log error
        logEntity.setErrorMessage(ExceptionUtils.getStackTrace(e));
        logEntity.setStatus(ReportStatus.FAILED);

        reportLogRepository.saveAndFlush(logEntity);
        throw e;
    }
}
