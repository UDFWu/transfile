package com.scsb.ncbs.core.service;

import org.springframework.data.domain.Pageable;

import com.ibm.cbmp.fabric.foundation.facade.bean.ApiRequestHeader;
import com.ibm.cbmp.fabric.foundation.facade.bean.ServiceInfo;
import com.scsb.ncbs.core.mcs.MidRequestContext;

public abstract class BaseService {
    /**
     * 
     * @return
     */
    protected Pageable getPageable() {
        return MidRequestContext.getInstance().getPageable();
    }

    /**
     * 
     * @return
     */
    protected ApiRequestHeader getRequestHeader() {
        return MidRequestContext.getInstance().getRequestHeader();
    }

    /**
     * 
     * @return
     */
    protected ServiceInfo getServiceInfo() {
        return MidRequestContext.getInstance().getServiceInfo();
    }
}
