package com.scsb.ncbs.intg.e2ee.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

/**
 * ISEC解密上傳資料
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class ISecDecryptRequest extends SuipRequest {
    /**
     * 加密金鑰密文
     */
    private String encSessionKey;

    /**
     * 密碼密文
     */
    private String encData;
}
