package com.scsb.ncbs.intg.e2ee.bean;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * ISEC解密回傳結果
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class ISecDecryptResponse extends SuipBaseResponse {
    /**
     * 資料字串
     */
    private String decrypted;
}
