package com.scsb.ncbs.intg.e2ee;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.scsb.ncbs.intg.e2ee.bean.GetPublicKeyRequest;
import com.scsb.ncbs.intg.e2ee.bean.GetPublicKeyResponse;
import com.scsb.ncbs.intg.e2ee.bean.ISecDecryptRequest;
import com.scsb.ncbs.intg.e2ee.bean.ISecDecryptResponse;
import com.scsb.ncbs.intg.e2ee.bean.PwdChangeRequest;
import com.scsb.ncbs.intg.e2ee.bean.PwdChangeResponse;
import com.scsb.ncbs.intg.e2ee.bean.PwdSetRequest;
import com.scsb.ncbs.intg.e2ee.bean.PwdSetResponse;
import com.scsb.ncbs.intg.e2ee.bean.PwdVerifyRequest;
import com.scsb.ncbs.intg.e2ee.bean.PwdVerifyResponse;

/**
 * 端點對端點加密機制API用戶端介面
 */
public interface E2eeApiClient {
    /**
     * 取得E2EE RSA公鑰，供客戶端E2EE安控套件加密對談密鑰成對談密鑰密文
     * @param request 上傳資料
     * @return 回傳結果
     */
    public GetPublicKeyResponse getPublicKey(GetPublicKeyRequest request);

    /**
     * 密碼設定<br>
     * 將對談密鑰密文與對談密鑰加密之密碼密文輸入至HSM FM之內，進行解密密碼密文。接著再用E2EE AES密鑰加密該密碼，回傳以供銀行端應用系統儲存於資料庫內，作為後續驗證密碼使用
     * @param request 上傳資料
     * @return 回傳結果
     */
    public PwdSetResponse pwdSet(PwdSetRequest request);

    /**
     * 密碼驗證<br>
     * 將對談密鑰密文與對談密鑰加密之密碼密文以及E2EE AES密鑰加密之密碼密文輸入至HSM FM之內，進行解密密碼密文與進行密碼比對，作為銀行端應用系統密碼驗證之用。
     * @param request 上傳資料
     * @return 回傳結果
     */
    public PwdVerifyResponse pwdVerify(PwdVerifyRequest request);

    /**
     * 密碼變更<br>
     * 將對談密鑰密文與對談密鑰加密之新舊密碼密文以及E2EE AES密鑰加密之舊密碼密文輸入至HSM FM之內，進行解密新舊密碼密文與進行密碼比對。接著再用E2EE AES密鑰加密新密碼，回傳以供銀行端應用系統儲存於資料庫內，作為後續驗證新密碼使用。
     * @param request 上傳資料
     * @return 回傳結果
     */
    public PwdChangeResponse pwdChange(PwdChangeRequest request);

    /**
     * 使用iSecurity取得E2EE RSA公鑰，供客戶端E2EE安控套件加密對談密鑰成對談密鑰密文
     * @param request 上傳資料
     * @return 回傳結果
     */
    @PostMapping("/SCSB/iSecGetPubKey")
    public @ResponseBody GetPublicKeyResponse iSecGetPubKey(@RequestBody GetPublicKeyRequest request);

    /**
     * ISEC解密<br>
     * 首先在客戶端使用E2EE安控套件將機敏資料依對談密鑰加密成資料密文。接著在銀行端應用系統上，將對談密鑰密文與資料密文透過iSecurity連接到HSM之內進行解密資料密文，然後回傳給銀行端應用系統進行下一步作業流程
     * @param request 上傳資料
     * @return 回傳結果
     */
    @PostMapping("/SCSB/iSecDecrypt")
    public @ResponseBody ISecDecryptResponse iSecDecrypt(@RequestBody ISecDecryptRequest request);

    /**
     * 是否支援指定應用程式代碼的加解密演算法
     * @param apId 應用程式代碼
     * @return boolean
     */
    public default boolean accept(String apId) {
        return false;
    }
}
