package com.scsb.ncbs.intg.e2ee.client;

import java.util.function.BiFunction;

import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.scsb.ncbs.intg.e2ee.E2eeApiClient;
import com.scsb.ncbs.intg.e2ee.bean.GetPublicKeyRequest;
import com.scsb.ncbs.intg.e2ee.bean.GetPublicKeyResponse;
import com.scsb.ncbs.intg.e2ee.bean.ISecDecryptRequest;
import com.scsb.ncbs.intg.e2ee.bean.ISecDecryptResponse;
import com.scsb.ncbs.intg.e2ee.bean.PwdChangeRequest;
import com.scsb.ncbs.intg.e2ee.bean.PwdChangeResponse;
import com.scsb.ncbs.intg.e2ee.bean.PwdSetRequest;
import com.scsb.ncbs.intg.e2ee.bean.PwdSetResponse;
import com.scsb.ncbs.intg.e2ee.bean.PwdVerifyRequest;
import com.scsb.ncbs.intg.e2ee.bean.PwdVerifyResponse;
import com.scsb.ncbs.intg.e2ee.bean.SuipRequest;

/**
 * 端點對端點加密機制API用戶端 wrapper，依據指定的應用程式代碼調用對應用E2eeApiClient
 */
public class E2eeApiClientWrapper implements E2eeApiClient {
    @Autowired
    @Qualifier("CUSTOM")
    private ObjectProvider<E2eeApiClient> clientProvider;

    @Autowired
    @Qualifier("DEFAULT")
    private E2eeApiClient defaultE2eeApiClient;

    @Override
    public GetPublicKeyResponse getPublicKey(GetPublicKeyRequest request) {
        return this.invokeApiClient(request, E2eeApiClient::getPublicKey);
    }

    @Override
    public PwdSetResponse pwdSet(PwdSetRequest request) {
        return this.invokeApiClient(request, E2eeApiClient::pwdSet);
    }

    @Override
    public PwdVerifyResponse pwdVerify(PwdVerifyRequest request) {
        return this.invokeApiClient(request, E2eeApiClient::pwdVerify);
    }

    @Override
    public PwdChangeResponse pwdChange(PwdChangeRequest request) {
        return this.invokeApiClient(request, E2eeApiClient::pwdChange);
    }

    @Override
    public GetPublicKeyResponse iSecGetPubKey(GetPublicKeyRequest request) {
        return this.invokeApiClient(request, E2eeApiClient::iSecGetPubKey);
    }

    @Override
    public ISecDecryptResponse iSecDecrypt(ISecDecryptRequest request) {
        return this.invokeApiClient(request, E2eeApiClient::iSecDecrypt);
    }

    private <T extends SuipRequest, R> R invokeApiClient(T request, BiFunction<E2eeApiClient, T, R> function) {
        return function.apply(this.findE2eeApiClient(request.getApId()), request);
    }

    private E2eeApiClient findE2eeApiClient(String apId) {
        for (E2eeApiClient client : clientProvider) {
            if (client.accept(apId)) {
                return client;
            }
        }
        return defaultE2eeApiClient;
    }

}
