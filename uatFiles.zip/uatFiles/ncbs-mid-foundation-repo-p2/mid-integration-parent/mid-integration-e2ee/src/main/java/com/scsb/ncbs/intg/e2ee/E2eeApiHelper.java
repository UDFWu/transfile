package com.scsb.ncbs.intg.e2ee;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;
import org.springframework.util.Base64Utils;

import com.scsb.ncbs.intg.e2ee.enums.E2eeApiCodeEnum;
import com.scsb.ncbs.intg.e2ee.enums.EncModeEnum;
import com.scsb.ncbs.intg.e2ee.enums.HashModeEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 端點對端點加密機制 Helper
 */
@Slf4j
public class E2eeApiHelper {
    private static final String E2EE_ENCRYPTION_ALGORITHM = "RSA";
    private static final String DATA_KEY_ALGORITHM = "AES";
    private static final String DATA_ENCRYPTION_ALGORITHM = "AES/ECB/PKCS5Padding";
    private static final byte[] EMPTY_BYTES = new byte[0];

    @Autowired
    private E2eeApiService e2eeApiService;
    private Map<String, PublicKey> publicKeyMap = new ConcurrentHashMap<>();

    /**
     * 取得E2EE RSA公鑰，供客戶端E2EE安控套件加密對談密鑰成對談密鑰密文
     * @param apId 應用程式代碼
     * @return E2EE公鑰
     */
    public PublicKey getPublicKey(String apId) {
        return publicKeyMap.computeIfAbsent(apId, key -> {
            String base64PublicKey = e2eeApiService.getPublicKey(apId);
            return loadPublicKey(base64PublicKey);
        });
    }

    /**
     * 取得E2EE RSA公鑰，供客戶端E2EE安控套件加密對談密鑰成對談密鑰密文
     * @param apId 應用程式代碼
     * @return E2EE公鑰
     */
    public PublicKey getISecPublicKey(String apId) {
        return publicKeyMap.computeIfAbsent(apId, key -> {
            String base64PublicKey = e2eeApiService.getISecPublicKey(apId);
            return loadPublicKey(base64PublicKey);
        });
    }

    /**
     * 建立E2EE加密使用的AES SESSION KEY
     * @param apId 應用程式代碼
     * @return E2EE加密使用的AES SESSION KEY
     */
    public E2eeSessionKey buildSessionKey(String apId) {
        PublicKey publicKey = this.getPublicKey(apId);
        SecretKey secretKey = this.generateAesKey();
        long timeMillis = System.currentTimeMillis();
        String encryptedSessionKey = this.formatEncryptedSessionKey(publicKey, secretKey, "", "", timeMillis);
        return E2eeSessionKey.builder()
                .apId(apId)
                .publicKey(publicKey)
                .secretKey(secretKey)
                .timeMillis(timeMillis)
                .encryptedSessionKey(encryptedSessionKey)
                .build();
    }

    /**
     * 建立E2EE加密使用的AES SESSION KEY
     * @param apId 應用程式代碼
     * @return E2EE加密使用的AES SESSION KEY
     */
    public E2eeSessionKey buildISecSessionKey(String apId) {
        PublicKey publicKey = this.getISecPublicKey(apId);
        SecretKey secretKey = this.generateAesKey();
        long timeMillis = System.currentTimeMillis();
        String encryptedSessionKey = this.formatEncryptedSessionKey(publicKey, secretKey, "", "", timeMillis);
        return E2eeSessionKey.builder()
                .apId(apId)
                .publicKey(publicKey)
                .secretKey(secretKey)
                .timeMillis(timeMillis)
                .encryptedSessionKey(encryptedSessionKey)
                .build();
    }

    /**
     * 使用加密金鑰加密之明文產生密文
     * @param sessionKey E2EE AES SESSION KEY
     * @param data 明文
     * @return 以加密金鑰加密之密文
     */
    public String encryptData(E2eeSessionKey sessionKey, String data) {
        return this.encryptData(sessionKey, data, HashModeEnum.NONE);
    }

    /**
     * 使用加密金鑰加密之明文產生密文
     * @param sessionKey E2EE AES SESSION KEY
     * @param data 明文
     * @return 以加密金鑰加密之密文
     */
    public String encryptData(E2eeSessionKey sessionKey, String data, HashModeEnum hashMode) {
        return this.encryptData(sessionKey, data.getBytes(StandardCharsets.UTF_8), hashMode);
    }

    /**
     * 使用加密金鑰加密之明文產生密文
     * @param sessionKey E2EE AES SESSION KEY
     * @param data 明文
     * @return 以加密金鑰加密之密文
     */
    public String encryptData(E2eeSessionKey sessionKey, byte[] data) {
        return this.encryptData(sessionKey, data, HashModeEnum.NONE);
    }

    /**
     * 使用加密金鑰加密之明文產生密文
     * @param sessionKey E2EE AES SESSION KEY
     * @param data 明文
     * @return 以加密金鑰加密之密文
     */
    public String encryptData(E2eeSessionKey sessionKey, byte[] data, HashModeEnum hashMode) {
        byte[] hashBytes = this.hash(data, hashMode);
        byte[] encData = encryptData(DATA_ENCRYPTION_ALGORITHM, sessionKey.getSecretKey(), hashBytes);
        return formatEncData(encData, hashMode, EncModeEnum.ECB, EMPTY_BYTES);
    }

    /**
     * 使用加密金鑰加密之明文產生密文
     * @param sessionKey E2EE AES SESSION KEY
     * @param data 明文
     * @return 以加密金鑰加密之密文
     */
    public String decryptData(E2eeSessionKey sessionKey, String encData) {
        byte[] decryptedBytes = decryptData(DATA_ENCRYPTION_ALGORITHM, sessionKey.getSecretKey(), Base64.decodeBase64(encData));
        return new String(decryptedBytes, StandardCharsets.UTF_8);
    }

    /**
     * 密碼設定<br/>
     * 將對談密鑰密文與對談密鑰加密之密碼密文輸入至HSM FM之內，進行解密密碼密文。接著再用E2EE AES密鑰加密該密碼，回傳以供銀行端應用系統儲存於資料庫內，作為後續驗證密碼使用
     * @param apId 應用程式代碼
     * @param password 密碼
     * @return E2EE 加密密文,以加密金鑰加密之密碼密文，用於應用系統儲存之E2EE密碼密文
     */
    public String setPassword(String apId, String password) {
        E2eeSessionKey sessionKey = this.buildSessionKey(apId);
        String encData = this.encryptData(sessionKey, password);
        return e2eeApiService.setPassword(apId, sessionKey.getEncryptedSessionKey(), encData);
    }

    /**
     * 密碼驗證<br/>
     * 將對談密鑰密文與對談密鑰加密之密碼密文以及E2EE AES密鑰加密之密碼密文輸入至HSM FM之內，進行解密密碼密文與進行密碼比對，作為銀行端應用系統密碼驗證之用。
     * @param apId 應用程式代碼
     * @param password 密碼
     * @param secData E2EE 加密密文 長度: 24 or 44, 應用系統儲存之E2EE密碼密文
     * @return 驗證結果,成功為true
     */
    public boolean verifyPassword(String apId, String password, String secData) {
        E2eeSessionKey sessionKey = this.buildSessionKey(apId);
        String encData = this.encryptData(sessionKey, password);
        return e2eeApiService.verifyPassword(apId, sessionKey.getEncryptedSessionKey(), encData, secData);
    }

    /**
     * 密碼變更<br/>
     * 將對談密鑰密文與對談密鑰加密之新舊密碼密文以及E2EE AES密鑰加密之舊密碼密文輸入至HSM FM之內，進行解密新舊密碼密文與進行密碼比對。接著再用E2EE AES密鑰加密新密碼，回傳以供銀行端應用系統儲存於資料庫內，作為後續驗證新密碼使用。
     * @param apId 應用程式代碼
     * @param password 舊密碼
     * @param newPassword 新密碼
     * @param secData E2EE 加密密文 長度: 24 or 44, 應用系統儲存之E2EE密碼密文
     * @return E2EE 加密密文,以加密金鑰加密之密碼密文，用於應用系統儲存之E2EE密碼密文
     * @remark
     */
    public String changePassword(String apId, String password, String newPassword, String secData) {
        E2eeSessionKey sessionKey = this.buildSessionKey(apId);
        String encOldData = this.encryptData(sessionKey, password);
        String encNewData = this.encryptData(sessionKey, newPassword);
        return e2eeApiService.changePassword(apId, sessionKey.getEncryptedSessionKey(), encOldData, encNewData, secData);
    }

    public SecretKey generateAesKey() {
        try {
            KeyGenerator kg = KeyGenerator.getInstance(DATA_KEY_ALGORITHM);
            kg.init(256);
            SecretKey key = kg.generateKey();
            return key;
        } catch (NoSuchAlgorithmException e) {
            throw new E2eeApiException(E2eeApiCodeEnum.ENCRYPTION_API_ERROR, e);
        }
    }

    public SecretKey loadAesKey(byte[] encodedAesKey) {
        return new SecretKeySpec(encodedAesKey, DATA_KEY_ALGORITHM);
    }

    public SecretKey loadAesKey(String base64AesKey) {
        return this.loadAesKey(Base64.decodeBase64(base64AesKey));
    }

    public byte[] generateIV(int size) {
        byte[] iv = new byte[size];
        new SecureRandom().nextBytes(iv);
        return iv;
    }

    public byte[] encryptData(String algorithm, Key key, byte[] value) {
        return this.encryptData(algorithm, key, Cipher.ENCRYPT_MODE, null, value);
    }

    public byte[] encryptData(String algorithm, Key key, byte[] iv, byte[] value) {
        return this.encryptData(algorithm, key, Cipher.ENCRYPT_MODE, iv, value);
    }

    public byte[] decryptData(String algorithm, Key key, byte[] iv, byte[] value) {
        return this.encryptData(algorithm, key, Cipher.DECRYPT_MODE, iv, value);
    }

    public byte[] decryptData(String algorithm, Key key, byte[] value) {
        return this.encryptData(algorithm, key, Cipher.DECRYPT_MODE, null, value);
    }

    private byte[] encryptData(String algorithm, Key key, int mode, byte[] iv, byte[] value) {
        try {
            Cipher cipher = Cipher.getInstance(algorithm);
            String encMode = StringUtils.upperCase(ArrayUtils.get(StringUtils.split(algorithm, "/"), 1, ""));
            switch (encMode) {
            case "GCM":
                Assert.notNull(value, "iv must not be null");
                cipher.init(mode, key, new GCMParameterSpec(iv.length * 8, iv));
                break;
            case "CBC":
                Assert.notNull(value, "iv must not be null");
                cipher.init(mode, key, new IvParameterSpec(iv));
                break;
            default:
                cipher.init(mode, key);
                break;
            }
            return cipher.doFinal(value);
        } catch (InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException | IllegalBlockSizeException | BadPaddingException | InvalidAlgorithmParameterException e) {
            throw new E2eeApiException(E2eeApiCodeEnum.ENCRYPTION_API_ERROR, e);
        }
    }

    /**
     * 將AES密文格式化為E2EE密文
     * @param encData AES加密後的密文
     * @param hashMode 1:md5 2:sha256 0:none
     * @param padType 1:YES 0:NO
     * @param encMode 1:ECB 2:CBC
     * @param iv iv
     * @return E2EE密文
     */
    private String formatEncData(byte[] encData, HashModeEnum hashMode, EncModeEnum encMode, byte[] iv) {
        try {
            ByteArrayOutputStream buff = new ByteArrayOutputStream();
            DataOutputStream dataOuput = new DataOutputStream(buff);
            dataOuput.writeShort(hashMode.getCode());
            dataOuput.writeShort(hashMode.getPadType().getCode());
            dataOuput.writeShort(encMode.getCode());
            dataOuput.writeShort(iv.length);
            dataOuput.write(iv);
            dataOuput.writeShort(encData.length);
            dataOuput.write(encData);
            dataOuput.flush();
            return Base64.encodeBase64String(buff.toByteArray());
        } catch (IOException e) {
            throw new E2eeApiException(E2eeApiCodeEnum.ENCRYPTION_API_ERROR, e);
        }
    }

    /**
     * 格式化E2EE加密金鑰密文,以E2EE公鑰加密之金鑰密文
     * @param publicKey E2EE公鑰
     * @param secretKey AES金鑰
     * @param data1 未知，目前放空字串
     * @param data2 未知，目前放空字串
     * @param timeMillis 當下時間
     * @return E2EE金鑰密文
     */
    private String formatEncryptedSessionKey(PublicKey publicKey, SecretKey secretKey, String data1, String data2, long timeMillis) {
        try {
            byte[] data1Bytes = data1.getBytes(StandardCharsets.UTF_8);
            byte[] data2Bytes = data2.getBytes(StandardCharsets.UTF_8);
            int sessionKeyLenth = 2 + 8 + 2 + secretKey.getEncoded().length + 2 + data1Bytes.length + 2 + data2Bytes.length;
            ByteArrayOutputStream buff = new ByteArrayOutputStream();
            DataOutputStream dataOuput = new DataOutputStream(buff);
            dataOuput.writeShort(sessionKeyLenth);
            dataOuput.writeLong(timeMillis);
            dataOuput.writeShort(secretKey.getEncoded().length);
            dataOuput.write(secretKey.getEncoded());
            dataOuput.writeShort(data1Bytes.length);
            dataOuput.write(data1Bytes);
            dataOuput.writeShort(data2Bytes.length);
            dataOuput.write(data2Bytes);
            dataOuput.flush();
            byte[] formatedSessionKey = buff.toByteArray();
            byte[] encryptedSessionKey = this.encryptData(E2EE_ENCRYPTION_ALGORITHM, publicKey, formatedSessionKey);
            return Base64Utils.encodeToString(encryptedSessionKey);
        } catch (Exception e) {
            throw new E2eeApiException(E2eeApiCodeEnum.ENCRYPTION_API_ERROR, e);
        }
    }

    private PublicKey loadPublicKey(String base64PublicKey) {
        byte[] publicKeyBytes = Base64Utils.decodeFromString(base64PublicKey);
        X509EncodedKeySpec ks = new X509EncodedKeySpec(publicKeyBytes);
        try {
            KeyFactory kf = KeyFactory.getInstance(E2EE_ENCRYPTION_ALGORITHM);
            return kf.generatePublic(ks);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new E2eeApiException(E2eeApiCodeEnum.LOAD_PUBLIC_KEY_ERROR, e);
        }
    }

    private byte[] hash(byte[] plainBytes, HashModeEnum hashMode) {
        switch (hashMode) {
        case NONE:
            return plainBytes;
        case MD5:
            return DigestUtils.md5(plainBytes);
        case SHA256:
            byte[] sha256 = DigestUtils.sha256(plainBytes);
            log.debug("sha256 : {}", Hex.encodeHexString(sha256));
            String base64 = Base64.encodeBase64String(sha256);
            log.debug("base64 : {}", base64);
            return sha256;
        default:
            throw new IllegalArgumentException("Invalid hash mode :" + hashMode);
        }
    }
}
