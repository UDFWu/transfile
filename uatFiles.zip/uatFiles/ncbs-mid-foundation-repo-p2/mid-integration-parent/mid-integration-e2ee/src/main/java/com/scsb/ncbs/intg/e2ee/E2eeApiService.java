package com.scsb.ncbs.intg.e2ee;

import org.apache.commons.lang3.BooleanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;

import com.scsb.ncbs.intg.e2ee.bean.GetPublicKeyRequest;
import com.scsb.ncbs.intg.e2ee.bean.GetPublicKeyResponse;
import com.scsb.ncbs.intg.e2ee.bean.ISecDecryptRequest;
import com.scsb.ncbs.intg.e2ee.bean.ISecDecryptResponse;
import com.scsb.ncbs.intg.e2ee.bean.PwdChangeRequest;
import com.scsb.ncbs.intg.e2ee.bean.PwdChangeResponse;
import com.scsb.ncbs.intg.e2ee.bean.PwdSetRequest;
import com.scsb.ncbs.intg.e2ee.bean.PwdSetResponse;
import com.scsb.ncbs.intg.e2ee.bean.PwdVerifyRequest;
import com.scsb.ncbs.intg.e2ee.bean.PwdVerifyResponse;

import lombok.extern.slf4j.Slf4j;

/**
 * 端點對端點加密機制
 */
@Slf4j
public class E2eeApiService {
    @Autowired
    private E2eeApiClient e2eeApiClient;

    /**
     * 取得E2EE RSA公鑰，供客戶端E2EE安控套件加密對談密鑰成對談密鑰密文
     * @param apId 應用程式代碼
     * @return E2EE公鑰值
     */
    @Cacheable(cacheNames = "E2EE:PUBLIC_KEY")
    public String getPublicKey(String apId) {
        GetPublicKeyRequest request = GetPublicKeyRequest.builder().apId(apId).build();
        log.debug("GetPublicKeyRequest : {}", request);
        GetPublicKeyResponse response = e2eeApiClient.getPublicKey(request);
        log.debug("GetPublicKeyResponse : {}", response);
        return response.getPublicKey();
    }

    /**
     * 密碼設定<br/>
     * 將對談密鑰密文與對談密鑰加密之密碼密文輸入至HSM FM之內，進行解密密碼密文。接著再用E2EE AES密鑰加密該密碼，回傳以供銀行端應用系統儲存於資料庫內，作為後續驗證密碼使用
     * @param apId 應用程式代碼
     * @param encSessionkey 加密金鑰密文,固定長度: 344
     * @param encData 密碼密文,長度: 36
     * @return E2EE 加密密文,以加密金鑰加密之密碼密文，用於應用系統儲存之E2EE密碼密文
     */
    public String setPassword(String apId, String encSessionkey, String encData) {
        PwdSetRequest request = PwdSetRequest.builder()
                .apId(apId)
                .encSessionKey(encSessionkey)
                .encData(encData)
                .build();
        log.debug("PwdSetRequest : {}", request);
        PwdSetResponse response = e2eeApiClient.pwdSet(request);
        log.debug("PwdSetResponse : {}", response);
        return response.getEncrypted();
    }

    /**
     * 密碼驗證<br/>
     * 將對談密鑰密文與對談密鑰加密之密碼密文以及E2EE AES密鑰加密之密碼密文輸入至HSM FM之內，進行解密密碼密文與進行密碼比對，作為銀行端應用系統密碼驗證之用。
     * @param apId 應用程式代碼
     * @param encSessionKey 加密金鑰密文,固定長度: 344, 以E2EE公鑰加密之金鑰密文
     * @param encData 密碼密文,長度: 36, 以加密金鑰加密之密碼密文
     * @param secData E2EE 加密密文 長度: 24 or 44, 應用系統儲存之E2EE密碼密文
     * @return 驗證結果,成功為true
     */
    public boolean verifyPassword(String apId, String encSessionKey, String encData, String secData) {
        PwdVerifyRequest request = PwdVerifyRequest.builder()
                .apId(apId)
                .encSessionKey(encSessionKey)
                .encData(encData)
                .secData(secData)
                .build();
        log.debug("PwdVerifyRequest : {}", request);
        PwdVerifyResponse response = e2eeApiClient.pwdVerify(request);
        log.debug("PwdVerifyResponse : {}", response);
        return BooleanUtils.isTrue(response.getResult());
    }

    /**
     * 密碼變更<br/>
     * 將對談密鑰密文與對談密鑰加密之新舊密碼密文以及E2EE AES密鑰加密之舊密碼密文輸入至HSM FM之內，進行解密新舊密碼密文與進行密碼比對。接著再用E2EE AES密鑰加密新密碼，回傳以供銀行端應用系統儲存於資料庫內，作為後續驗證新密碼使用。
     * @param apId 應用程式代碼
     * @param encSessionKey 加密金鑰密文,固定長度: 344, 以E2EE公鑰加密之金鑰密文
     * @param encOldData 舊密碼密文,長度: 36, 以加密金鑰加密之密碼密文
     * @param encNewData 新密碼密文,長度: 36, 以加密金鑰加密之密碼密文
     * @param secData E2EE 加密密文 長度: 24 or 44, 應用系統儲存之E2EE密碼密文
     * @return E2EE 加密密文,以加密金鑰加密之密碼密文，用於應用系統儲存之E2EE密碼密文
     */
    public String changePassword(String apId, String encSessionKey, String encOldData, String encNewData, String secData) {
        PwdChangeRequest request = PwdChangeRequest.builder()
                .apId(apId)
                .encSessionKey(encSessionKey)
                .encOldData(encNewData)
                .encNewData(encNewData)
                .secData(secData)
                .build();
        log.debug("PwdChangeRequest : {}", request);
        PwdChangeResponse response = e2eeApiClient.pwdChange(request);
        log.debug("PwdChangeResponse : {}", response);
        return response.getEncrypted();
    }

    /**
     * 取得E2EE ISEC RSA公鑰，供客戶端E2EE安控套件加密對談密鑰成對談密鑰密文
     * @param apId 應用程式代碼
     * @return E2EE公鑰值
     */
    @Cacheable(cacheNames = "E2EE:ISEC_PUBLIC_KEY")
    public String getISecPublicKey(String apId) {
        GetPublicKeyRequest request = GetPublicKeyRequest.builder().apId(apId).build();
        log.debug("GetPublicKeyRequest : {}", request);
        GetPublicKeyResponse response = e2eeApiClient.iSecGetPubKey(request);
        log.debug("GetPublicKeyResponse : {}", response);
        return response.getPublicKey();
    }

    /**
     * ISEC解密<br/>
     * 首先在客戶端使用E2EE安控套件將機敏資料依對談密鑰加密成資料密文。接著在銀行端應用系統上，將對談密鑰密文與資料密文透過iSecurity連接到HSM之內進行解密資料密文，然後回傳給銀行端應用系統進行下一步作業流程
     * @param apId 應用程式代碼
     * @param encSessionkey 加密金鑰密文,固定長度: 344
     * @param encData 密文,長度: 36
     * @return E2EE 解密後的Base64明文
     */
    public String decrypt(String apId, String encSessionkey, String encData) {
        ISecDecryptRequest request = ISecDecryptRequest.builder()
                .apId(apId)
                .encSessionKey(encSessionkey)
                .encData(encData)
                .build();
        log.debug("ISecDecryptRequest : {}", request);
        ISecDecryptResponse response = e2eeApiClient.iSecDecrypt(request);
        log.debug("ISecDecryptResponse : {}", response);
        return response.getDecrypted();
    }

}
