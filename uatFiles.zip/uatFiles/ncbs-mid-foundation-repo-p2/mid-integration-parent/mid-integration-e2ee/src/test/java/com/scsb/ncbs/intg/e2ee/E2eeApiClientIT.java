package com.scsb.ncbs.intg.e2ee;

import javax.crypto.SecretKey;

import org.apache.commons.codec.binary.Base64;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.ibm.cbmp.fabric.foundation.mcs.annotation.EnableMcs;
import com.scsb.ncbs.core.data.jpa.EnableMidJpa;
import com.scsb.ncbs.core.test.MidSpringBootTest;
import com.scsb.ncbs.intg.e2ee.E2eeApiClientIT.SuipClientITConfigration;
import com.scsb.ncbs.intg.e2ee.bean.ISecDecryptRequest;
import com.scsb.ncbs.intg.e2ee.bean.ISecDecryptResponse;
import com.scsb.ncbs.intg.e2ee.bean.PwdChangeRequest;
import com.scsb.ncbs.intg.e2ee.bean.PwdChangeResponse;
import com.scsb.ncbs.intg.e2ee.bean.PwdSetRequest;
import com.scsb.ncbs.intg.e2ee.bean.PwdSetResponse;
import com.scsb.ncbs.intg.e2ee.bean.PwdVerifyRequest;
import com.scsb.ncbs.intg.e2ee.bean.PwdVerifyResponse;
import com.scsb.ncbs.intg.e2ee.bean.SuipResponse;
import com.scsb.ncbs.intg.e2ee.enums.HashModeEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 端點對端點加密機制API用戶端 UT
 */
@MidSpringBootTest(classes = SuipClientITConfigration.class)
@Slf4j
class E2eeApiClientIT {
    @Autowired
    private E2eeApiHelper e2eeApiHelper;

    @Autowired
    private E2eeApiClient e2eeApiClient;

    @Test
    void testPwdSet() throws Throwable {
        String apId = "CTI";
        String password = "123456";
        E2eeSessionKey sessionKey = e2eeApiHelper.buildSessionKey(apId);
        String encData = e2eeApiHelper.encryptData(sessionKey, password);
        String encSessionKey = sessionKey.getEncryptedSessionKey();
        PwdSetRequest request = PwdSetRequest.builder()
                .apId(apId)
                .encSessionKey(encSessionKey)
                .encData(encData)
                .build();
        PwdSetResponse response = e2eeApiClient.pwdSet(request);
        log.debug("response : {}", response);
        // E2EE加密後的密碼
        String secData = response.getEncrypted();
        log.debug("secData : {}", secData);
        Assertions.assertEquals(SuipResponse.RTN_CODE_SUCCESS, response.getRtnCode());
    }

    @Test
    void testPwdVerify() throws Throwable {
        String apId = "NNB";
        String password = "a1b2c3d4";

        E2eeSessionKey sessionKey = e2eeApiHelper.buildSessionKey(apId);
        String encData = e2eeApiHelper.encryptData(sessionKey, password, HashModeEnum.NONE);
        String encSessionKey = sessionKey.getEncryptedSessionKey();
        String secData = this.getSecData(apId, password);
        log.debug("secData:{}", secData);

        PwdVerifyRequest request = PwdVerifyRequest.builder()
                .apId(apId)
                .encSessionKey(encSessionKey)
                .encData(encData)
                .secData(secData)
                .build();

        PwdVerifyResponse response = e2eeApiClient.pwdVerify(request);
        log.debug("response : {}", response);
        // 驗證結果
        boolean result = response.getResult();

        Assertions.assertEquals(SuipResponse.RTN_CODE_SUCCESS, response.getRtnCode());
        Assertions.assertEquals(Boolean.TRUE, result);

    }

    @Test
    void testPwdChange() throws Throwable {
        String apId = "EWB";
        String loginUID = "A123456789";
        String loginName = "XXXXXXX";
        String oldPassword = "1q2w3e4r";
        String newPassword = "5t6y7u8i";

        E2eeSessionKey sessionKey = e2eeApiHelper.buildSessionKey(apId);
        String encSessionKey = sessionKey.getEncryptedSessionKey();
        String encOldData = e2eeApiHelper.encryptData(sessionKey, oldPassword);
        String encNewData = e2eeApiHelper.encryptData(sessionKey, newPassword);
        String secData = this.getSecData(apId, oldPassword);

        PwdChangeRequest request = PwdChangeRequest.builder()
                .apId(apId)
                .encSessionKey(encSessionKey)
                .encOldData(encOldData)
                .encNewData(encNewData)
                .secData(secData)
                .customProperty("loginUID", loginUID)
                .customProperty("loginName", loginName)
                .build();

        PwdChangeResponse response = e2eeApiClient.pwdChange(request);
        log.debug("response : {}", response);
        // 新密碼密文
        String newSecData = response.getEncrypted();
        log.debug("newSecData : {}", newSecData);
        Assertions.assertEquals(SuipResponse.RTN_CODE_SUCCESS, response.getRtnCode());
    }

    @Test
    void testDescrypt() throws Throwable {
        String apId = "EWB";
        String password = "1q2w3e4r";
        E2eeSessionKey sessionKey = e2eeApiHelper.buildSessionKey(apId);
        String encData = e2eeApiHelper.encryptData(sessionKey, password);
        ISecDecryptRequest request = ISecDecryptRequest.builder()
                .apId(apId)
                .encSessionKey(sessionKey.getEncryptedSessionKey())
                .encData(encData)
                .build();
        ISecDecryptResponse response = e2eeApiClient.iSecDecrypt(request);
        log.debug("response : {}", response);
        String decryptedPassword = new String(Base64.decodeBase64(response.getDecrypted()));
        log.debug("decryptedPassword : {}", decryptedPassword);
        Assertions.assertEquals(password, decryptedPassword);
    }

    @Test
    void testAesKeyDescrypt() throws Throwable {
        String apId = "EWB";
        E2eeSessionKey sessionKey = e2eeApiHelper.buildSessionKey(apId);
        SecretKey aesKey = e2eeApiHelper.generateAesKey();
        String encData = e2eeApiHelper.encryptData(sessionKey, aesKey.getEncoded());
        ISecDecryptRequest request = ISecDecryptRequest.builder()
                .apId(apId)
                .encSessionKey(sessionKey.getEncryptedSessionKey())
                .encData(encData)
                .build();
        ISecDecryptResponse response = e2eeApiClient.iSecDecrypt(request);
        log.debug("response : {}", response);
        SecretKey decryptedAesKey = e2eeApiHelper.loadAesKey(response.getDecrypted());
        Assertions.assertArrayEquals(aesKey.getEncoded(), decryptedAesKey.getEncoded());
    }

    private String getSecData(String apId, String password) throws Throwable {
        E2eeSessionKey key = e2eeApiHelper.buildSessionKey(apId);
        String encData = e2eeApiHelper.encryptData(key, password);
        PwdSetRequest request = PwdSetRequest.builder()
                .apId(apId)
                .encSessionKey(key.getEncryptedSessionKey())
                .encData(encData)
                .build();
        PwdSetResponse response = e2eeApiClient.pwdSet(request);
        return response.getEncrypted();
    }

    @SpringBootApplication
    @EnableMcs
    @EnableMidJpa
    public static class SuipClientITConfigration {
    }

}
