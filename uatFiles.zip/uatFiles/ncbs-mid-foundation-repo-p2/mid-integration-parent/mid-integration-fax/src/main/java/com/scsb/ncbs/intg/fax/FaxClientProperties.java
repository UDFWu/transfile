package com.scsb.ncbs.intg.fax;

import org.springframework.boot.context.properties.ConfigurationProperties;

import com.scsb.ncbs.intg.client.cxf.CxfClientProperties;

import lombok.Data;

/**
 * 傳真參數設定
 */
@Data
@ConfigurationProperties(FaxClientProperties.CONFIG_PREFIX)
public class FaxClientProperties extends CxfClientProperties {
    public static final String CONFIG_PREFIX = "mid.integration.fax";
    private String owner;
}
