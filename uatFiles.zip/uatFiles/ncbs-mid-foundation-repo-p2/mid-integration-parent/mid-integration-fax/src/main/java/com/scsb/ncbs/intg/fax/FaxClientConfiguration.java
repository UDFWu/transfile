package com.scsb.ncbs.intg.fax;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ibm.cbmp.fabric.foundation.data.jpa.FabricJpaConfigurator;
import com.scsb.ncbs.core.data.jpa.EnableMidJpa;
import com.scsb.ncbs.core.sequence.EnableSeqTake;
import com.scsb.ncbs.intg.client.cxf.CxfClientFactoryBean;
import com.scsb.ncbs.intg.fax.client.RightFaxSoap;
import com.scsb.ncbs.intg.fax.service.FaxLogService;

/**
 * 傳真用戶端設定
 */
@Configuration
@EnableConfigurationProperties(FaxClientProperties.class)
@ConditionalOnProperty(prefix = FaxClientConfiguration.CONFIG_PREFIX, name = "enabled", havingValue = "true", matchIfMissing = true)
@EnableMidJpa
@EnableSeqTake
public class FaxClientConfiguration implements FabricJpaConfigurator {
    public static final String CONFIG_PREFIX = "mid.integration.fax";

    @Bean
    CxfClientFactoryBean<RightFaxSoap> rightFaxSoapFactoryBean(FaxClientProperties properties) {
        CxfClientFactoryBean<RightFaxSoap> factoryBean = new CxfClientFactoryBean<>();
        factoryBean.setObjectType(RightFaxSoap.class);
        factoryBean.setClientProperties(properties);
        factoryBean.getLoggingFeature().setRequestPayloadFilter(this::filterRequestPayload);
        factoryBean.getLoggingFeature().setResponsePayloadFilter(this::filterResponsePayload);
        return factoryBean;
    }

    @Bean
    FaxLogService faxLogService() {
        return new FaxLogService();
    }

    @Bean
    FaxClient faxClient() {
        return new FaxClient();
    }

    private String filterRequestPayload(String payload) {
        return payload.replaceAll("<FileData>.*</FileData>", "<FileData></FileData>");
    }

    private String filterResponsePayload(String payload) {
        return payload.replaceAll("<Attachment>.*</Attachment>", "<Attachment></Attachment>");
    }
}
