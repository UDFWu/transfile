package com.scsb.ncbs.intg.api.sms;

import java.nio.charset.StandardCharsets;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.core.convert.support.DefaultConversionService;
import org.springframework.http.converter.ObjectToStringHttpMessageConverter;

import com.ibm.cbmp.fabric.foundation.toolkit.CastUtils;
import com.scsb.ncbs.core.api.client.EnableMidApiClients;
import com.scsb.ncbs.intg.api.sms.bean.SmBulkSendRequestBody;
import com.scsb.ncbs.intg.api.sms.service.SmsAuthConfigProvider;
import com.scsb.ncbs.intg.api.sms.service.SmsAuthConfigProviderImpl;
import com.scsb.ncbs.intg.api.sms.service.SmsLogService;
import com.scsb.ncbs.intg.api.sms.service.SmsMessageService;

/**
 * 端點對端點加密機制API用戶端 Configuration
 */
@Configuration(proxyBeanMethods = false)
@EnableMidApiClients(basePackages = "com.scsb.ncbs.intg.api.sms")
@EnableConfigurationProperties(SmsApiProperties.class)
@ComponentScan
public class SmsApiAutoConfiguration {
    @Bean
    @ConditionalOnMissingBean(ObjectToStringHttpMessageConverter.class)
    ObjectToStringHttpMessageConverter smsObjectToStringHttpMessageConverter() {
        DefaultConversionService defaultConversionService = CastUtils.cast(DefaultConversionService.getSharedInstance());
        defaultConversionService.addConverter(
                new Converter<SmBulkSendRequestBody, String>() {
                    @Override
                    public String convert(SmBulkSendRequestBody source) {
                        return source.toString();
                    }
                });
        return new ObjectToStringHttpMessageConverter(DefaultConversionService.getSharedInstance(), StandardCharsets.UTF_8);
    }

    @Bean
    SmsAuthConfigProvider smsAuthConfigProvider() {
        return new SmsAuthConfigProviderImpl();
    }

    @Bean
    SmsLogService smsLogService() {
        return new SmsLogService();
    }

    @Bean
    SmsMessageService smsMessageService() {
        return new SmsMessageService();
    }
}
