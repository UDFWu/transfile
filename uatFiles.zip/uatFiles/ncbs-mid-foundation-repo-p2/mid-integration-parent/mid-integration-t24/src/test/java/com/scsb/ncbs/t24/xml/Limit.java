package com.scsb.ncbs.t24.xml;

import java.math.BigDecimal;
import java.util.List;

import lombok.Data;

@Data
public class Limit {
    @TagSpec(name = "id")
    private String id;
    @TagSpec(name = "c7")
    private String expiryDate;
    @TagSpec(name = "c140")
    private String serialNumber;
    @TagSpec(name = "c96")
    private String recordParent;
    private LimitAmounts limitAmounts;
    @TagSpec(name = "c40")
    private String limitCurrency;
    @TagSpec(name = "c100")
    private String limitProductId;

    @TagSpec(name = "c129")
    private String[] customerIds;

    @TagSpec(name = "c17")
    private String securedLimit;

    @TagSpec(name = "c65")
    private String availableMarker;

    @TagSpec(name = "c92")
    private String revolving;

    private List<Collateral> collaterals;

    @TagSpec(name = "c109", m = "2")
    private String[] stringArray;

    @Data
    public static class LimitAmounts {
        @TagSpec(name = "c62")
        private List<BigDecimal> limitAmount;
    }

    @Data
    public static class Collateral {
        @TagSpec(name = "c28")
        private String collateralRight;
        @TagSpec(name = "c29")
        private String securedAmount;
    }
}
