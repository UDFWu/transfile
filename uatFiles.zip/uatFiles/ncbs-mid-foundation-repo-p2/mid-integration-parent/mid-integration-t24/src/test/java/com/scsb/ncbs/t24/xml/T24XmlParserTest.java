package com.scsb.ncbs.t24.xml;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.scsb.ncbs.t24.exception.T24Exception;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class T24XmlParserTest {

    @Test
    void testParse() {
        String xml = "<row id='LI231161T8YX'><c1>TWD</c1><c2>TW</c2><c3>100</c3><c4>20230426</c4><c5>20230426</c5><c6>20240426M0101</c6><c7>20240426</c7><c9>20230426</c9><c10>20230426</c10><c12>1</c12><c13>100</c13><c15>1000000</c15><c17>FIXED</c17><c18>390</c18><c24>1000000</c24><c26>1000000</c26><c27>0</c27><c28>COR23116W0XGM</c28><c28 m='1' s='2'>COR23116NMSGG</c28><c29>0</c29><c29 m='1' s='2'>1000000</c29><c32>1000000</c32><c34>-500000</c34><c37>500000</c37><c40>TWD</c40><c41>-500000</c41><c62>1000000</c62><c65>Y</c65><c73>10310</c73><c74>100</c74><c92>Y</c92><c93>1</c93><c94>TB</c94><c96>LI23116KZJVN</c96><c97>LI23116KZJVN</c97><c98>Y</c98><c100>1021</c100><c101>NO</c101><c109>NO</c109><c109 m='2'>100065</c109><c109 m='2' s='2'>100066</c109><c109 m='6'>1</c109><c109 m='6' s='2'>2</c109><c109 m='11'>XX001</c109><c109 m='62'>326</c109><c109 m='62' s='2'>101</c109><c109 m='62' s='3'>102</c109><c109 m='69'>TW0010006</c109><c109 m='102'>71</c109><c109 m='102' s='2'>50</c109><c109 m='102' s='3'>51</c109><c109 m='166'></c109><c122>24</c122><c129>100062</c129><c130>NO</c130><c140>01</c140><c157>INAU</c157><c158>2</c158><c159>270_DANIEL.1__OFS_BROWSERTC</c159><c160>2501060917</c160><c162>TW0019998</c162><c163>1</c163><c170>20230426</c170><c172>20231226#-500000</c172></row>";
        T24XmlParser parser = new T24XmlParser();
        Limit limit = parser.parse(xml, Limit.class);
        log.debug("limit : {}", limit);
        Assertions.assertEquals("LI231161T8YX", limit.getId());
        Assertions.assertEquals("TWD", limit.getLimitCurrency());
        Assertions.assertEquals("20240426", limit.getExpiryDate());
        Assertions.assertEquals("01", limit.getSerialNumber());
        Assertions.assertEquals("LI23116KZJVN", limit.getRecordParent());
        Assertions.assertArrayEquals(new String[] {"100065", "100066" }, limit.getStringArray());
    }

    @Test
    void testParseError() {
        T24XmlParser parser = new T24XmlParser();
        Assertions.assertThrows(T24Exception.class, () -> {
            parser.parse("xml", Limit.class);
        }, "XML格式錯誤");
    }
}
