package com.scsb.ncbs.t24.processor;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.ObjectProvider;
import org.springframework.core.annotation.Order;

import com.scsb.ncbs.core.processor.Processor;
import com.scsb.ncbs.core.processor.ProcessorChain;
import com.scsb.ncbs.core.utils.MidCollectionUtils;
import com.scsb.ncbs.t24.T24ResponseHeaderAware;
import com.scsb.ncbs.t24.annotation.T24Component;
import com.scsb.ncbs.t24.checker.T24ResponseChecker;
import com.scsb.ncbs.t24.model.T24Response;
import com.scsb.ncbs.t24.support.T24RequestContext;

@T24Component
@Order(T24ProcessorOrderConstants.T24_RESPONSE_PROCESSOR)
public class T24ResponseProcessor implements Processor<T24RequestContext> {
    private List<T24ResponseChecker> responseCheckerList;

    public T24ResponseProcessor(ObjectProvider<T24ResponseChecker> provider) {
        this.responseCheckerList = provider.orderedStream().collect(Collectors.toList());
    }

    public void process(T24RequestContext context, ProcessorChain<T24RequestContext> chain) {
        T24Response<?> response = context.getResponse();
        this.checkT24Error(response);
        if (response.getBody() instanceof T24ResponseHeaderAware) {
            T24ResponseHeaderAware t24ResponseHeaderAware = (T24ResponseHeaderAware) response.getBody();
            t24ResponseHeaderAware.receiveT24ResponseHeader(response.getHeader());
        } else if (response.getBody() instanceof List) {
            List<?> bodyList = (List<?>) response.getBody();
            if (MidCollectionUtils.firstElement(bodyList) instanceof T24ResponseHeaderAware) {
                bodyList.forEach(item -> {
                    T24ResponseHeaderAware t24ResponseHeaderAware = (T24ResponseHeaderAware) item;
                    t24ResponseHeaderAware.receiveT24ResponseHeader(response.getHeader());
                });
            }
        }
    }

    private void checkT24Error(T24Response<?> response) {
        responseCheckerList.stream().forEach(checker -> checker.check(response));
    }
}
