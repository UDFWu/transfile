package com.scsb.ncbs.t24.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Stream;

import org.springframework.data.domain.Pageable;

import com.ibm.cbmp.fabric.foundation.facade.bean.MessageInfo;
import com.scsb.ncbs.core.utils.MidDateUtils;
import com.scsb.ncbs.core.utils.MidObjectUtils;
import com.scsb.ncbs.core.utils.MidStringUtils;
import com.scsb.ncbs.t24.constant.T24FunctionEnum;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Singular;

/**
 * T24請求資料
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class T24Request {
    public static final int DEFAULT_PAGE_SIZE = 3000;
    /**
     * T24功能代碼
     */
    private T24FunctionEnum function;
    /**
     * T24檢核
     */
    private Boolean validateOnly;
    /**
     * 帳號/密碼
     */
    private String credentials;
    /**
     * T24分行代碼
     */
    private String companyId;
    /**
     * T24分行代碼，若companyId無值時，使用此值查詢T24_PARAM取得對應的compmayId
     */
    private String branchId;
    private String deviceId;
    /**
     * 授權次數
     */
    private Integer numberOfAuthorisers;
    /**
     * 通路
     */
    @Default
    private String channelName = "MID";
    /**
     * 分頁件
     */
    private Pageable page;
    private String uniqueIdentifier;

    /**
     * 是否為高頻查詢
     */
    private boolean highFrequencyQuery;

    /**
     * HTTP URI參數
     */
    @Singular
    private Map<String, String> uriVariables = new HashMap<>();
    /**
     * HTTP Header參數
     */
    @Singular
    private Map<String, String> httpHeaders = new HashMap<>();
    /**
     * HTTP 查詢參數
     */
    @Singular
    private Map<String, String> queryParams = new HashMap<>();

    /**
     * Override
     */
    @Singular
    private List<MessageInfo> overrides = new ArrayList<>();

    /**
     * HTTP 請求資料
     */
    private Object requestBodyContent;

    /**
     * 是否自動override，注意只會自動執行一次override
     */
    private boolean autoOverride;

    /**
     * 分頁查詢大小
     */
    private Integer pageSize;

    /**
     * 要查詢的分頁
     */
    private Integer pageStart;

    /**
     * 分頁Token
     */
    private String pageToken;

    /**
     * Returns the page to be returned.
     */
    public Integer getPageStart() {
        if (page != null) {
            return page.getPageNumber() + 1;
        }
        return pageStart;
    }

    /**
     * Returns the number of items to be returned.
     */
    public Integer getPageSize() {
        if (page != null) {
            return page.getPageSize();
        }
        return Objects.requireNonNullElse(pageSize, DEFAULT_PAGE_SIZE);
    }

    public static class T24RequestBuilder {
        public T24RequestBuilder queryParamValues(String name, String... values) {
            return this.queryParam(name, MidStringUtils.joinWith(MidStringUtils.SPACE, (Object[]) values));
        }

        public T24RequestBuilder queryParamValues(String name, LocalDate... values) {
            String[] stringValues = Stream.of(values).map(MidDateUtils.YYYYMMDD::format).toArray(String[]::new);
            return this.queryParamValues(name, stringValues);
        }

        public T24RequestBuilder variable(String name, String value) {
            this.uriVariable(name, value);
            return this;
        }
    }

    /**
     * 設定資料到uriVariables
     * 
     * @param kxy
     * @param value
     */
    public void putUriVariables(String kxy, String value) {
        if (MidObjectUtils.isEmpty(uriVariables)) {
            uriVariables = new HashMap<>();
        }

        uriVariables.put(kxy, value);
    }

    /**
     * 設定資料到httpHeaders
     * 
     * @param kxy
     * @param value
     */
    public void putHttpHeaders(String kxy, String value) {
        if (MidObjectUtils.isEmpty(httpHeaders)) {
            httpHeaders = new HashMap<>();
        }

        httpHeaders.put(kxy, value);
    }

    /**
     * 設定資料到queryParams
     * 
     * @param kxy
     * @param value
     */
    public void putQueryParams(String kxy, String value) {
        if (MidObjectUtils.isEmpty(queryParams)) {
            queryParams = new HashMap<>();
        }

        queryParams.put(kxy, value);
    }

    /**
     * 設定資料到queryParams
     * 
     * @param kxy
     * @param value
     */
    public void putQueryParams(String kxy, String... values) {
        if (MidObjectUtils.isEmpty(queryParams)) {
            queryParams = new HashMap<>();
        }
        queryParams.put(kxy, MidStringUtils.joinWith(MidStringUtils.SPACE, (Object[]) values));
    }

    /**
     * 設定資料到queryParams
     * 
     * @param kxy
     * @param value
     */
    public void putQueryParams(String kxy, LocalDate... values) {
        String[] stringValues = Stream.of(values).map(MidDateUtils.YYYYMMDD::format).toArray(String[]::new);
        this.putQueryParams(kxy, stringValues);
    }

    /**
     * 新增資料到overrides
     * 
     * @param msgInfo
     */
    public void addOverrides(MessageInfo msgInfo) {
        if (MidObjectUtils.isEmpty(overrides)) {
            overrides = new ArrayList<>();
        }

        if (!MidObjectUtils.isEmpty(msgInfo)) {
            overrides.add(msgInfo);
        }
    }
}
