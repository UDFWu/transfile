package com.scsb.ncbs.t24.enums;

import org.springframework.http.HttpMethod;

import com.ibm.cbmp.fabric.foundation.enums.ICode;

import lombok.Getter;

/**
 * T24 User-defined HTTP Request Header
 */
public enum T24HeaderEnum implements ICode {
    /** CREDENTIALS **/
    CREDENTIALS(T24HeaderTypeEnum.HTTP, "credentials", "credentials", "帳密"),
    /** COMPANY_ID **/
    COMPANY_ID(T24HeaderTypeEnum.HTTP, "companyId", "companyId", "分行別"),
    /** COMPANY_ID **/
    DEVICE_ID(T24HeaderTypeEnum.HTTP, "deviceId", "deviceId", "未知"),
    /** CONTENT_TYPE **/
    CONTENT_TYPE(T24HeaderTypeEnum.HTTP, "Content-Type", "contentType", "內容類型"),
    /** VALIDATE_ONLY **/
    VALIDATE_ONLY(T24HeaderTypeEnum.HTTP, "validate_only", "validateOnly", "是否需要Validation"),
    /** UNIQUE_IDENTIFIER **/
    UNIQUE_IDENTIFIER(T24HeaderTypeEnum.HTTP, "uniqueIdentifier", "uniqueIdentifier", "各介接系統自訂"),
    /** PAGE_START **/
    PAGE_NUMBER(T24HeaderTypeEnum.QUERY, "page_start", "pageStart", "頁數", HttpMethod.GET),
    /** PAGE_SIZE **/
    PAGE_SIZE(T24HeaderTypeEnum.QUERY, "page_size", "pageSize", "回傳筆數", HttpMethod.GET),
    /** PAGE_TOKEN **/
    PAGE_TOKEN(T24HeaderTypeEnum.QUERY, "page_token", "pageToken", "分頁TOKEN", HttpMethod.GET),
    /** CHANNEL_NAME **/
    CHANNEL_NAME(T24HeaderTypeEnum.HTTP, "channelName", "channelName", "通路"),
    /** NUMBER_OF_AUTHORISERS **/
    NUMBER_OF_AUTHORISERS(T24HeaderTypeEnum.HTTP, "numberOfAuthorisers", "numberOfAuthorisers", "授權次數"),
    ;

    /** name **/
    @Getter
    private String name;

    /** property **/
    @Getter
    private String property;

    /** description **/
    @Getter
    private String description;

    @Getter
    private T24HeaderTypeEnum type;

    @Getter
    private HttpMethod[] httpMethods;

    T24HeaderEnum(T24HeaderTypeEnum type, String name, String property, String description) {
        this.type = type;
        this.name = name;
        this.property = property;
        this.description = description;
    }

    T24HeaderEnum(T24HeaderTypeEnum type, String name, String property, String description, HttpMethod... httpMethods) {
        this.type = type;
        this.name = name;
        this.property = property;
        this.httpMethods = httpMethods;
        this.description = description;
    }

    @Override
    public String getCode() {
        return name;
    }
}