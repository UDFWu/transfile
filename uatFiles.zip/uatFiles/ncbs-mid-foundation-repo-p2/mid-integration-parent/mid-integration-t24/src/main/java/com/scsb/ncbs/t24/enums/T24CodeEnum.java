package com.scsb.ncbs.t24.enums;

import com.ibm.cbmp.fabric.foundation.enums.IReturnCodeDescEnum;
import com.ibm.cbmp.fabric.foundation.enums.api.SeverityEnum;

import lombok.Getter;

/**
 * 狀態代碼列舉
 */
@Getter
public enum T24CodeEnum implements IReturnCodeDescEnum {
    /**
     * T24執行失敗
     */
    ERROR("T240001", SeverityEnum.ERROR, "T24執行失敗 : %s"),

    /**
     * T24檢核錯誤訊息
     */
    VALIDATION_ERROR("T240002", SeverityEnum.ERROR, "T24檢核失敗"),
    /**
     * T24檢核警示訊息
     */
    VALIDATION_WARNING("T240003", SeverityEnum.WARN, "T24檢核失敗"),

    /**
     * T24未回傳Response
     */
    EMPTY_RESPONSE("T240004", SeverityEnum.ERROR, "T24未回傳下行電文"),

    /**
     * T24執行失敗
     */
    HTTP_RESPONSE_ERROR("T240005", SeverityEnum.ERROR, "T24 HTTP連線錯誤 : %s"),

    /**
     * T24資料未異動
     */
    RECORD_NOT_CHANGED("T240006", SeverityEnum.ERROR, "Record Not Changed"),

    /**
     * 查無T24分行代碼
     */
    COMPANY_ID_NOT_FOUND("T240007", SeverityEnum.ERROR, "查無T24分行代碼 : %s"),

    /**
     * T24資料未異動
     */
    XML_ERROR("T240008", SeverityEnum.ERROR, "解析T24 XML時發生異常"),

    /**
     * Resource not found
     */
    RESOURCE_NOT_FOUND("T240009", SeverityEnum.ERROR, "Resource not found"),

    /**
     * Resource not found
     */
    RESPONE_STATUS_ERROR("T240010", SeverityEnum.ERROR, "T24回傳的狀態碼不正確"),

    /**
     * T24發生未預期錯誤
     */
    UNDEFINED("T249999", SeverityEnum.ERROR, "連接T24發生未預期錯誤"),
    ;

    private String code;
    private SeverityEnum severity;
    private String desc;

    private T24CodeEnum(String code, SeverityEnum severity, String desc) {
        this.code = code;
        this.severity = severity;
        this.desc = desc;
    }

    @Override
    public SeverityEnum getSeverity() {
        return this.severity;
    }

    @Override
    public String getDesc() {
        return this.desc;
    }
}
