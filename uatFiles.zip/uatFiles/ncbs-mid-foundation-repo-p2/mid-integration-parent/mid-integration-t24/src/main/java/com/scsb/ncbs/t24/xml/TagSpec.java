package com.scsb.ncbs.t24.xml;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * T24 XML欄位設定
 */
@Target({ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
public @interface TagSpec {
    /**
     * XML Tag名稱
     */
    String name();

    /**
     * MultiValue屬性值
     */
    String m() default "";
}
