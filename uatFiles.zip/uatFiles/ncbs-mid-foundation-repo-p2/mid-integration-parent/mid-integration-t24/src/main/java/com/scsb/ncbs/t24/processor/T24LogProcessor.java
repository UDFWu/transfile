package com.scsb.ncbs.t24.processor;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;

import com.ibm.cbmp.fabric.foundation.api.RequestContext;
import com.ibm.cbmp.fabric.foundation.enums.api.ApiCodeEnum;
import com.ibm.cbmp.fabric.foundation.exception.ExceptionUtils;
import com.ibm.cbmp.fabric.foundation.exception.TxnException;
import com.ibm.cbmp.fabric.foundation.http.client.RestApiMessage;
import com.ibm.cbmp.fabric.foundation.toolkit.ExtDateUtils;
import com.scsb.ncbs.core.processor.Processor;
import com.scsb.ncbs.core.processor.ProcessorChain;
import com.scsb.ncbs.t24.annotation.T24Component;
import com.scsb.ncbs.t24.enums.T24CodeEnum;
import com.scsb.ncbs.t24.model.T24Request;
import com.scsb.ncbs.t24.persistence.entity.T24MsgLogEntity;
import com.scsb.ncbs.t24.support.T24LogService;
import com.scsb.ncbs.t24.support.T24RequestContext;

import lombok.extern.slf4j.Slf4j;

@T24Component
@Slf4j
@Order(T24ProcessorOrderConstants.T24_LOG_PROCESSOR)
public class T24LogProcessor implements Processor<T24RequestContext> {
    @Autowired(required = false)
    private RequestContext requestContext;

    @Autowired
    private T24LogService t24LogService;

    @Override
    public void process(T24RequestContext context, ProcessorChain<T24RequestContext> chain) {
        try {
            chain.process(context);
        } catch (Exception e) {
            TxnException exnException = ExceptionUtils.handleException(e, T24CodeEnum.UNDEFINED, e.getMessage());
            context.setTxnException(exnException);
            throw e;
        } finally {
            this.log(context);
        }
    }

    private void log(T24RequestContext context) {
        try {
            T24Request request = context.getRequest();
            T24MsgLogEntity entity = new T24MsgLogEntity();
            entity.setBusinessType(StringUtils.truncate(request.getFunction().getBusinessType(), 20));
            entity.setFunctionCode(StringUtils.truncate(request.getFunction().getFunctionCode(), 50));
            if (requestContext != null) {
                entity.setGuid(requestContext.getGuid());
            }
            RestApiMessage message = context.getRestApiMessage();
            if (message != null) {
                entity.setRequestUri(StringUtils.truncate(message.getRequestURI(), 500));
                entity.setRequestHeaders(StringUtils.truncate(message.getRequestHeader(), 2000));
                entity.setRequestBody(message.getRequestBody());
                entity.setResponseHeaders(StringUtils.truncate(message.getResponseHeader(), 2000));
                entity.setResponseBody(message.getResponseBody());
                entity.setStatusCode(StringUtils.truncate(message.getStatusCode(), 3));
                entity.setStartTimestamp(ExtDateUtils.toLocalDateTime(message.getStartTime()));
                entity.setEndTimestamp(ExtDateUtils.toLocalDateTime(message.getEndTime()));
            }
            TxnException txnException = context.getTxnException();
            if (txnException != null) {
                entity.setResultCode(txnException.getCodeEnum().getCode());
                entity.setErrorMsg(StringUtils.truncate(ExceptionUtils.getStackTrace(txnException), 2000));
            } else {
                entity.setResultCode(ApiCodeEnum.SUCCESS.getCode());
            }
            t24LogService.addT24MsgLog(entity);
        } catch (Exception e) {
            log.warn("failed to log t24 message : {}", e.getMessage(), e);
        }
    }

}
