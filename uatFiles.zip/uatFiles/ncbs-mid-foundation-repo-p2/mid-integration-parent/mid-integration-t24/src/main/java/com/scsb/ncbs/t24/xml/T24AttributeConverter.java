package com.scsb.ncbs.t24.xml;

import javax.persistence.AttributeConverter;

/**
 * T24 JPA AttributeConverter
 */
public abstract class T24AttributeConverter<T> implements AttributeConverter<T, String> {
    private static final T24XmlParser t24XmlParser = new T24XmlParser();

    @Override
    public String convertToDatabaseColumn(T attribute) {
        return null;
    }

    @Override
    public T convertToEntityAttribute(String dbData) {
        return t24XmlParser.parse(dbData, this.getAttributeType());
    }

    protected abstract Class<T> getAttributeType();
}
