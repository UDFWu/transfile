package com.scsb.ncbs.t24.xml;

import java.lang.reflect.Field;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.springframework.core.ResolvableType;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ibm.cbmp.fabric.foundation.toolkit.JsonUtils;
import com.ibm.cbmp.fabric.foundation.toolkit.ReflectionUtils;
import com.scsb.ncbs.t24.enums.T24CodeEnum;
import com.scsb.ncbs.t24.exception.T24Exception;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * T24 XML Parser
 */
@Slf4j
public class T24XmlParser {
    /**
     * 解析T24 XML
     * @param <T> 資料型別
     * @param xml XML
     * @param type 要解析的資料型別
     * @return 處理結果
     */
    public <T> T parse(String xml, Class<T> resultType) {
        try {
            ParserContext context = new ParserContext(resultType);
            Document doc = DocumentHelper.parseText(xml);
            String id = doc.getRootElement().attributeValue("id");
            if (id != null) {
                this.processElement("id", null, null, id, context);
            }
            doc.getRootElement().elements().forEach(element -> {
                String name = element.getName();
                String m = element.attributeValue("m");
                String s = element.attributeValue("s");
                String value = element.getText();
                this.processElement(name, m, s, value, context);
            });
            if (log.isDebugEnabled()) {
                log.debug("json : {}", JsonUtils.toJson(context.getResultNode()));
            }
            return new ObjectMapper().convertValue(context.getResultNode(), resultType);
        } catch (DocumentException e) {
            throw new T24Exception(T24CodeEnum.XML_ERROR, e);
        }
    }

    private void processElement(String name, String m, String s, String value, ParserContext context) {
        FieldConfig mapping = context.findFieldConfig(name, m);
        if (mapping == null) {
            return;
        }
        ObjectNode parent = this.findParrentNode(mapping, context.getResultNode(), m, s);
        Field field = mapping.getField();
        if (field.getType().isArray() || Collection.class.isAssignableFrom(field.getType())) {
            ArrayNode array = (ArrayNode) parent.get(field.getName());
            if (array == null) {
                array = new ArrayNode(JsonNodeFactory.instance);
                parent.set(field.getName(), array);
            }
            array.add(value);
        } else {
            parent.put(field.getName(), value);
        }
    }

    private ObjectNode findParrentNode(FieldConfig fieldConfig, ObjectNode parentNode, String m, String s) {
        if (fieldConfig.getParent() == null) {
            return parentNode;
        }

        FieldConfig parentFieldConfig = fieldConfig.getParent();
        if (parentFieldConfig.getParent() != null) {
            parentNode = this.findParrentNode(parentFieldConfig, parentNode, m, s);
        }

        Field field = parentFieldConfig.getField();
        if (field.getType().isArray() || Collection.class.isAssignableFrom(field.getType())) {
            ArrayNode arrayNode = (ArrayNode) parentNode.get(field.getName());
            if (arrayNode == null) {
                arrayNode = new ArrayNode(JsonNodeFactory.instance);
                parentNode.set(field.getName(), arrayNode);
            }
            int index = this.getArrayIndex(fieldConfig.getSpec().m(), m, s);
            while (arrayNode.size() <= index) {
                arrayNode.addObject();
            }
            return (ObjectNode) arrayNode.get(index);
        } else {
            ObjectNode objectNode = (ObjectNode) parentNode.get(field.getName());
            if (objectNode == null) {
                objectNode = new ObjectNode(JsonNodeFactory.instance);
                parentNode.set(field.getName(), objectNode);
            }
            return objectNode;
        }
    }

    private int getArrayIndex(String mv, String m, String s) {
        if (StringUtils.isNotBlank(mv)) {
            return Integer.parseInt(StringUtils.defaultString(s, "1")) - 1;
        } else {
            return Integer.parseInt(StringUtils.defaultString(m, "1")) - 1;
        }
    }

    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @Data
    private static class FieldConfig {
        private FieldConfig parent;
        private Field field;
        private TagSpec spec;
    }

    private static class ParserContext {
        Map<String, FieldConfig> fieldConfigMap = new HashMap<>();
        @Getter
        private ObjectNode resultNode = new ObjectNode(JsonNodeFactory.instance);

        public ParserContext(Class<?> type) {
            this.initFieldConfig(type, null);
        }

        public FieldConfig findFieldConfig(String name, String m) {
            if (StringUtils.isNotBlank(m)) {
                FieldConfig mapping = fieldConfigMap.get(this.buildFieldConfigKey(name, m));
                if (mapping != null) {
                    return mapping;
                }
            }
            return fieldConfigMap.get(name);
        }

        private void initFieldConfig(Class<?> type, FieldConfig parent) {
            ReflectionUtils.doWithFields(type, field -> {
                TagSpec spec = field.getAnnotation(TagSpec.class);
                FieldConfig mapping = FieldConfig.builder()
                        .parent(parent)
                        .field(field)
                        .spec(spec)
                        .build();
                if (spec != null) {
                    fieldConfigMap.put(this.buildFieldConfigKey(spec), mapping);
                } else {
                    if (field.getType().isArray()) {
                        this.initFieldConfig(field.getType().getComponentType(), mapping);
                    } else if (Collection.class.isAssignableFrom(field.getType())) {
                        Class<?> componentType = ResolvableType.forField(field).getGeneric(0).getRawClass();
                        this.initFieldConfig(componentType, mapping);
                    } else {
                        this.initFieldConfig(field.getType(), mapping);
                    }
                }
            });
        }

        private String buildFieldConfigKey(TagSpec spec) {
            return this.buildFieldConfigKey(spec.name(), spec.m());
        }

        private String buildFieldConfigKey(String tag, String m) {
            if (StringUtils.isBlank(m)) {
                return tag;
            } else {
                return tag + "." + m;
            }
        }
    }

}
