package com.scsb.ncbs.intg.client.ldap;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.scsb.ncbs.intg.client.ldap.bean.OrgUnit;
import com.scsb.ncbs.intg.client.ldap.bean.Person;
import com.scsb.ncbs.intg.config.MidLdapProperties;

/**
 * LDAP Client接口
 *
 * @Author IBM
 * @Date: 2024/01/24
 */
public class LdapClient extends AbstractLdapClient {

    @Autowired
    private MidLdapProperties ldapProperties;

    /**
     * 查詢員工組織資訊
     *
     * @param ou 組織編號
     * @return OrgUnit
     */
    public OrgUnit getOrgUnit(String ou) {
        return searchForObject(ldapProperties.getBase(), String.format("(&(objectClass=organizationalUnit)(ou=%s))", ou), OrgUnit.class);
    }

    /**
     * 查詢員工資訊
     *
     * @param userId 員工編號
     * @return Person
     */
    public Person getPerson(String userId) {
        return searchForObject(ldapProperties.getBase(), String.format("(&(objectClass=%s)(cn=%s*))", ldapProperties.getPersonObjectClass(), userId), Person.class);
    }

    /**
     * 查詢該部門下所屬成員清單
     *
     * @param departmentNumber 部門編號ID(ex:01500)
     * @return
     */
    public List<Person> getPersonsByDeptNo(String departmentNumber) {
        return searchForList(ldapProperties.getBase(),
                String.format("(&(objectClass=%s)(departmentNumber=%s))", ldapProperties.getPersonObjectClass(), departmentNumber), attrs -> {
                    Person person = new Person();
                    person.setCn((String) attrs.get("cn").get());
                    if (attrs.get("cardtitle") != null)
                        person.setCardtitle((String) attrs.get("cardtitle").get());
                    if (attrs.get("givenName") != null)
                        person.setGivenName((String) attrs.get("givenName").get());
                    if (attrs.get("departmentNumber") != null)
                        person.setDepartmentNumber((String) attrs.get("departmentNumber").get());
                    if (attrs.get("departmentName") != null)
                        person.setDepartmentName((String) attrs.get("departmentName").get());
                    if (attrs.get("carLicense") != null)
                        person.setCarLicense((String) attrs.get("carLicense").get());
                    if (attrs.get("notesAccount") != null)
                        person.setNotesAccount((String) attrs.get("notesAccount").get());
                    if (attrs.get("mail") != null)
                        person.setMail((String) attrs.get("mail").get());
                    if (attrs.get("observer") != null)
                        person.setObserver((String) attrs.get("observer").get());
                    if (attrs.get("observer2") != null)
                        person.setObserver2((String) attrs.get("observer2").get());
                    return person;
                });
    }

    /**
     * 查詢 完整 User ID
     *
     * @param userId 員工編號 userId + *, ex:3644*
     * @return User Full ID
     */
    public String getFullUserId(String userId) {
        Person person = getPerson(userId);
        if (person != null) {
            return person.getCn();
        }

        return null;
    }

    /**
     * 取得身份證字號
     *
     * @param userId 員工編號
     * @return 身份證字號
     */
    public String getUserCardLicense(String userId) {
        Person person = getPerson(userId);
        if (person != null)
            return person.getCarLicense();
        else
            return null;
    }

    /**
     * email
     *
     * @param userId 員工編號
     * @return email
     */
    public String getMail(String userId) {
        Person person = getPerson(userId);
        if (person != null)
            return person.getMail();
        else
            return null;
    }

    /**
     * 取得職稱
     *
     * @param userId 員工編號
     * @return 職稱
     */
    public String getUserCardTitle(String userId) {
        Person person = getPerson(userId);
        if (person != null)
            return person.getCardtitle();
        else
            return null;
    }

}
