package com.scsb.ncbs.intg.component;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.scsb.ncbs.intg.client.ldap.LdapClient;
import com.scsb.ncbs.intg.client.ldap.bean.Person;

/**
 * LDAP Helper
 *
 * @author IBM
 */
public class LdapHelper {

    @Autowired
    private LdapClient ldapClient;

    /**
     * 查詢該部門下所屬法遵主管清單
     *
     * @param deptNo 部門代號
     * @return 法遵主管清單
     */
    public List<Person> getComplianceManagersByDeptNo(String deptNo) {
        List<Person> persons = ldapClient.getPersonsByDeptNo(deptNo);
        if (ObjectUtils.isNotEmpty(persons)) {
            return persons.stream().filter(p -> StringUtils.isNotEmpty(p.getObserver()) || StringUtils.isNotEmpty(p.getObserver2())).collect(Collectors.toList());
        }
        return null;
    }
}
