package com.scsb.ncbs.intg.config;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;

import com.scsb.ncbs.intg.client.ldap.LdapClient;
import com.scsb.ncbs.intg.component.LdapHelper;

/**
 * LDAP 相關設定
 *
 * @Author IBM
 * @Date 2024/01/24
 */
@Configuration
@EnableConfigurationProperties(MidLdapProperties.class)
@ConditionalOnProperty(name = "ldap.enabled", havingValue = "true", matchIfMissing = false)
public class MidLdapConfiguration {
    @Bean
    LdapContextSource contextSource(MidLdapProperties ldapProperties) {
        LdapContextSource contextSource = new LdapContextSource();
        contextSource.setUrl(ldapProperties.getUrl());
        contextSource.setUserDn(ldapProperties.getUser());
        contextSource.setPassword(ldapProperties.getPassword());
        return contextSource;
    }

    @Bean
    LdapTemplate ldapTemplate(LdapContextSource contextSource) {
        return new LdapTemplate(contextSource);
    }

    @Bean
    LdapClient ldapClient() {
        return new LdapClient();
    }

    @Bean
    LdapHelper ldapHelper() {
        return new LdapHelper();
    }
}
