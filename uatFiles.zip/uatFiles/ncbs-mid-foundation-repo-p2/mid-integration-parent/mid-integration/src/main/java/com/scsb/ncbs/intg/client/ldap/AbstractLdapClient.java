package com.scsb.ncbs.intg.client.ldap;

import java.util.List;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;

import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.DirContextAdapter;
import org.springframework.ldap.core.LdapTemplate;

import com.scsb.ncbs.intg.client.BaseClient;

/**
 * LDAP Client 抽象物件
 *
 * @Author IBM
 * @Date 2024/01/24
 */
public abstract class AbstractLdapClient extends BaseClient {

    public class ContextMapper<B> implements org.springframework.ldap.core.ContextMapper<B> {

        private final Class<? extends B> rsClazz;

        private ContextMapper(Class<? extends B> rsClazz) {
            this.rsClazz = rsClazz;
        }

        @SuppressWarnings("unchecked")
        @Override
        public B mapFromContext(Object ctx) throws NamingException {
            BeanWrapper beanWrapper = new BeanWrapperImpl(rsClazz);
            try {

                DirContextAdapter dirContextAdapter = (DirContextAdapter) ctx;
                NamingEnumeration<? extends Attribute> namingEnumeration = dirContextAdapter.getAttributes().getAll();

                while (namingEnumeration.hasMoreElements()) {
                    Attribute attribute = namingEnumeration.next();

                    if (beanWrapper.isWritableProperty(attribute.getID())) {
                        beanWrapper.setPropertyValue(attribute.getID(), attribute.get());
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            return (B) beanWrapper.getWrappedInstance();
        }
    }

    @Autowired
    private LdapTemplate ldapTemplate;

    protected <B> B searchForObject(String base, String filter, Class<? extends B> rsClazz) {
        return ldapTemplate.searchForObject(base, filter, new ContextMapper<B>(rsClazz));
    }

    protected <T> List<T> searchForList(String base, String filter, AttributesMapper<T> mapper) {
        return ldapTemplate.search(base, filter, mapper);
    }
}
