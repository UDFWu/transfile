package com.scsb.ncbs.intg.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Data;

/**
 * LDAP 設定參數檔
 */
@ConfigurationProperties("ldap")
@Data
public class MidLdapProperties {
    /**
     * 是否啟用ldap設定
     */
    private boolean enabled;
    /**
     * 網址
     */
    private String url;
    /**
     * 帳號
     */
    private String user;
    /**
     * 密碼
     */
    private String password;
    /**
     * 搜尋ldap時的基本識別名稱
     */
    private String base;

    /**
     * 搜尋ldap時的物件類別
     */
    private String personObjectClass;
}
