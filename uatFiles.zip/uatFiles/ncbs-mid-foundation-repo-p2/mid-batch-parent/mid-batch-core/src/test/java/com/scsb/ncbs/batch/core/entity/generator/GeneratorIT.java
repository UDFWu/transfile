package com.scsb.ncbs.batch.core.entity.generator;

import org.junit.jupiter.api.Test;

import com.wise.generator.CodeGenerator;
import com.wise.generator.config.CodeGeneratorConfig;

class GeneratorIT {
    @Test
    void generatorExp() throws Exception {
        CodeGeneratorConfig config = CodeGeneratorConfig.load("entity/generator/generator-exp.yml");
        config.setPackageName("com.scsb.ncbs.batch.core.persistence.entity");
        config.setRepositoryPackageName("com.scsb.ncbs.batch.core.persistence.repository");
        CodeGenerator.generateAll(config, false);
    }

}
