package com.scsb.ncbs.batch.core;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 批次執行參數
 */
@Data
@NoArgsConstructor
public class MidJobParameter {
    private String jobCode;
    private String jobName;
    private LocalDate runDate;
    private LocalDateTime runDateTime;
    private Map<String, Object> params = new HashMap<>();
    private boolean forceRun;
}
