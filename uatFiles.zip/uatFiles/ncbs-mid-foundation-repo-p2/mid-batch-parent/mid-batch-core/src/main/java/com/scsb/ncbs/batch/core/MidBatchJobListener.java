package com.scsb.ncbs.batch.core;

import java.text.MessageFormat;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ibm.cbmp.fabric.foundation.exception.ExceptionUtils;
import com.ibm.cbmp.fabric.foundation.exception.TxnException;
import com.scsb.ncbs.batch.core.enums.BatchStatusCodeEnum;
import com.scsb.ncbs.batch.core.service.bean.BatchControl;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class MidBatchJobListener implements JobExecutionListener {
    private static final String BATCH_RESULT_PATTERN = "總筆數:{0}, 成功筆數:{1}, 失敗筆數:{2}, 忽略筆數:{3}";

    @Autowired
    private MidJobService jobService;

    @Autowired
    private MidBatchContext midBatchContext;

    @Autowired
    private MidJobParameter midJobParameter;

    @Override
    public void beforeJob(JobExecution jobExecution) {
        BatchControl batchControl = midBatchContext.getBatchControl();
        log.info("midJobParameter : {}", jobExecution.getJobParameters().getParameters());
        log.info("Job Start : jobCode:{}, jobExecutionId:{}, batchControlId:{}", midJobParameter.getJobCode(), jobExecution.getJobId(), batchControl.getBatchControlId());
        batchControl.setStatusCode(BatchStatusCodeEnum.BATCH_JOB_RUNNING.getCode());
        jobService.updateBatchStatus(batchControl);
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        BatchControl batchControl = midBatchContext.getBatchControl();
        log.info("afterJob : jobExecutionId:{}, batchControlId:{}", jobExecution.getJobId(), batchControl.getBatchControlId());
        this.resolveBatchControlStatus(batchControl);
        if (StringUtils.isNotBlank(batchControl.getStatusCode())) {
            jobService.updateBatchStatus(batchControl);
        } else if (ExitStatus.COMPLETED.equals(jobExecution.getExitStatus())) {
            // 預設成功，若有失敗筆數時,當成功筆數>0時部分成功 ，不然為執行失敗
            batchControl.setStatusCode(BatchStatusCodeEnum.SUCCESS.getCode());
            if (StringUtils.isBlank(batchControl.getStatusMessage())) {
                Optional<Counter> counter = this.getJobCounter(jobExecution, batchControl);
                counter.ifPresentOrElse(c -> {
                    if (c.getFailCount() > 0) {
                        if (c.getSuccessCount() > 0) {
                            batchControl.setStatusCode(BatchStatusCodeEnum.PARTIAL_SUCCESS.getCode());
                        } else {
                            batchControl.setStatusCode(BatchStatusCodeEnum.BATCH_JOB_FAILED.getCode());
                        }
                    }
                    if (c.getTotalCount() > 0) {
                        batchControl.setStatusMessage(MessageFormat.format(BATCH_RESULT_PATTERN,
                                c.getTotalCount(),
                                c.getSuccessCount(),
                                c.getFailCount(),
                                c.getFilterCount()));
                    }
                }, () -> batchControl.setStatusMessage(BatchStatusCodeEnum.SUCCESS.formatDesc()));
            }
            jobService.updateBatchStatus(batchControl);
            log.info("batchControl : {}", batchControl);
            log.info("Job End  : {}", midJobParameter.getJobCode());
        } else {
            Throwable e = jobExecution.getAllFailureExceptions().stream()
                    .findFirst()
                    .orElse(null);
            if (e != null) {
                log.error(String.format("批次處理失敗 : %s, %s", midJobParameter.getJobCode(), e.getMessage()), e);
                TxnException txnException = ExceptionUtils.findRootTxnException(e);
                if (txnException != null) {
                    batchControl.setStatusCode(txnException.getCodeEnum().getCode());
                    batchControl.setStatusMessage(ExceptionUtils.getStackTrace(txnException));
                    jobService.updateBatchStatus(batchControl);
                } else {
                    batchControl.setStatusCode(BatchStatusCodeEnum.BATCH_JOB_FAILED.getCode());
                    batchControl.setStatusMessage(ExceptionUtils.getRootStackTrace(e));
                    jobService.updateBatchStatus(batchControl);
                }
            } else {
                batchControl.setStatusCode(BatchStatusCodeEnum.BATCH_JOB_FAILED.getCode());
                batchControl.setStatusMessage(jobExecution.getExitStatus().toString());
                jobService.updateBatchStatus(batchControl);
            }
        }
    }

    private void resolveBatchControlStatus(BatchControl batchControl) {
        if (BatchStatusCodeEnum.BATCH_JOB_RUNNING.getCode().equals(batchControl.getStatusCode())) {
            batchControl.setStatusCode(null);
        }
        if (midBatchContext.getStatusEnum() != null) {
            batchControl.setStatusCode(midBatchContext.getStatusEnum().getCode());
            batchControl.setStatusMessage(midBatchContext.getStatusEnum().getFormatedDesc());
        }
        if (StringUtils.isNotBlank(midBatchContext.getStatusCode())) {
            batchControl.setStatusCode(midBatchContext.getStatusCode());
        }
        if (StringUtils.isNotBlank(midBatchContext.getStatusMessage())) {
            batchControl.setStatusMessage(midBatchContext.getStatusMessage());
            batchControl.setStatusCode(midBatchContext.getStatusCode());
        }
    }

    /**
     * 計算資料處理筆數
     * @param jobExecution Batch domain object representing the execution of a job
     * @param batchControl Batch control object representing the execution of a job
     */
    private Optional<Counter> getJobCounter(JobExecution jobExecution, BatchControl batchControl) {
        return jobExecution.getStepExecutions()
                .stream()
                .map(Counter::new)
                .reduce((v1, v2) -> {
                    return (v1.getTotalCount() >= v2.getTotalCount()) ? v1 : v2;
                });
    }

    @Data
    private class Counter {
        private int successCount;
        private int failCount;
        private int filterCount;
        private int totalCount;

        private Counter(StepExecution stepExecution) {
            successCount = stepExecution.getWriteCount();
            failCount = stepExecution.getReadSkipCount() + stepExecution.getProcessSkipCount() + stepExecution.getWriteSkipCount();
            filterCount = stepExecution.getFilterCount();
            totalCount = successCount + failCount + filterCount;
        }
    }
}
