package com.scsb.ncbs.batch.exp.job;

import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;

import com.scsb.ncbs.batch.exp.job.annotation.EnableExpJob;
import com.scsb.ncbs.core.annotation.MidConfiguration;

@MidConfiguration
@ConditionalOnBean(annotation = EnableExpJob.class)
public class MidExpBatchAutoConfiguration {

}
