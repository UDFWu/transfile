package com.scsb.ncbs.batch.core;

import java.util.function.Function;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.job.builder.FlowBuilder;
import org.springframework.batch.core.job.builder.JobFlowBuilder;
import org.springframework.batch.core.job.flow.Flow;
import org.springframework.batch.core.job.flow.FlowExecutionStatus;
import org.springframework.batch.core.job.flow.support.SimpleFlow;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.step.builder.SimpleStepBuilder;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.core.step.builder.TaskletStepBuilder;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.vavr.collection.Stream;

@Component
public class MidJobBuilderFactory {
    @Autowired
    private JobBuilderFactory jobBuilderFactory;
    @Autowired
    private StepBuilderFactory stepBuilderFactory;
    @Autowired
    private MidBatchJobListener midBatchJobListener;
    @Autowired
    MidJobExecutionDecider midJobExecutionDecider;

    public Job buildJob(String jobName, Step... steps) {
        return this.buildJob(jobName, builder -> {
            Stream.of(steps).forEach(builder::next);
            return builder.end().build();
        });
    }

    public Job buildJob(String jobName, Function<JobFlowBuilder, Job> builderFunction) {
        JobFlowBuilder builder = jobFlowBuilder(jobName);
        return builderFunction.apply(builder);
    }

    public JobFlowBuilder jobFlowBuilder(String jobName) {
        return jobBuilderFactory.get(jobName)
                .incrementer(new RunIdIncrementer())
                .listener(midBatchJobListener)
                .start(this.buildMidJobExecutionDeciderFow());
    }

    private Flow buildMidJobExecutionDeciderFow() {
        return new FlowBuilder<SimpleFlow>(MidJobExecutionDecider.class.getSimpleName())
                .start(midJobExecutionDecider).on(FlowExecutionStatus.COMPLETED.getName()).end()
                .from(midJobExecutionDecider).on(FlowExecutionStatus.STOPPED.getName()).stop()
                .build();
    }

    public StepBuilder stepBuilder(String stepName) {
        return this.stepBuilderFactory.get(stepName);
    }

    public Step buildStep(String stepName, Function<StepBuilder, Step> builderFunction) {
        StepBuilder stepBuilder = this.stepBuilderFactory.get(stepName);
        return builderFunction.apply(stepBuilder);
    }

    public <I, O> SimpleStepBuilder<I, O> buildReadAllWriterStep(String stepName, ItemReader<I> reader, Function<I, O> processor, ItemWriter<O> writer) {
        return this.stepBuilderFactory.get(stepName)
                .<I, O> chunk(Integer.MAX_VALUE)
                .reader(reader)
                .processor(processor)
                .writer(writer);
    }

    public <I, O> SimpleStepBuilder<I, O> buildReadAllWriterStep(String stepName, ItemReader<I> reader, ItemWriter<O> writer) {
        return this.stepBuilderFactory.get(stepName)
                .<I, O> chunk(Integer.MAX_VALUE)
                .reader(reader)
                .writer(writer);
    }

    public <I, O> SimpleStepBuilder<I, O> buildReadSingleWriterStep(String stepName, ItemReader<I> reader, Function<I, O> processor, ItemWriter<O> writer) {
        return this.stepBuilderFactory.get(stepName)
                .<I, O> chunk(1)
                .reader(reader)
                .processor(processor)
                .writer(writer);
    }

    public <I, O> SimpleStepBuilder<I, O> buildReadSingleWriterStep(String stepName, ItemReader<I> reader, ItemWriter<O> writer) {
        return this.stepBuilderFactory.get(stepName)
                .<I, O> chunk(1)
                .reader(reader)
                .writer(writer);
    }

    public <I, O> SimpleStepBuilder<I, O> buildReadWriterStep(String stepName, int chunkSize, ItemReader<I> reader, Function<I, O> processor, ItemWriter<O> writer) {
        return this.stepBuilderFactory.get(stepName)
                .<I, O> chunk(chunkSize)
                .reader(reader)
                .processor(processor)
                .writer(writer);
    }

    public <I, O> SimpleStepBuilder<I, O> buildReadWriterStep(String stepName, int chunkSize, ItemReader<I> reader, ItemWriter<O> writer) {
        return this.stepBuilderFactory.get(stepName)
                .<I, O> chunk(chunkSize)
                .reader(reader)
                .writer(writer);
    }

    public TaskletStepBuilder taskletStepBuilder(String stepName, Tasklet tasklet) {
        return this.stepBuilderFactory.get(stepName)
                .tasklet(tasklet);
    }

    public Step buildTaskletStep(String stepName, Tasklet tasklet) {
        return this.buildStep(stepName, builder -> {
            return builder.tasklet(tasklet).build();
        });
    }
}
