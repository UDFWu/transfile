package com.scsb.ncbs.batch.core;

import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;

import com.scsb.ncbs.batch.core.annotation.EnableMidBatch;
import com.scsb.ncbs.core.annotation.MidConfiguration;
import com.scsb.ncbs.core.api.client.EnableMidApiClients;

@MidConfiguration
@ConditionalOnBean(annotation = EnableMidBatch.class)
@EnableMidApiClients(basePackages = "com.scsb.ncbs.batch.api.client")
public class MidBatchAutoConfiguration {

}
