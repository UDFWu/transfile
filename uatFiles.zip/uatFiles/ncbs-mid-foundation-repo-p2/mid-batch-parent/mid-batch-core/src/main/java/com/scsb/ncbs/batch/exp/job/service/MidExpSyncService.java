package com.scsb.ncbs.batch.exp.job.service;

import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.JdbcUtils;
import org.springframework.jdbc.support.MetaDataAccessException;
import org.springframework.transaction.annotation.Propagation;

import com.scsb.ncbs.batch.core.enums.BatchStatusCodeEnum;
import com.scsb.ncbs.batch.core.persistence.entity.MidExpSyncStatusEntity;
import com.scsb.ncbs.batch.core.persistence.repository.MidExpSyncStatusRepository;
import com.scsb.ncbs.batch.exp.job.MidExpSyncProperties.MidExpSyncJobProperties;
import com.scsb.ncbs.batch.exp.job.persistence.entity.MidExpTableControlEntity;
import com.scsb.ncbs.batch.exp.job.persistence.repository.MidExpTableControlRepository;
import com.scsb.ncbs.core.data.jpa.ExpDatabase;
import com.scsb.ncbs.core.data.jpa.ExpTransactional;
import com.scsb.ncbs.core.data.jpa.MidDatabase;
import com.scsb.ncbs.core.data.jpa.MidTransactional;
import com.scsb.ncbs.core.utils.MidMessageUtils;

/**
 * MIDEXP資料庫同步服務
 */
public class MidExpSyncService {
    @Autowired
    @MidDatabase
    private DataSource midDataSource;
    @Autowired
    @ExpDatabase
    private DataSource expDataSource;
    @Autowired
    @ExpDatabase
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private MidExpSyncStatusRepository expSyncStatusRepository;
    @Autowired
    private MidExpTableControlRepository expTableControlRepository;

    /**
     * 取得同步狀態Entity物件
     */
    public MidExpSyncStatusEntity getExpSyncStatusEntity(String jobCode) {
        return expSyncStatusRepository
                .findByJobCode(jobCode)
                .orElseThrow(MidMessageUtils.raiseTxErrorSupp(BatchStatusCodeEnum.EXP_SYNC_STATUS_NOT_FOUND));
    }

    /**
     * 取得資料欄位清單及資料類型
     */
    public Map<String, Integer> getExpTableColumnDataTypeMap(String tableName) {
        try {
            return JdbcUtils.extractDatabaseMetaData(expDataSource, databaseMetaData -> {
                Map<String, Integer> columns = new LinkedHashMap<>();
                ResultSet rs = databaseMetaData.getColumns(null, null, tableName, null);
                while (rs.next()) {
                    String columnName = rs.getString("COLUMN_NAME");
                    int dataType = rs.getInt("DATA_TYPE");
                    columns.put(columnName, dataType);
                }
                return columns;
            });
        } catch (MetaDataAccessException e) {
            throw new IllegalStateException(e);
        }
    }

    /**
     * 刪除EXP資料表資料
     */
    @ExpTransactional(propagation = Propagation.REQUIRES_NEW)
    public void truncateExpTable(String table) {
        String truncateSQL = "TRUNCATE TABLE " + table;
        jdbcTemplate.execute(truncateSQL);
    }

    @ExpTransactional(propagation = Propagation.REQUIRES_NEW)
    public void deleteExpTable(String table) {
        String sql = "DELETE FROM " + table;
        jdbcTemplate.execute(sql);
    }

    /**
     * 更新同步狀態
     */
    @MidTransactional(propagation = Propagation.REQUIRES_NEW)
    public void updateSyncStatus(MidExpSyncJobProperties properties) {
        MidExpSyncStatusEntity entity = this.getExpSyncStatusEntity(properties.getJobCode());
        entity.setSyncDate(properties.getSyncDate());
        expSyncStatusRepository.save(entity);
    }

    @ExpTransactional
    public void updateExpTableControl(MidExpSyncJobProperties properties) {
        MidExpTableControlEntity entity = expTableControlRepository
                .findByTableName(properties.getDstTable())
                .orElseGet(() -> {
                    MidExpTableControlEntity newEntity = new MidExpTableControlEntity();
                    newEntity.setTableName(properties.getDstTable());
                    return newEntity;
                });
        entity.setWriteTimestamp(LocalDateTime.now());
        expTableControlRepository.saveAndFlush(entity);
    }
}
