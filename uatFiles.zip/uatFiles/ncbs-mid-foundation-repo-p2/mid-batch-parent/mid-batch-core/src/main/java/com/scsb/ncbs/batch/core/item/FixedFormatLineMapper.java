package com.scsb.ncbs.batch.core.item;

import java.nio.charset.Charset;

import org.springframework.batch.item.file.LineMapper;

import com.ibm.cbmp.fabric.foundation.fixedformat.FixedFormatMapper;
import com.ibm.cbmp.fabric.foundation.fixedformat.impl.FixedFormatMapperImpl;

import lombok.Builder;
import lombok.Setter;

public class FixedFormatLineMapper<T> implements LineMapper<T> {
    @Setter
    private FixedFormatMapper fixedFormatMapper = FixedFormatMapper.instance();

    @Setter
    private Class<T> targetType;

    @Override
    public T mapLine(String line, int lineNumber) throws Exception {
        return fixedFormatMapper.load(targetType, line);
    }

    @Builder
    static <T> FixedFormatLineMapper<T> mapperBuilder(Class<T> type, Charset charset) {
        FixedFormatLineMapper<T> mapper = new FixedFormatLineMapper<>();
        mapper.setTargetType(type);
        mapper.setFixedFormatMapper(new FixedFormatMapperImpl(charset));
        return mapper;
    }

}
