package com.scsb.ncbs.batch.core.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;

import com.scsb.ncbs.batch.core.MidJobParameter;
import com.scsb.ncbs.batch.core.MidJobService;
import com.scsb.ncbs.batch.core.service.bean.BatchControl;
import com.scsb.ncbs.batch.core.service.bean.BatchDefine;

public class BatchMockService {
    private List<BatchDefine> batchDefineList = new ArrayList<>();
    private List<BatchControl> batchControlList = new ArrayList<>();

    @Autowired
    @Lazy
    private MidJobService midJobService;

    public void addBatchDefine(BatchDefine batchDefine) {
        if (batchDefine != null) {
            batchDefine.setBatchDefineId(System.currentTimeMillis());
            batchDefineList.add(batchDefine);
        }
    }

    public void runJob(MidJobParameter parameter) throws JobExecutionException {
        if (this.findBatchDefine(parameter.getJobCode()).isEmpty()) {
            BatchDefine batchDefine = new BatchDefine();
            batchDefine.setBatchDefineId(System.currentTimeMillis());
            batchDefine.setJobCode(parameter.getJobCode());
            batchDefine.setJobName(StringUtils.defaultIfBlank(parameter.getJobName(), parameter.getJobCode()));
            batchDefineList.add(batchDefine);
        }
        midJobService.runJob(parameter);
    }

    Optional<BatchDefine> findBatchDefine(String jobCode) {
        return this.batchDefineList.stream().filter(item -> {
            return StringUtils.equals(item.getJobCode(), jobCode);
        }).findAny();
    }

    void addBatchControl(BatchControl batchControl) {
        batchControl.setBatchControlId(System.currentTimeMillis());
        this.batchControlList.add(batchControl);
    }

    Optional<BatchControl> findBatchControl(Long batchControlId) {
        return batchControlList.stream()
                .filter(item -> {
                    return item.getBatchControlId().equals(batchControlId);
                }).findAny();
    }

    Optional<BatchDefine> findBatchDefine(Long batchDefineId) {
        return batchDefineList.stream()
                .filter(item -> {
                    return item.getBatchDefineId().equals(batchDefineId);
                }).findAny();
    }

}
