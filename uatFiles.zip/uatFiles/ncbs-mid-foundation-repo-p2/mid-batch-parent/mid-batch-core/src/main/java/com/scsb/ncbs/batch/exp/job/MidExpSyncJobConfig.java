package com.scsb.ncbs.batch.exp.job;

import java.time.LocalDate;
import java.util.Map;
import java.util.Optional;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemStreamReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.context.properties.PropertyMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.ColumnMapRowMapper;
import org.springframework.jdbc.core.SqlTypeValue;
import org.springframework.jdbc.core.StatementCreatorUtils;
import org.springframework.transaction.PlatformTransactionManager;

import com.scsb.ncbs.batch.core.BaseJobConfig;
import com.scsb.ncbs.batch.core.MidJobParameter;
import com.scsb.ncbs.batch.core.persistence.entity.MidExpSyncStatusEntity;
import com.scsb.ncbs.batch.exp.job.MidExpSyncProperties.MidExpSyncJobProperties;
import com.scsb.ncbs.batch.exp.job.annotation.EnableExpJob;
import com.scsb.ncbs.batch.exp.job.service.MidExpSyncService;
import com.scsb.ncbs.core.data.jpa.ExpDatabase;
import com.scsb.ncbs.core.data.jpa.MidDatabase;

/**
 * MIDEXP資料庫同步批次設定
 */
@Configuration
@ConditionalOnBean(annotation = EnableExpJob.class)
@EnableConfigurationProperties(MidExpSyncProperties.class)
public class MidExpSyncJobConfig extends BaseJobConfig {
    public static final String JOB_NAME = "MIDEXP_SYNC_JOB";
    public static final String SYNC_PROPERTIES = JOB_NAME + "_PROPERTIES";
    public static final String TRUNCATE_STEP = JOB_NAME + "_TRUNCATE";
    public static final String SYNC_STEP = JOB_NAME + "_SYNC";
    public static final String SYNC_READER = SYNC_STEP + "_READER";
    public static final String SYNC_WRITER = SYNC_STEP + "_WRITER";
    public static final String SYNC_PROCESSOR = SYNC_STEP + "_PROCESSOR";
    public static final String UPDATE_STATUS_STEP = JOB_NAME + "_STATUS";

    @Autowired
    @MidDatabase
    private DataSource midDataSource;
    @Autowired
    @ExpDatabase
    private DataSource expDataSource;
    @Autowired
    @MidDatabase
    private PlatformTransactionManager midTransactionManager;
    @Autowired
    @ExpDatabase
    private PlatformTransactionManager expTransactionManager;
    @Autowired
    private MidJobParameter jobParameter;
    @Autowired
    private MidExpSyncProperties jobProperties;

    @Bean
    MidExpSyncService midExpSyncService() {
        return new MidExpSyncService();
    }

    @Bean
    @JobScope
    MidExpSyncJob midExpSyncJob() {
        return new MidExpSyncJob();
    }

    @Bean
    @JobScope
    MidExpSyncJobProperties midExpSyncJobProperties(MidExpSyncService service) {
        MidExpSyncStatusEntity entity = service.getExpSyncStatusEntity(jobParameter.getJobCode());
        MidExpSyncJobProperties properties = jobProperties.getConfigMap().computeIfAbsent(entity.getJobCode(), key -> new MidExpSyncJobProperties());
        PropertyMapper mapper = PropertyMapper.get().alwaysApplyingWhenNonNull();
        mapper.from(jobParameter::getJobCode).to(properties::setJobCode);
        mapper.from(entity::getSrcTable).to(properties::setSrcTable);
        mapper.from(entity::getDstTable).to(properties::setDstTable);
        mapper.from(Optional.ofNullable(entity.getSyncDate()).orElse(LocalDate.EPOCH)).to(properties::setLastSyncDate);
        mapper.from(jobParameter::getRunDate).to(properties::setSyncDate);
        mapper.from(entity::getSyncTime).to(properties::setSyncTime);
        mapper.from(entity::getSelectSql).to(properties::setSelectSql);
        mapper.from(entity::getTruncateTable).to(properties::setTruncateTable);
        mapper.from(entity::getChunkSize).to(properties::setChunkSize);
        mapper.from(entity::getEnableSqlSyncDate).to(properties::setEnableWhereSyncDate);
        return properties;
    }

    @Bean(JOB_NAME)
    Job job(@Qualifier(TRUNCATE_STEP) Step truncateStep,
            @Qualifier(SYNC_STEP) Step syncStep,
            @Qualifier(UPDATE_STATUS_STEP) Step updateStatusStep) {
        return midJobBuilderFactory.buildJob(JOB_NAME, truncateStep, syncStep, updateStatusStep);
    }

    /**
     * Truncate Step
     */
    @Bean(TRUNCATE_STEP)
    Step truncateExpStep(MidExpSyncJob expSyncJob) {
        return midJobBuilderFactory
                .taskletStepBuilder(TRUNCATE_STEP, expSyncJob::truncateExpTable)
                .transactionManager(expTransactionManager)
                .build();
    }

    /**
     * 同步Step
     */
    @Bean(SYNC_STEP)
    @JobScope
    Step syncStep(
            @Qualifier(SYNC_READER) ItemReader<Map<String, Object>> reader,
            @Qualifier(SYNC_WRITER) ItemWriter<Map<String, Object>> writer,
            @Qualifier(SYNC_PROCESSOR) ItemProcessor<Map<String, Object>, Map<String, Object>> processor,
            MidExpSyncJobProperties midExpSyncProperties) {
        return midJobBuilderFactory
                .buildReadWriterStep(SYNC_STEP, midExpSyncProperties.getChunkSize(), reader, writer)
                .processor(processor)
                .transactionManager(expTransactionManager)
                .build();
    }

    /**
     * 來源資料庫Reader
     */
    @StepScope
    @Bean(SYNC_READER)
    ItemStreamReader<Map<String, Object>> syncReader(MidExpSyncJob job) {
        ItemStreamReader<Map<String, Object>> itemReader = new JdbcCursorItemReaderBuilder<Map<String, Object>>()
                .dataSource(midDataSource)
                .sql(job.buildMidReaderSQL())
                .rowMapper(new ColumnMapRowMapper())
                .saveState(false)
                .preparedStatementSetter(ps -> {
                    Object[] params = job.buildMidReaderArguments();
                    int paramCount = ps.getParameterMetaData().getParameterCount();
                    for (int paramIndex = 0; paramIndex < paramCount; paramIndex++) {
                        Object param = params[paramIndex % params.length];
                        StatementCreatorUtils.setParameterValue(ps, paramIndex + 1, SqlTypeValue.TYPE_UNKNOWN, param);
                    }
                })
                .build();
        return itemReader;
    }

    /**
     * 目的資料庫Writer
     */
    @Bean(SYNC_WRITER)
    @StepScope
    ItemWriter<Map<String, Object>> syncWriter(MidExpSyncJob job) {
        return new JdbcBatchItemWriterBuilder<Map<String, Object>>()
                .dataSource(expDataSource)
                .sql(job.buildExpWriterSQL())
                .itemSqlParameterSourceProvider(job::createExpWriterParameterSource)
                .build();
    }

    /**
     * 來源資料庫/目的資料庫格式轉換
     */
    @Bean(SYNC_PROCESSOR)
    @StepScope
    ItemProcessor<Map<String, Object>, Map<String, Object>> syncProcessor(MidExpSyncJob job) {
        return job::processItem;
    }

    /**
     * 同步狀態更新Step
     */
    @Bean(UPDATE_STATUS_STEP)
    Step updateStatusStep(MidExpSyncJob job) {
        return midJobBuilderFactory
                .taskletStepBuilder(UPDATE_STATUS_STEP, job::updateSyncStatus)
                .transactionManager(midTransactionManager)
                .build();
    }
}
