package com.scsb.ncbs.batch.exp.job.persistence.repository;

import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.scsb.ncbs.batch.exp.job.persistence.entity.MidExpTableControlEntity;
import com.scsb.ncbs.core.repository.MidJpaRepository;

/**
 * EXP資料表匯出控制檔 Repository
 */
@Repository
public interface MidExpTableControlRepository extends MidJpaRepository<MidExpTableControlEntity, Long> {
    Optional<MidExpTableControlEntity> findByTableName(String tableName);
}