package com.scsb.ncbs.batch.core;

import javax.sql.DataSource;

import org.springframework.batch.core.configuration.JobRegistry;

/**
 * @author Spencer
 * @createDate 2020年4月14日
 */

import org.springframework.batch.core.configuration.annotation.BatchConfigurer;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.support.JobRegistryBeanPostProcessor;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.explore.support.JobExplorerFactoryBean;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.JobRepositoryFactoryBean;
import org.springframework.batch.support.DatabaseType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

import com.scsb.ncbs.batch.core.annotation.JobTaskExecutor;
import com.scsb.ncbs.batch.core.annotation.MidBatch;
import com.scsb.ncbs.batch.core.annotation.StepTaskExecutor;
import com.scsb.ncbs.batch.core.service.BatchDataService;
import com.scsb.ncbs.core.data.jpa.MidDatabase;
import com.scsb.ncbs.core.utils.MidJsonUtils;

/**
 * 中台批次設定
 */
@Configuration(proxyBeanMethods = false)
@EnableBatchProcessing
public class MidBatchConfiguration {
    private static final String DEFAULT_ISOLATION_LEVEL = "ISOLATION_READ_COMMITTED";
    @Autowired
    @MidDatabase
    private DataSource dataSource;
    @Autowired
    @MidDatabase
    private PlatformTransactionManager transactionManager;

    @MidBatch
    @Bean
    JobRepositoryFactoryBean midJobRepositoryFactoryBean() {
        JobRepositoryFactoryBean factory = new JobRepositoryFactoryBean();
        factory.setDataSource(dataSource);
        factory.setTransactionManager(transactionManager);
        factory.setDatabaseType(DatabaseType.ORACLE.getProductName());
        factory.setIsolationLevelForCreate(DEFAULT_ISOLATION_LEVEL);
        return factory;
    }

    @Bean
    @MidBatch
    JobExplorerFactoryBean midJobExplorerFactoryBean() {
        JobExplorerFactoryBean factory = new JobExplorerFactoryBean();
        factory.setDataSource(dataSource);
        return factory;
    }

    @Bean
    public JobRegistryBeanPostProcessor jobRegistryBeanPostProcessor(JobRegistry jobRegistry) {
        JobRegistryBeanPostProcessor postProcessor = new JobRegistryBeanPostProcessor();
        postProcessor.setJobRegistry(jobRegistry);
        return postProcessor;
    }

    @Bean
    @MidBatch
    public JobLauncher asyncJobLauncher(@MidBatch JobRepository jobRepository, @JobTaskExecutor TaskExecutor taskExecutor) {
        SimpleJobLauncher jobLauncher = new SimpleJobLauncher();
        jobLauncher.setJobRepository(jobRepository);
        jobLauncher.setTaskExecutor(taskExecutor);
        return jobLauncher;
    }

    @JobTaskExecutor
    @Bean(MidBatchConstrants.JOB_THREAD_POOL_TASK_EXECUTOR_BEAN)
    @ConfigurationProperties(MidBatchConstrants.JOB_THREAD_POOL_TASK_EXECUTOR_CONFIG)
    public TaskExecutor jobThreadPoolTaskExecutor(MidBatchTaskDecorator taskDecorator) {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setThreadNamePrefix("batch-");
        executor.setCorePoolSize(20);
        executor.setKeepAliveSeconds(10 * 60 * 1000);// 超過20分鐘將自動刪除pool內舊的執行緒
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.setTaskDecorator(taskDecorator);
        return executor;
    }

    @Bean(MidBatchConstrants.STEP_THREAD_POOL_TASK_EXECUTOR_BEAN)
    @ConfigurationProperties(MidBatchConstrants.STEP_THREAD_POOL_TASK_EXECUTOR_CONFIG)
    @StepTaskExecutor
    public TaskExecutor stepThreadPoolProcessesExecutor(MidBatchTaskDecorator taskDecorator) {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setThreadNamePrefix("batch-step-");
        executor.setCorePoolSize(100);
        executor.setKeepAliveSeconds(10 * 60 * 1000);// 超過20分鐘將自動刪除pool內舊的執行緒
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.setTaskDecorator(taskDecorator);
        return executor;
    }

    @Bean
    @JobScope
    public MidJobParameter midJobParameter(MidBatchContext batchContext) {
        if (batchContext.getJobParameter() != null) {
            return batchContext.getJobParameter();
        } else {
            return new MidJobParameter();
        }
    }

    @Bean
    @JobScope
    public MidBatchContext midBatchContext(BatchDataService batchDataService, @Value("#{jobParameters['batchControlId']}") Long batchControlId) {
        MidBatchContext context = new MidBatchContext();
        batchDataService.findBatchControl(batchControlId).ifPresent(
                batchControl -> {
                    context.setBatchControl(batchControl);
                    batchDataService.findBatchDefine(batchControl.getBatchDefineId())
                            .ifPresent(context::setBatchDefine);
                    MidJobParameter jobParameter = MidJsonUtils.toObject(batchControl.getPayload(), MidJobParameter.class);
                    context.setJobParameter(jobParameter);
                });
        return context;
    }

    @Bean
    MidBatchTaskDecorator midBatchTaskDecorator() {
        return new MidBatchTaskDecorator();
    }

    @Bean
    MidBatchConfigurer midBatchConfigurer() {
        return new MidBatchConfigurer();
    }
}

class MidBatchConfigurer implements BatchConfigurer {
    @Autowired
    @MidDatabase
    private PlatformTransactionManager transactionManager;

    @Autowired
    @MidBatch
    private JobRepository jobRepository;

    @Autowired
    @MidBatch
    private JobLauncher jobLauncher;

    @Autowired
    @MidBatch
    private JobExplorer jobExplorer;

    @Override
    public JobRepository getJobRepository() throws Exception {
        return jobRepository;
    }

    @Override
    public PlatformTransactionManager getTransactionManager() throws Exception {
        return transactionManager;
    }

    @Override
    public JobLauncher getJobLauncher() throws Exception {
        return jobLauncher;
    }

    @Override
    public JobExplorer getJobExplorer() throws Exception {
        return jobExplorer;
    }
}
