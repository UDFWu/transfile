package com.scsb.ncbs.batch.core.enums;

import com.ibm.cbmp.fabric.foundation.enums.IReturnCodeDescEnum;
import com.ibm.cbmp.fabric.foundation.enums.api.SeverityEnum;

import lombok.Getter;

/**
 * 狀態代碼列舉
 */
@Getter
public enum BatchStatusCodeEnum implements IReturnCodeDescEnum {
    SUCCESS("000000", SeverityEnum.INFO, "成功"),
    PARTIAL_SUCCESS("000001", SeverityEnum.WARN, "部分成功"),
    BATCH_DEFINE_NOT_FOUND("BAT00001", SeverityEnum.ERROR, "查無批次定義檔(%s)"),
    BATCH_JOB_NOT_FOUND("BAT00002", SeverityEnum.ERROR, "查無批次設定(%s)"),
    BATCH_JOB_CREATED("BAT00003", SeverityEnum.INFO, "批次JOB已建立"),
    BATCH_JOB_RUNNING("BAT00004", SeverityEnum.INFO, "批次JOB執行中"),
    BATCH_JOB_FAILED("BAT00005", SeverityEnum.INFO, "批次JOB執行失敗"),
    BATCH_CONTROL_NOT_FOUND("BAT00006", SeverityEnum.ERROR, "查無批次執行紀錄"),
    INVALID_BUSINESS_DAY("BAT00007", SeverityEnum.ERROR, "本日非營業日，批次暫停執行！"),
    BATCH_JOB_SKIPPED("BAT00008", SeverityEnum.ERROR, "本日批次不需執行！"),
    EXP_SYNC_STATUS_NOT_FOUND("BAT01001", SeverityEnum.ERROR, "查無EXP資料庫同步設定"),
    /**
     * 本次同步日期須晚於上次同步日期
     */
    EXP_SYNC_INVALID_SYNC_DATE("BAT01002", SeverityEnum.ERROR, "本次同步日期須晚於上次同步日期"),
    ;

    private String code;
    private SeverityEnum severity;
    private String desc;

    private BatchStatusCodeEnum(String code, SeverityEnum severity, String desc) {
        this.code = code;
        this.severity = severity;
        this.desc = desc;
    }

    @Override
    public SeverityEnum getSeverity() {
        return this.severity;
    }

    @Override
    public String getDesc() {
        return this.desc;
    }
}
