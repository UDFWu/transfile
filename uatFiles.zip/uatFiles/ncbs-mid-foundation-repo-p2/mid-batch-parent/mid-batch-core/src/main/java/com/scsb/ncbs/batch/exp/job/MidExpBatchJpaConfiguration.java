package com.scsb.ncbs.batch.exp.job;

import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.context.annotation.Configuration;

import com.ibm.cbmp.fabric.foundation.data.jpa.FabricJpaConfigurator;
import com.scsb.ncbs.batch.exp.job.annotation.EnableExpJob;
import com.scsb.ncbs.core.data.jpa.EnableExpEntities;
import com.scsb.ncbs.core.data.jpa.EnableExpJpa;
import com.scsb.ncbs.core.data.jpa.EnableExpRepositories;

@Configuration
@EnableExpJpa
@EnableExpEntities("com.scsb.ncbs.batch.exp.job.persistence.entity")
@EnableExpRepositories("com.scsb.ncbs.batch.exp.job.persistence.repository")
@ConditionalOnBean(annotation = EnableExpJob.class)
public class MidExpBatchJpaConfiguration implements FabricJpaConfigurator {

}
