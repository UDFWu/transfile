package com.scsb.ncbs.batch.exp.job;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import com.scsb.ncbs.batch.core.enums.BatchStatusCodeEnum;
import com.scsb.ncbs.batch.exp.job.MidExpSyncProperties.MidExpSyncJobProperties;
import com.scsb.ncbs.batch.exp.job.service.MidExpSyncService;
import com.scsb.ncbs.core.utils.MidMessageUtils;

/**
 * MIDEXP資料庫同步批次
 */
public class MidExpSyncJob implements InitializingBean {
    @Autowired
    private MidExpSyncJobProperties jobProperties;
    @Autowired
    private MidExpSyncService service;
    @Autowired
    private ApplicationContext applicationContext;

    private Map<String, Integer> expTableColumns;

    /**
     * 刪除EXP資料表資料
     */
    public RepeatStatus truncateExpTable(StepContribution stepContribution, ChunkContext chunkcontext) {
        if (jobProperties.isTruncateTable()) {
            service.truncateExpTable(jobProperties.getDstTable());
        } else if (jobProperties.isDeleteTable()) {
            service.deleteExpTable(jobProperties.getDstTable());
        }
        return RepeatStatus.FINISHED;
    }

    /**
     * 更新同步狀態
     */
    public RepeatStatus updateSyncStatus(StepContribution stepContribution, ChunkContext chunkcontext) {
        service.updateExpTableControl(jobProperties);
        service.updateSyncStatus(jobProperties);
        return RepeatStatus.FINISHED;
    }

    /**
     * 來源資料庫/目的資料庫格式轉換
     */
    public Map<String, Object> processItem(Map<String, Object> item) {
        return item;
    }

    /**
     * MID TABLE 查詢SQL
     */
    public String buildMidReaderSQL() {
        if (jobProperties.getCallback() != null) {
            MidExpSyncCallback callback = applicationContext.getBean(jobProperties.getCallback());
            String sql = callback.buildSelectSql(jobProperties);
            if (sql != null) {
                return sql;
            }
        }

        if (StringUtils.isNotBlank(jobProperties.getSelectSql())) {
            return jobProperties.getSelectSql();
        } else if (jobProperties.isEnableWhereSyncDate()) {
            return String.format("SELECT * FROM %s  WHERE UPDATED_TIMESTAMP > ? and UPDATED_TIMESTAMP <= ?", jobProperties.getSrcTable());
        } else {
            return String.format("SELECT * FROM %s", jobProperties.getSrcTable());
        }
    }

    /**
     * MID TABLE 查詢參數
     */
    public Object[] buildMidReaderArguments() {
        if (jobProperties.getCallback() != null) {
            MidExpSyncCallback callback = applicationContext.getBean(jobProperties.getCallback());
            Object[] args = callback.buildSelectParams(jobProperties);
            if (args != null) {
                return args;
            }
        }
        if (jobProperties.isEnableWhereSyncDate()) {
            LocalDateTime startTime = LocalDateTime.of(jobProperties.getLastSyncDate(), jobProperties.getSyncTime());
            LocalDateTime endTime = LocalDateTime.of(jobProperties.getSyncDate(), jobProperties.getSyncTime());
            return new Object[] {startTime, endTime };
        }
        return ArrayUtils.EMPTY_OBJECT_ARRAY;
    }

    /**
     * EXP TABLE 寫入SQL
     */
    public String buildExpWriterSQL() {
        String tableName = jobProperties.getDstTable();
        return new StringBuilder()
                .append(String.format("MERGE INTO %s DST", tableName))
                .append(" USING (SELECT ")
                .append(expTableColumns.keySet().stream()
                        .map(name -> ":" + name + " " + name)
                        .collect(Collectors.joining(",")))
                .append(" FROM DUAL) SRC")
                .append(" ON (DST.LIST_ID=SRC.LIST_ID)")
                .append(" WHEN MATCHED THEN UPDATE SET ")
                .append(expTableColumns.keySet().stream()
                        .filter(v -> !v.equals("LIST_ID"))
                        .map(name -> String.format("DST.%1$s=SRC.%1$s", name))
                        .collect(Collectors.joining(",")))
                .append(" WHEN NOT MATCHED THEN INSERT (")
                .append(StringUtils.join(expTableColumns.keySet(), ",")).append(")")
                .append(" VALUES (")
                .append(expTableColumns.keySet().stream()
                        .map(name -> "SRC." + name)
                        .collect(Collectors.joining(",")))
                .append(")")
                .toString();
    }

    /**
     * EXP TABLE 寫入SQL參數處理
     */
    public SqlParameterSource createExpWriterParameterSource(Map<String, Object> params) {
        MapSqlParameterSource paramSource = new MapSqlParameterSource();
        expTableColumns.forEach((name, type) -> paramSource.addValue(name, params.get(name), type));
        return paramSource;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        if (!jobProperties.getSyncDate().isAfter(jobProperties.getLastSyncDate())) {
            MidMessageUtils.raiseTxError(BatchStatusCodeEnum.EXP_SYNC_INVALID_SYNC_DATE);
        }
        this.expTableColumns = service.getExpTableColumnDataTypeMap(jobProperties.getDstTable());
    }

}
