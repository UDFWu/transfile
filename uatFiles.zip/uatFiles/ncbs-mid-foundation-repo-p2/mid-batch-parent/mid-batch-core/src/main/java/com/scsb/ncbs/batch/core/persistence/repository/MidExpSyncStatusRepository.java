package com.scsb.ncbs.batch.core.persistence.repository;

import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.scsb.ncbs.batch.core.persistence.entity.MidExpSyncStatusEntity;
import com.scsb.ncbs.core.repository.MidJpaRepository;

/**
 * 中台EXPDB同步狀態 Repository
 */
@Repository
public interface MidExpSyncStatusRepository extends MidJpaRepository<MidExpSyncStatusEntity, Long> {
    Optional<MidExpSyncStatusEntity> findByJobCode(String jobCode);
}