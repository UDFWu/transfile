pipeline {
    agent any

    parameters {
        choice(
            name: 'DEPLOY_PROJECT',
            choices: ['cbr', 'cmn', 'dep', 'gla', 'len', 'all projects'],
            description: 'Select the project to deploy.'
        )
        string(name: 'TAG', defaultValue: '1.0.0', description: '部屬的 tag')
        string(name: 'TYPE', defaultValue: 'bat', description: '部屬的環境')
    }

    stages {
        stage('Preparation') {
            steps {
                // determine which project to deploy
                script {
                    if (params.DEPLOY_PROJECT == 'all projects') {
                        deployProjects = ['cbr', 'cmn', 'dep', 'gla', 'len']
                    } else {
                        deployProjects = [params.DEPLOY_PROJECT]
                    }
                    env.DEPLOY_PROJECTS = deployProjects.join(',')
                    echo "DEPLOY_PROJECTS: ${env.DEPLOY_PROJECTS}"
                    echo "TAG: ${env.TAG}"
                    echo "TYPE: ${env.TYPE}"
                    // 定義要傳送的參數
                    def parameters = [
                        string(name: 'DEPLOY_PROJECTS', value: env.DEPLOY_PROJECTS),
                        string(name: 'TAG', value: env.TAG),
                        string(name: 'TYPE', value: env.TYPE)
                    ]

                    // 觸發 ncbs-mid-repo-p2-bat-B pipeline
                    build job: 'ncbs-mid-repo-p2-bat-B', parameters: parameters
                }
            }
        }
    }
}
