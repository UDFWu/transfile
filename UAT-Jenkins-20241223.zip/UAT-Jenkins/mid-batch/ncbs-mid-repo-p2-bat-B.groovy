def deployProjects = []
pipeline {
    agent any
    
    environment {
        REGISTRY_AUTH_FILE = '~/.config/containers/auth.json' // Manage Jenkins > configure system
        GIT_REPO_URL = 'https://sdpsg01.cbsd.scsb.com.tw/mid/ncbs-mid-repo-p2.git'
        GIT_REPO_SSH_URL = 'git@sdpsg01.cbsd.scsb.com.tw:mid/ncbs-mid-repo-p2.git'
        NEXUS_URL = 'https://sdpsn01.cbsd.scsb.com.tw'
        CONTAINER_PROJECT = 'mid'
        CONTAINER_REGISTRY = 'socph01.cbsd.scsb.com.tw'
        // 依據實際情況調整
        DEPLOY_MACHINE_IP = '10.21.109.200'
    }

    stages {
        stage('Get Selection') {
            steps {
                script {
                    if (!params.DEPLOY_PROJECTS ||params.DEPLOY_PROJECTS.trim().isEmpty()) {
                        error "請至少選擇一個專案部屬"
                    }

                    // 將收到的參數設置爲環境變數
                    deployProjects = params.DEPLOY_PROJECTS.split(',') // 將結果存入全局變數
                    env.TAG = params.TAG
                    env.TYPE = params.TYPE

                    //檢查訊息
                    echo "Deploy Projects: ${deployProjects}"
                    echo "TYPE: ${env.TYPE}"
                    echo "TAG: ${env.TAG}"
                }
            }
        }

        stage('Declarative: Checkout SCM') {
            steps {
                checkout([
                    $class: 'GitSCM', 
                    // 依據實際情況調整
                    branches: [[name: '*/sit']], 
                    browser: [$class: 'GitLab', repoUrl: "${GIT_REPO_URL}"],
                    // 依據實際情況調整
                    userRemoteConfigs: [[credentialsId: '59f75586-1688-4078-9f31-525f6cada5bb', url: "${GIT_REPO_SSH_URL}"]]
                ])
            }
        }

        stage('Build Project Code') {
            steps {
                script {
                    for (project in deployProjects) {
                        echo "#### Building ${project} code"
                        sh """
                            mvn -U clean install \
                                -pl :${project}-${TYPE} \
                                -am -Dmaven.test.skip=true \
                                -Dnexus-url=${NEXUS_URL} \
                                -DreleaseTag=${TAG}:SNAPSHOTS
                        """
                    }
                }
            }
        }

        stage('Compress Batch Script') {
            steps {
                script {
                    for (project in deployProjects) {
                        echo '#### Compressing batch script...'

                        def localScriptPath = "${project}/${project}-${TYPE}/script"
                        // c: create an archive, z: compress using gzip, f: specify filename
                        sh "tar -czf batch-script.tar.gz -C ${localScriptPath} ."
                    }
                }
            }
        }
        
        stage('Upload to Remote Server') {
            steps {
                script {
                    for (project in deployProjects) {
                        def remoteScriptPath = "batch/${project}"
                        sshCommand remote: getSshServer(), command: "mkdir -p ${remoteScriptPath}"
                        sshPut remote: getSshServer(), from: "batch-script.tar.gz", into: "${remoteScriptPath}"
                    }
                }
            }
        }

        stage('Decompress on Remote Server') {
            steps {
                script {
                    for (project in deployProjects) {
                        def remoteScriptPath = "batch/${project}"
                        // x: extract archive, z: decompress using gzip (.tar.gz), C: change directory
                        sshCommand remote: getSshServer(), command: """
                            cd ${remoteScriptPath}
                            tar -xzf batch-script.tar.gz &&
                            rm batch-script.tar.gz
                        """
                    }
                }
            }
        }

        stage('Set Execute Permissions') {
            steps {
                sshCommand remote: getSshServer(), command: "chmod -R 755 batch/*"
            }
        }

        stage('Build Image') {
            steps {
                script {
                    for (project in deployProjects) {
                        echo "#### Building image: ${project}-${TYPE}"

                        dir("${env.WORKSPACE}/${project}/${project}-${TYPE}") {
                            sh """
                                podman images | grep ${project}-${TYPE} | awk '{print \$3}' | xargs podman rmi --force || true
                                podman build --build-arg CONTAINER_REGISTRY=${CONTAINER_REGISTRY} -f ./Dockerfile -t ${project}-${TYPE}:${TAG}-SNAPSHOT .
                            """
                        }
                    }
                }
            }
        }

        stage('Release Image') {
            steps {
                // credentialsID 依據實際情況調整
                withCredentials([usernamePassword(credentialsId: 'harbor-user', passwordVariable: 'HARBOR_PASSWORD', usernameVariable: 'HARBOR_USER')]) {
                    script {
                        // 先登入 Harbor，爲了拉取 base image
                        sh "podman login ${CONTAINER_REGISTRY} -u '${HARBOR_USER}' -p '${HARBOR_PASSWORD}'"

                        for (project in deployProjects) {
                            // tag image
                            sh "podman tag ${project}-${TYPE}:${TAG}-SNAPSHOT ${CONTAINER_REGISTRY}/${CONTAINER_PROJECT}/${project}-${TYPE}:${TAG}-SNAPSHOT"
                            //取得 RepoDigest
                            def repoDigest = sh(returnStdout: true, script: "podman inspect -f '{{index .RepoDigests 0}}' ${CONTAINER_REGISTRY}/${CONTAINER_PROJECT}/${project}-${env.TYPE}:${env.TAG}-SNAPSHOT").trim()
                            // 上傳 repoDigest 到 Harbor
                            sh "podman push ${repoDigest}"
                            // 上傳 image 到 Harbor
                            sh "podman push ${CONTAINER_REGISTRY}/${CONTAINER_PROJECT}/${project}-${TYPE}:${TAG}-SNAPSHOT"
                            // 使用 cosign 簽名
                            withCredentials([file(credentialsId: 'cosign-private-key', variable: 'COSIGN_PRIVATE_KEY'), string(credentialsId: 'cosign-password', variable: 'COSIGN_PASSWORD')]) {
                                println(repoDigest)
                                sh "cosign sign --key '${COSIGN_PRIVATE_KEY}' --tlog-upload=false --allow-insecure-registry=true ${repoDigest}"
                            }
                        }
                    }
                }            
            }
        }

        stage('Deploy') {
            steps {
                script {
                    for (project in deployProjects) {
                        sh """
                            echo "${TAG}-SNAPSHOT ${project}" >> deploy.txt
                        """
                    }
                }
                sshPut remote: getSshServer(), from: 'deploy.txt', into: '.'
                script {
                    for (project in deployProjects) {
                        echo "#### Removing existing image ${project}-${TYPE} on remote server"

                        def sshServer = getSshServer()
                        def containerName = "${project}-${TYPE}"
                        removeImageFromServer(sshServer, containerName)
                    }                
                }
            }
        }

        stage('Run Image') {
             steps {
                 script {
                    for (project in deployProjects) {
                        echo "Running ${project}-${TYPE} image on remote server"

                        def containerName = "${project}-${TYPE}"
                        runImageFromServer(getSshServer(), getProjectPort("${project}"), 8080, containerName)
                    }
                 }
             }
        }

        stage('Save info') {
            steps {
                script {
                    for (project in deployProjects) {
                        env.HASH = sh(returnStdout: true, script: "podman inspect -f '{{.Digest}}' ${CONTAINER_REGISTRY}/${CONTAINER_PROJECT}/${project}-${env.TYPE}:${env.TAG}-SNAPSHOT").trim()
                        url = sh(script: "echo ${GIT_REPO_URL} | sed 's,https://,,'", returnStdout: true).trim()
                        group_id = sh(script: "echo ${url} | grep / | cut -d/ -f2", returnStdout: true).trim()
                        project_id = sh(script: "echo ${url} | grep / | cut -d/ -f3 | sed 's,.git,,'", returnStdout: true).trim()
                        patchOrg = """{
                            "group": "${group_id}",
                            "project": "${project}-${env.TYPE}",
                            "version": "${env.TAG}-SNAPSHOT",
                            "packages": [
                                {
                                    "name": "${project}-${env.TYPE}",
                                    "hash": "${HASH}",
                                    "url": "${CONTAINER_REGISTRY}/${CONTAINER_PROJECT}/${project}-${env.TYPE}:${env.TAG}-SNAPSHOT"
                                }
                            ]
                        }"""
                        echo "${patchOrg}"
                        response = httpRequest acceptType: 'APPLICATION_JSON',
                                   contentType: 'APPLICATION_JSON',
                                   httpMode: 'POST',
                                   requestBody: patchOrg,
                                   url: "${CICDAPISERVICE_URL}/api/v1/packages/project",
                                   validResponseCodes: '200:500'
                        println('Status: ' + response.status)
                        println('Response: ' + response.content)

                        if (response.status != 200) {
                            error(response.content)
                        }
                    }
                }
            }
        }
    }
}

def getSshServer() {
    def remote = [:]
    withCredentials([usernamePassword(credentialsId: 'mid_deploy', passwordVariable: 'SSH_PASSWORD', usernameVariable: 'SSH_USER')]) {
        remote.user = SSH_USER
        remote.password = SSH_PASSWORD
    }
    remote.name = env.DEPLOY_MACHINE_IP
    remote.host = env.DEPLOY_MACHINE_IP
    remote.allowAnyHosts = true
    return remote
}

def removeImageFromServer(sshServer, containerName) {
    sshCommand remote: sshServer, command: """
        pwd
        podman stop ${containerName} || true
        podman rm -f ${containerName} || true
        podman images | grep ${containerName} | awk '{print \$3}' | xargs podman rmi -f || true
        podman rmi ${CONTAINER_REGISTRY}/${CONTAINER_PROJECT}/${containerName}:${TAG}-SNAPSHOT || true
    """
}

def runImageFromServer(sshServer, serverPort, containerPort, containerName) {

    def remotePwd = sshCommand remote: sshServer, command: "pwd"
    remotePwd = remotePwd.trim()
    echo "Remote current working directory: ${remotePwd}"

    def REMOTE_TMPDIR = "${remotePwd}/tmp/podman"
    echo "Using TMPDIR: ${REMOTE_TMPDIR}"

    sshCommand remote: sshServer, command: """
        mkdir -p ${REMOTE_TMPDIR}
        export TMPDIR=${REMOTE_TMPDIR}
        podman run --tmpdir=\$TMPDIR \
            -di --tls-verify=false \
            -e "SPRING_PROFILES_ACTIVE=sit" \
            -e "JWT_ASPECT_ENABLED=false" \
            -v /opt/SIT/logs:/logs \
            -p ${serverPort}:${containerPort} \
            --name ${containerName} ${CONTAINER_REGISTRY}/${CONTAINER_PROJECT}/${containerName}:${TAG}-SNAPSHOT
    """
}

def getProjectPort(project) {
    switch(project) {
        case "len":
            serverPort = 9001
            break
        default: 
            serverPort = 8080
            break
    }
    echo "#### Project ${project} is using server port ${serverPort}"
    return serverPort
}
