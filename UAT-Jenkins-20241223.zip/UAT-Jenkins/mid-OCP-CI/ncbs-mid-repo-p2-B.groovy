def deployProjects = []
def projectVersions = [:] // 在腳本作用域中宣告變數

pipeline {
    agent any
    
    tools {
        oc 'OpenShift CLI'
    }

    environment {
        GIT_REPO_URL = 'https://sdpsg01.cbsd.scsb.com.tw/mid/ncbs-mid-repo-p2.git'
        GIT_REPO_SSH_URL = 'git@sdpsg01.cbsd.scsb.com.tw:mid/ncbs-mid-repo-p2.git'
        CONTAINER_REGISTRY = 'socph01.cbsd.scsb.com.tw'
        // NEXUS_URL 要根據實際情況修改
        NEXUS_URL = 'https://sdpsn01.cbsd.scsb.com.tw'
        CICDAPISERVICE_URL = 'http://sdpsa01.cbss.scsb.com.tw'
        // OPENSHIFT_SERVER 要根據實際情況修改
        OPENSHIFT_SERVER = 'mid'
    }

    stages {
        stage('Get Selection') {
            steps {
                script {
                    if (!params.DEPLOY_PROJECTS ||params.DEPLOY_PROJECTS.trim().isEmpty()) {
                        error "請至少選擇一個專案部屬"
                    }

                    // 將收到的參數設置爲環境變數
                    deployProjects = params.DEPLOY_PROJECTS.split(',') // 將結果存入全局變數
                    env.NAMESPACE = params.NAMESPACE
                    env.TAG = params.TAG
                    env.TYPE = params.TYPE

                    //檢查訊息
                    echo "Deploy Projects: ${deployProjects}"
                    echo "NAMESPACE: ${env.NAMESPACE}"
                    echo "TYPE: ${env.TYPE}"
                    echo "TAG: ${env.TAG}"
                }
            }
        }

        // 處理 app 專案
        // 處理 app 專案
        // 處理 app 專案
        stage('Declarative: Checkout APP SCM') {
            when {
                expression { env.TYPE == 'app' || env.TYPE == 'rpt' }
            }

            steps {
                checkout scmGit(
                    // 這裏的 branch 要根據實際情況修改
                    branches: [[name: '*/sit']], 
                    browser: github("${GIT_REPO_URL}"), 
                    extensions: [], 
                    // 這裏的 credentialsId 要根據實際情況修改
                    userRemoteConfigs: [[credentialsId: '6c14edec-6672-4160-a4c5-c9de7c038284', url: "${GIT_REPO_SSH_URL}"]]
                )
            }
        }

        stage('Delete APP mid-core and fabric dependencies') {
            when {
                expression { env.TYPE == 'app' || env.TYPE == 'rpt' }
            }

            steps {
                script {
                    sh """
                        rm -rf ~/.m2/repository/com/ibm/cbmp/*
                        rm -rf ~/.m2/repository/com/ibm/ncbs/mid-foundation-core/*
                        rm -rf ~/.m2/repository/com/ibm/ncbs/ncbs-mid-foundation/*
                        rm -rf ~/.m2/repository/com/ibm/ncbs/ncbs-mid-jasypt/*
                    """
                }
            }
        }

        stage('Build APP Code') {
            when {
                expression { env.TYPE == 'app' || env.TYPE == 'rpt' }
            }

            steps {
                script {
                    for (project in deployProjects) {
                        echo "Building ${project}-${env.TYPE} code"

                        def projectVersion = sh(
                            script: "mvn -q -DforceStdout help:evaluate -Dexpression=project.version -pl :${project}-${env.TYPE}",
                            returnStdout: true
                        ).trim()
                        projectVersions[project] = projectVersion

                        sh """
                            mvn -U clean install \\
                            -pl :${project}-${env.TYPE} \\
                            -am -Dnexus-url=${NEXUS_URL} \\
                            -Dmaven.test.skip=true \\
                            -Dmid-entity-generator.version=1.0.1-P2-SNAPSHOT \\
                            -Dmaven.wagon.http.ssl.insecure=true \\
                            -Dmaven.wagon.http.ssl.allowall=true
                        """
                    }
                    echo "${projectVersions}"
                }
            }
        }

        stage('Build APP Image') {
            when {
                expression { env.TYPE == 'app' || env.TYPE == 'rpt' }
            }

            steps {
                script {
                    // 這裏的 credentialsId 要根據實際情況修改
                    withCredentials([usernamePassword(credentialsId: 'harbor-user', passwordVariable: 'HARBOR_PASSWORD', usernameVariable: 'HARBOR_USER')]) {
                        // 先登入 Harbor，爲了拉取 base image
                        sh "podman login ${CONTAINER_REGISTRY} -u '${HARBOR_USER}' -p '${HARBOR_PASSWORD}'"
                        for (project in deployProjects) {
                            echo "Building ${project}-${env.TYPE} image"

                            sh """
                                podman images | grep ${project}-${env.TYPE} | awk '{print \$3}' | xargs podman rmi --force || true
                                cd ${env.WORKSPACE}/${project}/${project}-${env.TYPE}
                                podman build --build-arg CONTAINER_REGISTRY=${CONTAINER_REGISTRY} -f ./Dockerfile -t ${CONTAINER_REGISTRY}/${env.NAMESPACE}/${project}-${env.TYPE}:${env.TAG} .
                            """
                        }
                    }
                }
            }
        }

        stage('Release APP Image') {
            when {
                expression { env.TYPE == 'app' || env.TYPE == 'rpt' }
            }

            steps {
                script {
                    // 上傳 image 到 Harbor
                    for (project in deployProjects) {
                        echo "Releaseing ${project}-${env.TYPE} image"

                        //取得 RepoDigest
                        def repoDigest = sh(returnStdout: true, script: "podman inspect -f '{{index .RepoDigests 0}}' ${CONTAINER_REGISTRY}/${env.NAMESPACE}/${project}-${env.TYPE}:${env.TAG}").trim()
                        // 上傳 repoDigest 到 Harbor
                        sh "podman push ${repoDigest}"
                        // 上傳 image 到 Harbor
                        sh "podman push ${CONTAINER_REGISTRY}/${env.NAMESPACE}/${project}-${env.TYPE}:${env.TAG}"
                        sh "podman tag ${project}-${TYPE}:${TAG} ${CONTAINER_REGISTRY}/${env.NAMESPACE}/${project}-${TYPE}:latest"
                        sh "podman push ${CONTAINER_REGISTRY}/${env.NAMESPACE}/${project}-${TYPE}:latest"
                        // credentialsId 要根據實際情況修改
                        withCredentials([file(credentialsId: 'cosign-private-key', variable: 'COSIGN_PRIVATE_KEY'), string(credentialsId: 'cosign-password', variable: 'COSIGN_PASSWORD')]) {
                            println(repoDigest)
                            // 使用 cosign 簽名
                            sh "cosign sign --key '${COSIGN_PRIVATE_KEY}' --tlog-upload=false --allow-insecure-registry=true ${repoDigest}"
                        }
                    }
                    
                    sh "podman logout ${CONTAINER_REGISTRY}"
                }
            }
        }

        stage('Rollout Deployment') {
            when {
                expression { env.TYPE == 'app' || env.TYPE == 'rpt' }
            }

            steps {
                script {
                    openshift.withCluster(OPENSHIFT_SERVER) {
                        openshift.withProject("${env.NAMESPACE}") {
                            def deployProjects = env.DEPLOY_PROJECTS.split(',')
                            def rolloutSuccess = true

                            for (project in deployProjects) {
                                echo "Rollout ${project} for version ${TAG}"
                                def currentTimestamp = sh(
                                    script: "date +%Y-%m-%d\\ %H:%M:%S",
                                    returnStdout: true
                                ).trim()
                                def projectVersion = "${projectVersions[project]}"
                                echo "Rollout ${project}-${TYPE} for version ${projectVersion} version"

                                try {
                                    // 導入最新鏡像
                                    openshift.raw('import-image', "${project}-${TYPE}:${TAG}", 
                                        "--from=${CONTAINER_REGISTRY}/${CONTAINER_PROJECT}/${project}-${TYPE}:${TAG}", '--confirm')

                                    // 更新 deployment 的 image 和環境變數
                                    openshift.raw('set', 'image', "deployment/${project}-${TYPE}", 
                                        "${project}-${TYPE}=${CONTAINER_REGISTRY}/${CONTAINER_PROJECT}/${project}-${TYPE}:${TAG}")
                                    openshift.raw('set', 'env', "deployment/${project}-${TYPE}", 
                                        "RELEASE-VERSION=${projectVersion}", 
                                        "RELEASE-TAG=${TAG}", 
                                        "RELEASE-TIMESTAMP=${currentTimestamp}")

                                    // 重啓 deployment
                                    openshift.raw('rollout', 'restart', "deployment/${project}-${TYPE}")
                                    echo "Rollout of ${project}-${TYPE} succeeded!"
                                } catch (Exception e) {
                                    echo "Rollout of ${project}-${TYPE} failed: ${e.getMessage()}"
                                    rolloutSuccess = false // 設爲失敗
                                }
                            }

                            // 確認所有 Rollout 狀態
                            if (rolloutSuccess) {
                                echo 'Rollout successful!'
                            } else {
                                error('One or more Rollout checks failed.')
                            }
                        }
                    }
                }
            }
        }

        stage('Check Deployment and Pod Status') {
            when {
                expression { env.TYPE == 'app' || env.TYPE == 'rpt' }
            }

            steps {
                script {
                    openshift.withCluster(OPENSHIFT_SERVER) {
                        openshift.withProject("${env.NAMESPACE}") {
                            for (project in deployProjects) {
                                echo "Check ${project} deployment and Pod status"

                                try {
                                    def deployment = openshift.selector('deployment', "${project}-${env.TYPE}")
                                    def deploymentObject = openshift.selector('deployment', "${project}-${env.TYPE}").object()
                                    // 1分鐘 timeout
                                    def rolloutStatus = timeout(5) {deployment.rollout().status()}

                                    // 判斷是否成功
                                    if (rolloutStatus.out.contains('successfully rolled out')) {
                                        echo "Deployment ${project}-${env.TYPE} has successfully rolled out."
                                        echo "rolloutStatus: ${rolloutStatus.out}"
                                    } else {
                                        // 提供更詳細的錯誤資訊
                                        echo "Rollout of ${project}-${env.TYPE} failed. Status: ${deploymentObject}"
                                        error("Rollout of ${project}-${env.TYPE} failed. Status: ${deployment}")
                                    }
                                } catch (Exception e) {
                                    echo "Deployment or Pod check for ${project}-${env.TYPE} failed: ${e.getMessage()}"
                                    error("Rollout of ${project}-${env.TYPE} failed. Status: ${deployment}")
                                    break // 停止檢查，直接退出迴圈
                                } finally {
                                    // openshift.verbose(false) // 關閉 verbose 模式
                                }
                            }
                            echo 'All deployments and Pods are successful!'
                        }
                    }
                }
            }
        }

        stage('Save info') {
            when {
                expression { env.TYPE == 'app' || env.TYPE == 'rpt' }
            }

            steps {
                script {
                    for (project in deployProjects) {
                        env.HASH = sh(returnStdout: true, script: "podman inspect -f '{{.Digest}}' ${CONTAINER_REGISTRY}/${env.NAMESPACE}/${project}-${env.TYPE}:${env.TAG}").trim()
                        url = sh(script: "echo ${GIT_REPO_URL} | sed 's,https://,,'", returnStdout: true).trim()
                        group_id = sh(script: "echo ${url} | grep / | cut -d/ -f2", returnStdout: true).trim()
                        project_id = sh(script: "echo ${url} | grep / | cut -d/ -f3 | sed 's,.git,,'", returnStdout: true).trim()
                        patchOrg = """{
                            "group": "${group_id}",
                            "project": "${project}-${env.TYPE}",
                            "version": "${env.TAG}",
                            "packages": [
                                {
                                    "name": "${project}-${env.TYPE}",
                                    "hash": "${HASH}",
                                    "url": "${CONTAINER_REGISTRY}/${env.NAMESPACE}/${project}-${env.TYPE}:${env.TAG}"
                                }
                            ]
                        }"""
                        echo "${patchOrg}"
                        response = httpRequest acceptType: 'APPLICATION_JSON',
                                   contentType: 'APPLICATION_JSON',
                                   httpMode: 'POST',
                                   requestBody: patchOrg,
                                   url: "${CICDAPISERVICE_URL}/api/v1/packages/project",
                                   validResponseCodes: '200:500'
                        println('Status: ' + response.status)
                        println('Response: ' + response.content)

                        if (response.status != 200) {
                            error(response.content)
                        }
                    }
                }
            }
        }
    }
}
