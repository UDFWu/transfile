pipeline {
    agent any

    parameters {
        string(name: 'NAMESPACE', defaultValue: 'mid', description: '部屬的 namespace')
        string(name: 'TAG', defaultValue: '1.0.0', description: '部屬的 tag')
        string(name: 'TYPE', defaultValue: 'app', description: '部屬的環境')
        booleanParam(defaultValue: false, description: '部屬 demo', name: 'demo')
        booleanParam(defaultValue: false, description: '部屬 cbr', name: 'cbr')
        booleanParam(defaultValue: false, description: '部屬 cmn', name: 'cmn')
        booleanParam(defaultValue: false, description: '部屬 dep', name: 'dep')
        booleanParam(defaultValue: false, description: '部屬 gla', name: 'gla')
        booleanParam(defaultValue: false, description: '部屬 len', name: 'len')
        booleanParam(defaultValue: false, description: '部屬 rem', name: 'rem')
        booleanParam(defaultValue: false, description: '部屬 remb', name: 'remb')
        booleanParam(defaultValue: false, description: '部屬 remm', name: 'remm')
        booleanParam(defaultValue: false, description: '部屬 rems', name: 'rems')
    }

    stages {
        stage('Get Selection') {
            steps {
                script {
                    def deployProjects = []
                    if (params.demo) {
                        deployProjects.add('demo')
                    }
                    if (params.cbr) {
                        deployProjects.add('cbr')
                    }
                    if (params.cmn) {
                        deployProjects.add('cmn')
                    }
                    if (params.dep) {
                        deployProjects.add('dep')
                    }
                    if (params.gla) {
                        deployProjects.add('gla')
                    }
                    if (params.len) {
                        deployProjects.add('len')
                    }
                    if (params.rem) {
                        deployProjects.add('rem')
                    }
                    if (params.remb) {
                        deployProjects.add('remb')
                    }
                    if (params.remm) {
                        deployProjects.add('remm')
                    }
                    if (params.rems) {
                        deployProjects.add('rems')
                    }

                    if (deployProjects.isEmpty()) {
                        error '請至少選擇一個專案部屬'
                    }

                    env.DEPLOY_PROJECTS = deployProjects.join(',')
                    echo "DEPLOY_PROJECTS: ${env.DEPLOY_PROJECTS}"
                    echo "NAMESPACE: ${env.NAMESPACE}"
                    echo "TAG: ${env.TAG}"
                    echo "TYPE: ${env.TYPE}"

                    // 定義要傳送的參數
                    def parameters = [
                        string(name: 'DEPLOY_PROJECTS', value: env.DEPLOY_PROJECTS),
                        string(name: 'NAMESPACE', value: env.NAMESPACE),
                        string(name: 'TAG', value: env.TAG),
                        string(name: 'TYPE', value: env.TYPE)
                    ]
                    // 觸發 B pipeline
                    build job: 'ncbs-mid-ocp-repo-B', parameters: parameters
                }
            }
        }
    }
}

