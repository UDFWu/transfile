def deployProjects = [] // 在腳本作用域中聲明變數

pipeline {
    agent any

    tools {
        oc 'OpenShift CLI'
    }

    environment {
        GIT_REPO_URL = 'https://sdpsg01.cbsd.scsb.com.tw/mid/ncbs-mid-ocp-repo.git'
        GIT_REPO_SSH_URL = 'git@sdpsg01.cbsd.scsb.com.tw:mid/ncbs-mid-ocp-repo.git'
        // NEXUS_URL 要根據實際情況修改
        NEXUS_URL = 'https://sdpsn01.cbsd.scsb.com.tw/'
        CONTAINER_REGISTRY = 'socph01.cbsd.scsb.com.tw'
        OPENSHIFT_SERVER = 'mid'
        // SPRING_PROFILE 要根據實際情況修改
        SPRING_PROFILE = 'sit'
    }

    stages {
        stage('Get Selection') {
            steps {
                script {
                    if (!params.DEPLOY_PROJECTS ||params.DEPLOY_PROJECTS.trim().isEmpty()) {
                        error '請至少選擇一個專案部屬'
                    }

                    // 將收到的參數設置爲環境變數
                    deployProjects = params.DEPLOY_PROJECTS.split(',') // 將結果存入全局變數
                    env.NAMESPACE = params.NAMESPACE
                    env.TAG = params.TAG
                    env.TYPE = params.TYPE

                    //檢查訊息
                    echo "Deploy Projects: ${deployProjects}"
                    echo "NAMESPACE: ${env.NAMESPACE}"
                    echo "TYPE: ${env.TYPE}"
                    echo "TAG: ${env.TAG}"
                }
            }
        }

        stage('print deployProjects with for loop') {
            steps {
                script {
                    for (project in deployProjects) {
                        echo "Deploy Project: ${project}"
                    }
                    // print other information
                    echo "NAMESPACE: ${env.NAMESPACE}"
                    echo "TYPE: ${env.TYPE}"
                    echo "TAG: ${env.TAG}"
                    echo "SPRING_PROFILE: ${SPRING_PROFILE}"
                }
            }
        }

        stage('Declarative: Checkout SCM') {
            steps {
                checkout scmGit(
                    // 依據實際情況修改
                    branches: [[name: '*/main']],
                    browser: github("${GIT_REPO_URL}"),
                    extensions: [],
                    // 依據實際情況修改
                    userRemoteConfigs: [[credentialsId: '6c14edec-6672-4160-a4c5-c9de7c038284', url: "${GIT_REPO_SSH_URL}"]]
                )
            }
        }

        stage('Deploy YAML To Nexus') {
            steps {
                script {
                    sh """
                        mvn clean deploy -Dnexus-url=${NEXUS_URL} -Dmaven.wagon.http.ssl.insecure=true -Dmaven.wagon.http.ssl.allowall=true
                    """
                }
            }
        }

        stage('Download YAML From Nexus') {
            steps {
                script {
                    sh """
                        rm -rf ncbs-mid-ocp-repo-1.0.0.tar.gz
                        rm -rf ~/.m2/respoitory/com/ibm/ncbs/ncbs-mid-ocp/*

                        mvn dependency:get -DremoteRepositories=${NEXUS_URL}/repository/maven-group \
                           -DgroupId=com.ibm.ncbs \
                           -DartifactId=ncbs-mid-ocp \
                           -Dversion=${env.TAG} \
                           -Dpackaging=tar.gz \
                           -Ddest=ncbs-mid-ocp-repo-1.0.0.tar.gz \
                           -Dmaven.wagon.http.ssl.insecure=true \
                           -Dmaven.wagon.http.ssl.allowall=true
                    """
                }
            }
        }

        stage('Apply YAML with OpenShift Plugin') {
            steps {
                script {
                    openshift.withCluster(OPENSHIFT_SERVER) {
                        openshift.withProject("${env.NAMESPACE}") {
                            applySuccess = true

                            for (project in deployProjects) {
                                echo "Processing YAML for project: ${project}-${TYPE}"
                                try {
                                    // 替換 YAML 文件中的佔位符
                                    def workspacePath = "${env.WORKSPACE}/${project}/${project}-${TYPE}"
                                    sh """
                                        cd ${workspacePath}
                                        sed -i 's/{{HARBOR_SERVER}}/${CONTAINER_REGISTRY}/g' imagestream.yaml
                                        sed -i 's/{{SPRING_PROFILE}}/${env.SPRING_PROFILE}/g' deployment.yaml
                                    """

                                    // 使用 OpenShift 插件應用 YAML 文件
                                    openshift.raw('apply', '-f', "${workspacePath}/deployment.yaml", '-f', "${workspacePath}/service.yaml", '-f', "${workspacePath}/route.yaml", '-f', "${workspacePath}/imagestream.yaml")

                                    echo "Apply of ${project}-${TYPE} YAML succeeded!"
                                } catch (Exception e) {
                                    echo "Apply of ${project}-${TYPE} YAML failed: ${e.getMessage()}"
                                    applySuccess = false
                                }
                            }

                            if (applySuccess) {
                                echo 'All YAML files applied successfully!'
                            } else {
                                error('One or more YAML applications failed.')
                            }
                        }
                    }
                }
            }
        }
    }
}
