declare 
  -- Local variables here
  V_TAG_OWNER VARCHAR2(100) :='MIDAPP';
  V_SRC_OWNER VARCHAR2(100) :='MIDMVW';
  sql_stmt  VARCHAR2(1000);
begin

--grant Select on MIDMVW MV to MIDAPP
FOR CC IN (
SELECT MVIEW_NAME TABLE_NAME FROM all_MViews WHERE OWNER = V_SRC_OWNER and instr(TABLE_NAME,'MLOG$')  = 0 and instr(TABLE_NAME,'BIN$')  = 0
minus
SELECT TABLE_NAME FROM ALL_tab_privS WHERE GRANTEE =V_TAG_OWNER AND TABLE_SCHEMA=V_SRC_OWNER AND PRIVILEGE='SELECT' and instr(TABLE_NAME,'MLOG$')  = 0 and instr(TABLE_NAME,'BIN$')  = 0
) Loop
    sql_stmt := 'GRANT Select ON ' || V_SRC_OWNER ||'.'|| cc.ORI_TABLE_NAME ||' TO '||V_TAG_OWNER;
    --DBMS_OUTPUT.PUT_LINE('SQL Statement = ' || sql_stmt );
    EXECUTE IMMEDIATE sql_stmt; 
  END LOOP;
END;

