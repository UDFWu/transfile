declare 
  -- Local variables here
  V_TAG_OWNER VARCHAR2(100) :='MIDAPP';
  V_SRC_OWNER VARCHAR2(100) :='MIDMVW';
  sql_stmt  VARCHAR2(500);
begin

-- create MIDAPP synonym From MIDMVW
FOR CC IN (
SELECT MVIEW_NAME TABLE_NAME FROM ALL_MVIEWS WHERE OWNER =V_SRC_OWNER
minus
SELECT TABLE_NAME FROM ALL_SYNONYMS WHERE OWNER=V_TAG_OWNER AND TABLE_OWNER =V_SRC_OWNER
) Loop
    sql_stmt := 'CREATE OR REPLACE SYNONYM ' || V_TAG_OWNER ||'.'|| cc.table_name || ' for ' ||  V_SRC_OWNER|| '.' || cc.table_name;
    --DBMS_OUTPUT.PUT_LINE('SQL Statement = ' || sql_stmt );
    EXECUTE IMMEDIATE sql_stmt; 
  END LOOP;
  
--Drop MIDAPP's  MIDMVW synonym
FOR CC IN (
SELECT TABLE_NAME FROM ALL_SYNONYMS WHERE OWNER=V_TAG_OWNER AND TABLE_OWNER =V_SRC_OWNER
minus
SELECT MVIEW_NAME TABLE_NAME FROM ALL_MVIEWS WHERE OWNER =V_SRC_OWNER
) Loop

    sql_stmt := 'Drop SYNONYM ' || V_TAG_OWNER ||'.'|| cc.table_name ;
    DBMS_OUTPUT.PUT_LINE('SQL Statement = ' || sql_stmt );
    EXECUTE IMMEDIATE sql_stmt; 
  END LOOP;

END;

