Papirus icon theme
Version 20171223
License GNU LGPL v3.0
https://github.com/PapirusDevelopmentTeam/papirus-icon-theme/tree/20171223
